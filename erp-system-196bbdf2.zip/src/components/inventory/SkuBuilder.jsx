import React, { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function SkuBuilder({ value, onChange, existingProducts }) {
  const [projekt, setProjekt] = useState("");
  const [lokation, setLokation] = useState("");
  const [system, setSystem] = useState("");
  const [komponent, setKomponent] = useState("");
  const [variant, setVariant] = useState("STD");
  const [revision, setRevision] = useState("R1");
  const [generatedSku, setGeneratedSku] = useState("");
  const [isValid, setIsValid] = useState(false);
  const [errors, setErrors] = useState([]);

  // Generer SKU når felter ændres
  useEffect(() => {
    if (projekt && lokation && system && komponent && revision) {
      const variantPart = variant ? `-${variant}` : "";
      const sku = `${projekt}-${lokation}-${system}-${komponent}${variantPart}-${revision}`;
      setGeneratedSku(sku);
      
      // Valider
      const newErrors = [];
      
      // Tjek om SKU allerede findes
      if (existingProducts?.some(p => p.sku === sku)) {
        newErrors.push("SKU findes allerede i systemet");
      }
      
      // Valider format (kun store bogstaver og tal)
      if (!/^[A-Z0-9-]+$/.test(sku)) {
        newErrors.push("SKU må kun indeholde store bogstaver, tal og bindestreger");
      }
      
      setErrors(newErrors);
      setIsValid(newErrors.length === 0);
      
      if (newErrors.length === 0) {
        onChange(sku);
      }
    } else {
      setGeneratedSku("");
      setIsValid(false);
      setErrors(["Alle påkrævede felter skal udfyldes"]);
    }
  }, [projekt, lokation, system, komponent, variant, revision, existingProducts, onChange]);

  // Parser eksisterende SKU hvis value er sat
  useEffect(() => {
    if (value && value.includes("-")) {
      const parts = value.split("-");
      if (parts.length >= 5) {
        setProjekt(parts[0] || "");
        setLokation(parts[1] || "");
        setSystem(parts[2] || "");
        setKomponent(parts[3] || "");
        if (parts.length === 6) {
          setVariant(parts[4] || "STD");
          setRevision(parts[5] || "R1");
        } else {
          setVariant("STD");
          setRevision(parts[4] || "R1");
        }
      }
    }
  }, [value]);

  const handleUpperCase = (setter) => (e) => {
    setter(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''));
  };

  return (
    <div className="space-y-4 p-4 bg-slate-50 rounded-lg border border-slate-200">
      <div className="flex items-center justify-between">
        <Label className="text-lg font-semibold">SKU Builder</Label>
        {generatedSku && (
          <Badge className={isValid ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
            {isValid ? (
              <>
                <Check className="w-3 h-3 mr-1" />
                Gyldig
              </>
            ) : (
              <>
                <AlertCircle className="w-3 h-3 mr-1" />
                Ugyldig
              </>
            )}
          </Badge>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="projekt">
            Projektkode *
            <span className="text-xs text-slate-500 ml-2">(f.eks. ECW, OWF)</span>
          </Label>
          <Input
            id="projekt"
            value={projekt}
            onChange={handleUpperCase(setProjekt)}
            placeholder="ECW"
            maxLength={10}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="lokation">
            Lokation *
            <span className="text-xs text-slate-500 ml-2">(f.eks. A1, TP2, WTG3)</span>
          </Label>
          <Input
            id="lokation"
            value={lokation}
            onChange={handleUpperCase(setLokation)}
            placeholder="TP2"
            maxLength={10}
          />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="system">Systemtype *</Label>
          <Select value={system} onValueChange={setSystem}>
            <SelectTrigger>
              <SelectValue placeholder="Vælg system" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="RACK">RACK - Rack system</SelectItem>
              <SelectItem value="PWR">PWR - Power/Strøm</SelectItem>
              <SelectItem value="NET">NET - Netværk</SelectItem>
              <SelectItem value="RADAR">RADAR - Radar system</SelectItem>
              <SelectItem value="CAM">CAM - Kamera system</SelectItem>
              <SelectItem value="CTRL">CTRL - Control system</SelectItem>
              <SelectItem value="HYD">HYD - Hydraulik</SelectItem>
              <SelectItem value="PNEU">PNEU - Pneumatik</SelectItem>
              <SelectItem value="SENS">SENS - Sensorer</SelectItem>
              <SelectItem value="MECH">MECH - Mekanisk</SelectItem>
              <SelectItem value="ELEC">ELEC - Elektrisk</SelectItem>
              <SelectItem value="MISC">MISC - Diverse</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="komponent">
            Komponentnavn *
            <span className="text-xs text-slate-500 ml-2">(f.eks. APC1500, AXISQ18)</span>
          </Label>
          <Input
            id="komponent"
            value={komponent}
            onChange={handleUpperCase(setKomponent)}
            placeholder="APC1500"
            maxLength={20}
          />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="variant">
            Variant
            <span className="text-xs text-slate-500 ml-2">(f.eks. STD, EXT, SP1)</span>
          </Label>
          <Input
            id="variant"
            value={variant}
            onChange={handleUpperCase(setVariant)}
            placeholder="STD"
            maxLength={10}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="revision">Revision *</Label>
          <Select value={revision} onValueChange={setRevision}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="R1">R1 - Første revision</SelectItem>
              <SelectItem value="R2">R2 - Anden revision</SelectItem>
              <SelectItem value="R3">R3 - Tredje revision</SelectItem>
              <SelectItem value="R4">R4 - Fjerde revision</SelectItem>
              <SelectItem value="R5">R5 - Femte revision</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {generatedSku && (
        <div className="space-y-2">
          <Label>Genereret SKU</Label>
          <div className={`p-4 rounded-lg border-2 font-mono text-lg font-bold text-center ${
            isValid 
              ? 'bg-green-50 border-green-300 text-green-800' 
              : 'bg-red-50 border-red-300 text-red-800'
          }`}>
            {generatedSku}
          </div>
        </div>
      )}

      {errors.length > 0 && (
        <Alert variant="destructive">
          <AlertCircle className="w-4 h-4" />
          <AlertDescription>
            <ul className="list-disc list-inside space-y-1">
              {errors.map((error, index) => (
                <li key={index}>{error}</li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      <div className="text-xs text-slate-600 bg-blue-50 p-3 rounded border border-blue-200">
        <strong>Format:</strong> [PROJEKT]-[LOKATION]-[SYSTEM]-[KOMPONENT]-[VARIANT]-[REVISION]
        <br />
        <strong>Eksempel:</strong> ECW-TP2-NET-APC1500-STD-R1
      </div>
    </div>
  );
}