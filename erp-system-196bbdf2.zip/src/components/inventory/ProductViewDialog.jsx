import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Edit2, Download, TrendingDown, Package } from "lucide-react";
import { useLanguage } from "@/components/LanguageContext";

export default function ProductViewDialog({ product, supplier, open, onClose, onEdit }) {
  const { t } = useLanguage();
  if (!product) return null;

  const isLowStock = product.current_stock <= product.min_stock_level;
  const stockValue = product.current_stock * product.unit_price;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                product.criticality === 'critical' ? 'bg-red-100' : 'bg-blue-100'
              }`}>
                <Package className={`w-5 h-5 ${
                  product.criticality === 'critical' ? 'text-red-600' : 'text-blue-600'
                }`} />
              </div>
              {product.name}
            </DialogTitle>
            <Button size="sm" onClick={() => { onClose(); onEdit(product); }}>
              <Edit2 className="w-4 h-4 mr-2" />
              {t('edit')}
            </Button>
          </div>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Basic Info */}
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <p className="text-sm text-slate-500">SKU</p>
              <p className="font-mono font-medium">{product.sku}</p>
            </div>
            <div>
              <p className="text-sm text-slate-500">{t('category')}</p>
              <Badge variant="outline">{t(product.category)}</Badge>
            </div>
            {product.description && (
              <div className="md:col-span-2">
                <p className="text-sm text-slate-500">{t('description')}</p>
                <p className="font-medium">{product.description}</p>
              </div>
            )}
          </div>

          {/* Component Details */}
          {(product.component_type || product.criticality) && (
            <div className="border-t pt-4">
              <h3 className="font-semibold mb-3">{t('componentType')}</h3>
              <div className="grid md:grid-cols-3 gap-4">
                {product.component_type && (
                  <div>
                    <p className="text-sm text-slate-500">{t('type')}</p>
                    <Badge variant="outline">{product.component_type.replace(/_/g, ' ')}</Badge>
                  </div>
                )}
                {product.criticality && (
                  <div>
                    <p className="text-sm text-slate-500">{t('criticality')}</p>
                    <Badge className={
                      product.criticality === 'critical' ? 'bg-red-100 text-red-800' :
                      product.criticality === 'high' ? 'bg-orange-100 text-orange-800' :
                      product.criticality === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }>{product.criticality}</Badge>
                  </div>
                )}
                {product.stock_strategy && (
                  <div>
                    <p className="text-sm text-slate-500">{t('stockStrategy')}</p>
                    <Badge variant="outline">{product.stock_strategy.replace(/_/g, ' ')}</Badge>
                  </div>
                )}
                {product.failure_impact && (
                  <div>
                    <p className="text-sm text-slate-500">{t('failureImpact')}</p>
                    <Badge variant="outline">{product.failure_impact.replace(/_/g, ' ')}</Badge>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Stock & Pricing */}
          <div className="border-t pt-4">
            <h3 className="font-semibold mb-3">{t('stock')} & {t('value')}</h3>
            <div className="grid md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-slate-500">{t('currentStock')}</p>
                <p className={`font-bold ${isLowStock ? 'text-orange-600' : 'text-slate-900'}`}>
                  {product.current_stock} {product.unit}
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-500">{t('minLevel')}</p>
                <p className="font-medium">{product.min_stock_level} {product.unit}</p>
              </div>
              <div>
                <p className="text-sm text-slate-500">{t('unitPrice')}</p>
                <p className="font-medium">{product.unit_price} {t('kr')}</p>
              </div>
              <div>
                <p className="text-sm text-slate-500">{t('value')}</p>
                <p className="font-bold text-blue-600">{stockValue.toLocaleString('da-DK')} {t('kr')}</p>
              </div>
              {product.reorder_quantity && (
                <div>
                  <p className="text-sm text-slate-500">{t('reorderQty')}</p>
                  <p className="font-medium">{product.reorder_quantity} {product.unit}</p>
                </div>
              )}
              {product.lead_time_days > 0 && (
                <div>
                  <p className="text-sm text-slate-500">{t('leadTime')}</p>
                  <p className="font-medium">{product.lead_time_days} {t('da') || 'dage'}</p>
                </div>
              )}
            </div>
            {isLowStock && (
              <div className="mt-3 p-3 bg-orange-50 border border-orange-200 rounded-lg flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-orange-600" />
                <span className="text-sm text-orange-800 font-medium">{t('lowStock')}</span>
              </div>
            )}
          </div>

          {/* Supplier */}
          {supplier && (
            <div className="border-t pt-4">
              <h3 className="font-semibold mb-3">{t('supplier')}</h3>
              <div className="p-3 bg-slate-50 rounded-lg">
                <p className="font-medium">{supplier.name}</p>
                <p className="text-sm text-slate-500">{supplier.email} • {supplier.phone}</p>
              </div>
            </div>
          )}

          {/* Manuals */}
          {product.manuals && product.manuals.length > 0 && (
            <div className="border-t pt-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <FileText className="w-4 h-4" />
                {t('manuals')} ({product.manuals.length})
              </h3>
              <div className="space-y-2">
                {product.manuals.map((manual, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-blue-600" />
                      <div>
                        <div className="text-sm font-medium">{manual.name}</div>
                        <div className="text-xs text-slate-500">{manual.file_type?.toUpperCase()}</div>
                      </div>
                    </div>
                    <a href={manual.file_url} target="_blank" rel="noopener noreferrer">
                      <Button size="sm" variant="ghost">
                        <Download className="w-4 h-4" />
                      </Button>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}