import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Camera, FileText, MapPin, Edit2, Download, Box, Weight, Ruler } from "lucide-react";
import { useLanguage } from "@/components/LanguageContext";

export default function EquipmentViewDialog({ equipment, open, onClose, onEdit }) {
  const { t } = useLanguage();
  if (!equipment) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-3">
              <Box className="w-6 h-6 text-blue-600" />
              {equipment.name}
            </DialogTitle>
            <Button size="sm" onClick={() => { 
              onClose(); 
              setTimeout(() => onEdit(equipment), 50);
            }}>
              <Edit2 className="w-4 h-4 mr-2" />
              {t('edit')}
            </Button>
          </div>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Basic Info */}
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <p className="text-sm text-slate-500">{t('equipmentId')}</p>
              <p className="font-medium">{equipment.equipment_id}</p>
            </div>
            <div>
              <p className="text-sm text-slate-500">{t('type')}</p>
              <Badge variant="outline">{equipment.type?.replace(/_/g, ' ')}</Badge>
            </div>
            <div>
              <p className="text-sm text-slate-500">{t('site')}</p>
              <Badge variant="outline" className="gap-1">
                <MapPin className="w-3 h-3" />
                {equipment.site}
              </Badge>
            </div>
            <div>
              <p className="text-sm text-slate-500">{t('status')}</p>
              <Badge className={
                equipment.status === 'available' ? 'bg-green-100 text-green-800' :
                equipment.status === 'in_use' || equipment.status === 'offshore' ? 'bg-blue-100 text-blue-800' :
                'bg-slate-100 text-slate-800'
              }>{t(equipment.status)}</Badge>
            </div>
            <div>
              <p className="text-sm text-slate-500">{t('quantity')}</p>
              <p className="font-medium">{equipment.quantity || 1}x</p>
            </div>
            <div>
              <p className="text-sm text-slate-500">{t('condition')}</p>
              <Badge>{t(equipment.condition)}</Badge>
            </div>
            {equipment.added_by && (
              <div>
                <p className="text-sm text-slate-500">{t('addedBy')}</p>
                <p className="font-medium">{equipment.added_by}</p>
              </div>
            )}
            {equipment.weight_kg && (
              <div>
                <p className="text-sm text-slate-500 flex items-center gap-1">
                  <Weight className="w-3 h-3" />
                  {t('weight')}
                </p>
                <p className="font-medium">{equipment.weight_kg} kg</p>
              </div>
            )}
          </div>

          {/* Dimensions */}
          {equipment.dimensions && (equipment.dimensions.length_mm || equipment.dimensions.width_mm || equipment.dimensions.height_mm) && (
            <div className="border-t pt-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Ruler className="w-4 h-4" />
                {t('dimensions')}
              </h3>
              <div className="grid md:grid-cols-3 gap-4">
                {equipment.dimensions.length_mm && (
                  <div>
                    <p className="text-sm text-slate-500">{t('length')}</p>
                    <p className="font-medium">{equipment.dimensions.length_mm} mm</p>
                  </div>
                )}
                {equipment.dimensions.width_mm && (
                  <div>
                    <p className="text-sm text-slate-500">{t('width')}</p>
                    <p className="font-medium">{equipment.dimensions.width_mm} mm</p>
                  </div>
                )}
                {equipment.dimensions.height_mm && (
                  <div>
                    <p className="text-sm text-slate-500">{t('height')}</p>
                    <p className="font-medium">{equipment.dimensions.height_mm} mm</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Technical Details */}
          {(equipment.manufacturer || equipment.year_developed || equipment.developed_for_project) && (
            <div className="border-t pt-4">
              <h3 className="font-semibold mb-3">{t('technicalDocuments')}</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {equipment.manufacturer && (
                  <div>
                    <p className="text-sm text-slate-500">{t('manufacturer')}</p>
                    <p className="font-medium">{equipment.manufacturer}</p>
                  </div>
                )}
                {equipment.year_developed && (
                  <div>
                    <p className="text-sm text-slate-500">{t('yearDeveloped')}</p>
                    <p className="font-medium">{equipment.year_developed}</p>
                  </div>
                )}
                {equipment.developed_for_project && (
                  <div className="md:col-span-2">
                    <p className="text-sm text-slate-500">{t('developedFor')}</p>
                    <p className="font-medium">{equipment.developed_for_project}</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Description & Specifications */}
          {(equipment.description || equipment.specifications) && (
            <div className="border-t pt-4 space-y-4">
              {equipment.description && (
                <div>
                  <p className="text-sm text-slate-500 mb-2">{t('description')}</p>
                  <p className="text-slate-700 bg-slate-50 p-3 rounded-lg">{equipment.description}</p>
                </div>
              )}
              {equipment.specifications && (
                <div>
                  <p className="text-sm text-slate-500 mb-2">{t('specifications')}</p>
                  <p className="text-slate-700 bg-slate-50 p-3 rounded-lg whitespace-pre-wrap">{equipment.specifications}</p>
                </div>
              )}
            </div>
          )}

          {/* Notes */}
          {equipment.notes && (
            <div>
              <p className="text-sm text-slate-500 mb-2">{t('notes')}</p>
              <p className="text-slate-700 bg-slate-50 p-3 rounded-lg">{equipment.notes}</p>
            </div>
          )}

          {/* Photos */}
          {equipment.photos && equipment.photos.length > 0 && (
            <div className="border-t pt-4">
              <p className="text-sm text-slate-500 mb-3 flex items-center gap-2">
                <Camera className="w-4 h-4" />
                {t('photos')} ({equipment.photos.length})
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {equipment.photos.map((photo, index) => (
                  <a key={index} href={photo.url} target="_blank" rel="noopener noreferrer">
                    <img 
                      src={photo.url} 
                      alt={photo.caption}
                      className="w-full h-32 object-cover rounded border border-slate-200 hover:opacity-80 transition-opacity cursor-pointer"
                    />
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Technical Documents */}
          {equipment.technical_documents && equipment.technical_documents.length > 0 && (
            <div className="border-t pt-4">
              <p className="text-sm text-slate-500 mb-3 flex items-center gap-2">
                <FileText className="w-4 h-4" />
                {t('technicalDocuments')} ({equipment.technical_documents.length})
              </p>
              <div className="space-y-2">
                {equipment.technical_documents.map((doc, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-blue-600" />
                      <div>
                        <div className="text-sm font-medium">{doc.name}</div>
                        <Badge variant="outline" className="text-xs mt-1">{doc.type?.replace(/_/g, ' ')}</Badge>
                      </div>
                    </div>
                    <a href={doc.url} target="_blank" rel="noopener noreferrer">
                      <Button size="sm" variant="ghost">
                        <Download className="w-4 h-4" />
                      </Button>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}