import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Camera, FileText, MapPin, Calendar, Edit2, Download } from "lucide-react";
import { format } from "date-fns";
import { useLanguage } from "@/components/LanguageContext";

export default function ToolViewDialog({ tool, open, onClose, onEdit }) {
  const { t } = useLanguage();
  if (!tool) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>{tool.name}</DialogTitle>
            <Button size="sm" onClick={() => { 
              onClose(); 
              setTimeout(() => onEdit(tool), 50);
            }}>
              <Edit2 className="w-4 h-4 mr-2" />
              {t('edit')}
            </Button>
          </div>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Basic Info */}
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <p className="text-sm text-slate-500">{t('toolId')}</p>
              <p className="font-medium">{tool.tool_id}</p>
            </div>
            <div>
              <p className="text-sm text-slate-500">{t('category')}</p>
              <Badge variant="outline">{t(tool.category)}</Badge>
            </div>
            <div>
              <p className="text-sm text-slate-500">{t('site')}</p>
              <Badge variant="outline" className="gap-1">
                <MapPin className="w-3 h-3" />
                {tool.site}
              </Badge>
            </div>
            <div>
              <p className="text-sm text-slate-500">{t('status')}</p>
              <Badge className={
                tool.status === 'available' ? 'bg-green-100 text-green-800' :
                tool.status === 'offshore' ? 'bg-blue-100 text-blue-800' :
                'bg-slate-100 text-slate-800'
              }>{t(tool.status)}</Badge>
            </div>
            {tool.added_by && (
              <div>
                <p className="text-sm text-slate-500">{t('addedBy')}</p>
                <p className="font-medium">{tool.added_by}</p>
              </div>
            )}
            {tool.manufacturer && (
              <div>
                <p className="text-sm text-slate-500">{t('manufacturer')}</p>
                <p className="font-medium">{tool.manufacturer}</p>
              </div>
            )}
            {tool.model && (
              <div>
                <p className="text-sm text-slate-500">{t('model')}</p>
                <p className="font-medium">{tool.model}</p>
              </div>
            )}
            {tool.serial_number && (
              <div>
                <p className="text-sm text-slate-500">{t('serialNumber')}</p>
                <p className="font-medium">{tool.serial_number}</p>
              </div>
            )}
            <div>
              <p className="text-sm text-slate-500">{t('condition')}</p>
              <Badge>{t(tool.condition)}</Badge>
            </div>
          </div>

          {/* Inspection & Certification */}
          <div className="border-t pt-4">
            <h3 className="font-semibold mb-3">{t('inspectionCertification')}</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-slate-500">{t('lastInspection')}</p>
                <p className="font-medium">
                  {tool.last_inspection_date ? format(new Date(tool.last_inspection_date), 'dd/MM/yyyy') : '-'}
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-500">{t('nextInspection')}</p>
                <p className="font-medium">
                  {tool.next_inspection_date ? format(new Date(tool.next_inspection_date), 'dd/MM/yyyy') : '-'}
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-500">{t('requiresCertification')}</p>
                <Badge>{tool.requires_certification ? t('yes') : t('no')}</Badge>
              </div>
              {tool.certification_expiry && (
                <div>
                  <p className="text-sm text-slate-500">{t('certificationExpiry')}</p>
                  <p className="font-medium">{format(new Date(tool.certification_expiry), 'dd/MM/yyyy')}</p>
                </div>
              )}
            </div>
          </div>

          {/* Notes */}
          {tool.notes && (
            <div>
              <p className="text-sm text-slate-500 mb-2">{t('notes')}</p>
              <p className="text-slate-700 bg-slate-50 p-3 rounded-lg">{tool.notes}</p>
            </div>
          )}

          {/* Photos */}
          {tool.photos && tool.photos.length > 0 && (
            <div>
              <p className="text-sm text-slate-500 mb-3 flex items-center gap-2">
                <Camera className="w-4 h-4" />
                {t('photos')} ({tool.photos.length})
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {tool.photos.map((photo, index) => (
                  <a key={index} href={photo.url} target="_blank" rel="noopener noreferrer">
                    <img 
                      src={photo.url} 
                      alt={photo.caption}
                      className="w-full h-32 object-cover rounded border border-slate-200 hover:opacity-80 transition-opacity cursor-pointer"
                    />
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Manuals */}
          {tool.manuals && tool.manuals.length > 0 && (
            <div>
              <p className="text-sm text-slate-500 mb-3 flex items-center gap-2">
                <FileText className="w-4 h-4" />
                {t('manuals')} ({tool.manuals.length})
              </p>
              <div className="space-y-2">
                {tool.manuals.map((manual, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium">{manual.name}</span>
                    </div>
                    <a href={manual.url} target="_blank" rel="noopener noreferrer">
                      <Button size="sm" variant="ghost">
                        <Download className="w-4 h-4" />
                      </Button>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}