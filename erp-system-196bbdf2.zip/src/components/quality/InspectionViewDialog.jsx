import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Camera, FileText, Edit2, Download, CheckCircle2, XCircle, AlertTriangle, Clock } from "lucide-react";
import { format } from "date-fns";
import { useLanguage } from "@/components/LanguageContext";

export default function InspectionViewDialog({ inspection, open, onClose, onEdit }) {
  const { t } = useLanguage();
  if (!inspection) return null;

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved': return <CheckCircle2 className="w-4 h-4" />;
      case 'rejected': return <XCircle className="w-4 h-4" />;
      case 'conditional': return <AlertTriangle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-800",
      approved: "bg-green-100 text-green-800",
      rejected: "bg-red-100 text-red-800",
      conditional: "bg-orange-100 text-orange-800",
    };
    return colors[status] || colors.pending;
  };

  const getResultBadge = (result, type) => {
    if (!result) return <span className="text-slate-400">-</span>;
    
    const colors = {
      ok: 'bg-green-100 text-green-800',
      passed: 'bg-green-100 text-green-800',
      intact: 'bg-green-100 text-green-800',
      not_ok: 'bg-red-100 text-red-800',
      failed: 'bg-red-100 text-red-800',
      minor_issues: 'bg-orange-100 text-orange-800',
      minor_damage: 'bg-orange-100 text-orange-800',
      major_damage: 'bg-red-100 text-red-800',
      not_applicable: 'bg-slate-100 text-slate-800',
      not_checked: 'bg-slate-100 text-slate-800',
    };

    return <Badge className={colors[result] || 'bg-slate-100 text-slate-800'}>{t(result) || result}</Badge>;
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>{t('qualityInspections')} - {inspection.product_name}</DialogTitle>
            <Button size="sm" onClick={() => { 
              onClose(); 
              setTimeout(() => onEdit(inspection), 50);
            }}>
              <Edit2 className="w-4 h-4 mr-2" />
              {t('edit')}
            </Button>
          </div>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Status & Basic Info */}
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <p className="text-sm text-slate-500">{t('status')}</p>
              <Badge className={getStatusColor(inspection.status)}>
                {getStatusIcon(inspection.status)}
                <span className="ml-2">{t(inspection.status)}</span>
              </Badge>
            </div>
            <div>
              <p className="text-sm text-slate-500">{t('inspectionDate')}</p>
              <p className="font-medium">{format(new Date(inspection.inspection_date), 'dd/MM/yyyy')}</p>
            </div>
            <div>
              <p className="text-sm text-slate-500">{t('inspector')}</p>
              <p className="font-medium">{inspection.inspector}</p>
            </div>
            {inspection.added_by && (
              <div>
                <p className="text-sm text-slate-500">{t('addedBy')}</p>
                <p className="font-medium">{inspection.added_by}</p>
              </div>
            )}
            <div>
              <p className="text-sm text-slate-500">{t('product')}</p>
              <p className="font-medium">{inspection.product_name}</p>
              <p className="text-sm text-slate-400">{inspection.product_sku}</p>
            </div>
            <div>
              <p className="text-sm text-slate-500">{t('quantityReceived')}</p>
              <p className="font-medium">{inspection.quantity_received}</p>
            </div>
            {inspection.purchase_order_number && (
              <div>
                <p className="text-sm text-slate-500">{t('orderNumber')}</p>
                <p className="font-mono font-medium">{inspection.purchase_order_number}</p>
              </div>
            )}
            {inspection.serial_number && (
              <div>
                <p className="text-sm text-slate-500">{t('serialNumber')}</p>
                <p className="font-medium">{inspection.serial_number}</p>
              </div>
            )}
            {inspection.batch_number && (
              <div>
                <p className="text-sm text-slate-500">{t('batchNumber')}</p>
                <p className="font-medium">{inspection.batch_number}</p>
              </div>
            )}
          </div>

          {/* Inspection Results */}
          <div className="border-t pt-4">
            <h3 className="font-semibold mb-3">{t('inspectionResults')}</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-slate-500">{t('visualInspection')}</p>
                {getResultBadge(inspection.visual_inspection)}
              </div>
              <div>
                <p className="text-sm text-slate-500">{t('functionalTest')}</p>
                {getResultBadge(inspection.functional_test)}
              </div>
              <div>
                <p className="text-sm text-slate-500">{t('dimensionsCheck')}</p>
                {getResultBadge(inspection.dimensions_check)}
              </div>
              <div>
                <p className="text-sm text-slate-500">{t('packagingCondition')}</p>
                {getResultBadge(inspection.packaging_condition)}
              </div>
            </div>
          </div>

          {/* Notes & Reports */}
          {(inspection.notes || inspection.deviation_report || inspection.corrective_actions) && (
            <div className="border-t pt-4 space-y-4">
              {inspection.notes && (
                <div>
                  <p className="text-sm text-slate-500 mb-2">{t('notes')}</p>
                  <p className="text-slate-700 bg-slate-50 p-3 rounded-lg">{inspection.notes}</p>
                </div>
              )}
              {inspection.deviation_report && (
                <div>
                  <p className="text-sm text-slate-500 mb-2">{t('deviationReport')}</p>
                  <p className="text-slate-700 bg-orange-50 p-3 rounded-lg border border-orange-200">{inspection.deviation_report}</p>
                </div>
              )}
              {inspection.corrective_actions && (
                <div>
                  <p className="text-sm text-slate-500 mb-2">{t('correctiveActions')}</p>
                  <p className="text-slate-700 bg-blue-50 p-3 rounded-lg border border-blue-200">{inspection.corrective_actions}</p>
                </div>
              )}
            </div>
          )}

          {/* Photos */}
          {inspection.photos && inspection.photos.length > 0 && (
            <div className="border-t pt-4">
              <p className="text-sm text-slate-500 mb-3 flex items-center gap-2">
                <Camera className="w-4 h-4" />
                {t('inspectionPhotos')} ({inspection.photos.length})
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {inspection.photos.map((photo, index) => (
                  <a key={index} href={photo.url} target="_blank" rel="noopener noreferrer">
                    <img 
                      src={photo.url} 
                      alt={photo.caption}
                      className="w-full h-32 object-cover rounded border border-slate-200 hover:opacity-80 transition-opacity cursor-pointer"
                    />
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Certificates */}
          {inspection.certificates && inspection.certificates.length > 0 && (
            <div className="border-t pt-4">
              <p className="text-sm text-slate-500 mb-3 flex items-center gap-2">
                <FileText className="w-4 h-4" />
                {t('certificates')} ({inspection.certificates.length})
              </p>
              <div className="space-y-2">
                {inspection.certificates.map((cert, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-blue-600" />
                      <div>
                        <div className="text-sm font-medium">{cert.name}</div>
                        <div className="text-xs text-slate-500">{cert.type}</div>
                      </div>
                    </div>
                    <a href={cert.url} target="_blank" rel="noopener noreferrer">
                      <Button size="sm" variant="ghost">
                        <Download className="w-4 h-4" />
                      </Button>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}