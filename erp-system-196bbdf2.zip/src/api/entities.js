import { base44 } from './base44Client';


export const Product = base44.entities.Product;

export const Supplier = base44.entities.Supplier;

export const PurchaseOrder = base44.entities.PurchaseOrder;

export const SalesOrder = base44.entities.SalesOrder;

export const ProductionRecord = base44.entities.ProductionRecord;

export const StockMovement = base44.entities.StockMovement;

export const Location = base44.entities.Location;

export const Project = base44.entities.Project;

export const ProjectInventory = base44.entities.ProjectInventory;

export const QualityInspection = base44.entities.QualityInspection;

export const Tool = base44.entities.Tool;

export const ToolLoan = base44.entities.ToolLoan;

export const TestEquipment = base44.entities.TestEquipment;

export const ComponentTracking = base44.entities.ComponentTracking;

export const LocationBooking = base44.entities.LocationBooking;

export const Component = base44.entities.Component;

export const MaintenanceTask = base44.entities.MaintenanceTask;



// auth sdk:
export const User = base44.auth;