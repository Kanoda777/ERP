import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Plus, 
  Search, 
  QrCode,
  MapPin,
  History,
  Package,
  AlertCircle,
  CheckCircle2,
  Wrench,
  ArrowRight,
  Calendar,
  FileText,
  Camera,
  Upload,
  Download,
  Trash2,
  Loader2,
  RefreshCw,
  ExternalLink
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Alert,
  AlertDescription,
} from "@/components/ui/alert";
import { useLanguage } from "@/components/LanguageContext";
import ExportButton from "@/components/ExportButton";
import { format } from "date-fns";

export default function MasterTracker() {
  const { t } = useLanguage();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false);
  const [moveDialogOpen, setMoveDialogOpen] = useState(false);
  const [editingComponent, setEditingComponent] = useState(null);
  const [selectedComponent, setSelectedComponent] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterLocation, setFilterLocation] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [photos, setPhotos] = useState([]);
  const [unregisteredSNs, setUnregisteredSNs] = useState([]);
  const queryClient = useQueryClient();

  const { data: components = [] } = useQuery({
    queryKey: ['componentTracking'],
    queryFn: () => base44.entities.ComponentTracking.list('-created_date'),
  });

  const { data: qualityInspections = [] } = useQuery({
    queryKey: ['qualityInspections'],
    queryFn: () => base44.entities.QualityInspection.list('-created_date'),
  });

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
  });

  const { data: projects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.list(),
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.Location.filter({ status: 'active' }),
  });

  // Find serienumre fra QI som ikke er registreret i Master Tracker
  useEffect(() => {
    const registeredSNs = new Set(components.map(c => c.serial_number));
    const unregistered = qualityInspections
      .filter(qi => qi.serial_number && !registeredSNs.has(qi.serial_number) && qi.status === 'approved')
      .map(qi => ({
        serial_number: qi.serial_number,
        product_id: qi.product_id,
        product_name: qi.product_name,
        product_sku: qi.product_sku,
        batch_number: qi.batch_number,
        inspection_date: qi.inspection_date,
        source: 'quality_inspection',
        source_id: qi.id
      }));
    setUnregisteredSNs(unregistered);
  }, [components, qualityInspections]);

  const createComponentMutation = useMutation({
    mutationFn: (data) => base44.entities.ComponentTracking.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['componentTracking']);
      setDialogOpen(false);
      setEditingComponent(null);
      setPhotos([]);
    },
  });

  const updateComponentMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ComponentTracking.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['componentTracking']);
      setDialogOpen(false);
      setMoveDialogOpen(false);
      setEditingComponent(null);
      setSelectedComponent(null);
      setPhotos([]);
    },
  });

  const importFromQI = async (unregisteredItem) => {
    const data = {
      serial_number: unregisteredItem.serial_number,
      product_id: unregisteredItem.product_id,
      product_name: unregisteredItem.product_name,
      product_sku: unregisteredItem.product_sku,
      batch_number: unregisteredItem.batch_number,
      current_location: 'HQ',
      status: 'in_stock',
      condition: 'good',
      purchase_date: unregisteredItem.inspection_date,
      notes: `Importeret fra QA/QC inspektion (${unregisteredItem.inspection_date})`,
      history: [{
        date: format(new Date(), 'yyyy-MM-dd'),
        action: 'imported_from_qi',
        to_location: 'HQ',
        notes: `Automatisk importeret fra QA/QC inspektion`,
        performed_by: 'System'
      }]
    };
    
    await createComponentMutation.mutateAsync(data);
  };

  const handlePhotoUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setUploadingPhoto(true);
    try {
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        const photo = {
          url: file_url,
          caption: file.name,
          date: format(new Date(), 'yyyy-MM-dd'),
        };
        setPhotos(prev => [...prev, photo]);
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Fejl ved upload');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const product = products.find(p => p.id === formData.get('product_id'));
    const project = projects.find(p => p.id === formData.get('current_project_id'));

    const data = {
      serial_number: formData.get('serial_number'),
      product_id: formData.get('product_id'),
      product_name: product?.name,
      product_sku: product?.sku,
      current_location: formData.get('current_location'),
      current_project_id: formData.get('current_project_id'),
      current_project_name: project?.name,
      status: formData.get('status'),
      installation_date: formData.get('installation_date'),
      condition: formData.get('condition'),
      manufacturer_sn: formData.get('manufacturer_sn'),
      batch_number: formData.get('batch_number'),
      purchase_date: formData.get('purchase_date'),
      warranty_expiry: formData.get('warranty_expiry'),
      notes: formData.get('notes'),
      photos: photos,
      history: editingComponent?.history || [],
    };

    if (!editingComponent) {
      data.history = [{
        date: format(new Date(), 'yyyy-MM-dd'),
        action: 'created',
        to_location: data.current_location,
        notes: 'Komponent registreret manuelt',
        performed_by: formData.get('registered_by') || 'System'
      }];
    }

    if (editingComponent) {
      updateComponentMutation.mutate({ id: editingComponent.id, data });
    } else {
      createComponentMutation.mutate(data);
    }
  };

  const handleMove = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const project = projects.find(p => p.id === formData.get('new_project_id'));

    const historyEntry = {
      date: format(new Date(), 'yyyy-MM-dd'),
      action: formData.get('action'),
      from_location: selectedComponent.current_location,
      to_location: formData.get('new_location'),
      project: project?.name || formData.get('project_notes'),
      notes: formData.get('notes'),
      performed_by: formData.get('performed_by')
    };

    const updatedData = {
      ...selectedComponent,
      current_location: formData.get('new_location'),
      current_project_id: formData.get('new_project_id'),
      current_project_name: project?.name,
      status: formData.get('new_status'),
      history: [...(selectedComponent.history || []), historyEntry]
    };

    updateComponentMutation.mutate({ id: selectedComponent.id, data: updatedData });
  };

  const getStatusColor = (status) => {
    const colors = {
      in_stock: "bg-green-100 text-green-800",
      deployed: "bg-blue-100 text-blue-800",
      in_transit: "bg-yellow-100 text-yellow-800",
      under_repair: "bg-orange-100 text-orange-800",
      decommissioned: "bg-slate-100 text-slate-800",
      lost: "bg-red-100 text-red-800",
    };
    return colors[status] || colors.in_stock;
  };

  const filteredComponents = components.filter(comp => {
    const matchesSearch = comp.serial_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         comp.product_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         comp.product_sku?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         comp.manufacturer_sn?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLocation = filterLocation === "all" || comp.current_location === filterLocation;
    const matchesStatus = filterStatus === "all" || comp.status === filterStatus;
    return matchesSearch && matchesLocation && matchesStatus;
  });

  const exportColumns = [
    { label: 'Serienummer', accessor: (item) => item.serial_number },
    { label: 'Produkt', accessor: (item) => item.product_name },
    { label: 'SKU', accessor: (item) => item.product_sku },
    { label: 'Producentens S/N', accessor: (item) => item.manufacturer_sn || '-' },
    { label: 'Lokation', accessor: (item) => item.current_location },
    { label: 'Projekt', accessor: (item) => item.current_project_name || '-' },
    { label: 'Status', accessor: (item) => item.status },
    { label: 'Tilstand', accessor: (item) => item.condition },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Master Tracker</h2>
          <p className="text-slate-500 mt-1">Traceability & serienummer tracking - aflæser automatisk fra QA/QC</p>
        </div>
        <div className="flex gap-3">
          <ExportButton 
            data={filteredComponents}
            filename={`master-tracker-${new Date().toISOString().split('T')[0]}`}
            columns={exportColumns}
          />
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" onClick={() => {
                setEditingComponent(null);
                setPhotos([]);
              }}>
                <Plus className="w-4 h-4 mr-2" />
                Manuel Registrering
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Manuel Registrering</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <Alert className="bg-blue-50 border-blue-200">
                  <AlertCircle className="w-4 h-4 text-blue-600" />
                  <AlertDescription className="text-blue-800">
                    Normalt importeres serienumre automatisk fra QA/QC inspektioner. Brug kun manuel registrering hvis nødvendigt.
                  </AlertDescription>
                </Alert>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="serial_number">Serienummer *</Label>
                    <Input 
                      id="serial_number" 
                      name="serial_number" 
                      placeholder="F.eks. SN-2024-001"
                      required 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="manufacturer_sn">Producentens S/N</Label>
                    <Input id="manufacturer_sn" name="manufacturer_sn" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="product_id">Produkt *</Label>
                  <Select name="product_id" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Vælg produkt" />
                    </SelectTrigger>
                    <SelectContent>
                      {products.map(product => (
                        <SelectItem key={product.id} value={product.id}>
                          {product.name} ({product.sku})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="current_location">Lokation *</Label>
                    <Select name="current_location" defaultValue={locations[0]?.name}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {locations.map(loc => (
                          <SelectItem key={loc.id} value={loc.name}>{loc.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="status">Status *</Label>
                    <Select name="status" defaultValue="in_stock">
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="in_stock">På lager</SelectItem>
                        <SelectItem value="deployed">Udstationeret</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="condition">Tilstand</Label>
                    <Select name="condition" defaultValue="good">
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="excellent">Fremragende</SelectItem>
                        <SelectItem value="good">God</SelectItem>
                        <SelectItem value="fair">Rimelig</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="registered_by">Registreret af</Label>
                  <Input id="registered_by" name="registered_by" placeholder="Dit navn" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Noter</Label>
                  <Textarea id="notes" name="notes" rows={2} />
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    Annuller
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    Registrer
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Unregistered SNs Alert */}
      {unregisteredSNs.length > 0 && (
        <Alert className="bg-yellow-50 border-yellow-200">
          <AlertCircle className="w-4 h-4 text-yellow-600" />
          <AlertDescription>
            <div className="flex items-center justify-between">
              <div>
                <strong className="text-yellow-900">
                  {unregisteredSNs.length} godkendte serienumre fra QA/QC venter på import
                </strong>
                <p className="text-sm text-yellow-800 mt-1">
                  Klik på "Importer" for at registrere dem i Master Tracker
                </p>
              </div>
            </div>
            <div className="mt-3 space-y-2">
              {unregisteredSNs.slice(0, 5).map((item, idx) => (
                <div key={idx} className="flex items-center justify-between p-2 bg-white rounded border border-yellow-200">
                  <div className="flex items-center gap-3">
                    <QrCode className="w-4 h-4 text-yellow-600" />
                    <div>
                      <div className="font-mono font-semibold text-sm">{item.serial_number}</div>
                      <div className="text-xs text-slate-600">{item.product_name} ({item.product_sku})</div>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => importFromQI(item)}
                    className="bg-yellow-600 hover:bg-yellow-700"
                  >
                    <Download className="w-4 h-4 mr-1" />
                    Importer
                  </Button>
                </div>
              ))}
              {unregisteredSNs.length > 5 && (
                <p className="text-xs text-yellow-700 text-center pt-2">
                  + {unregisteredSNs.length - 5} flere...
                </p>
              )}
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <Package className="w-4 h-4" />
              Total Registreret
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{components.length}</div>
            <p className="text-xs text-slate-500 mt-1">Serienumre</p>
          </CardContent>
        </Card>

        <Card className="border-blue-200/60 bg-blue-50/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-blue-600" />
              Udstationeret
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {components.filter(c => c.status === 'deployed').length}
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200/60 bg-green-50/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-green-600" />
              På lager
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {components.filter(c => c.status === 'in_stock').length}
            </div>
          </CardContent>
        </Card>

        <Card className="border-yellow-200/60 bg-yellow-50/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-yellow-600" />
              Venter import
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {unregisteredSNs.length}
            </div>
            <p className="text-xs text-slate-500 mt-1">Fra QA/QC</p>
          </CardContent>
        </Card>
      </div>

      {/* Components Table */}
      <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
        <CardHeader className="border-b border-slate-200/60">
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                placeholder="Søg efter S/N, produkt eller SKU..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-3">
              <Select value={filterLocation} onValueChange={setFilterLocation}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle lokationer</SelectItem>
                  {locations.map(loc => (
                    <SelectItem key={loc.id} value={loc.name}>{loc.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle status</SelectItem>
                  <SelectItem value="in_stock">På lager</SelectItem>
                  <SelectItem value="deployed">Udstationeret</SelectItem>
                  <SelectItem value="under_repair">Reparation</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead>Serienummer</TableHead>
                <TableHead>Produkt</TableHead>
                <TableHead>Lokation</TableHead>
                <TableHead>Projekt</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Kilde</TableHead>
                <TableHead className="text-right">Handlinger</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredComponents.map((comp) => {
                const isImported = comp.history?.[0]?.action === 'imported_from_qi';
                return (
                  <TableRow key={comp.id} className="hover:bg-slate-50">
                    <TableCell>
                      <div className="font-mono font-semibold">{comp.serial_number}</div>
                      {comp.manufacturer_sn && (
                        <div className="text-xs text-slate-500">Prod: {comp.manufacturer_sn}</div>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{comp.product_name}</div>
                      <div className="text-sm text-slate-500">{comp.product_sku}</div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="gap-1">
                        <MapPin className="w-3 h-3" />
                        {comp.current_location}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {comp.current_project_name || <span className="text-slate-400">-</span>}
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(comp.status)}>
                        {comp.status.replace(/_/g, ' ')}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {isImported ? (
                        <Badge className="bg-blue-100 text-blue-800 gap-1">
                          <ExternalLink className="w-3 h-3" />
                          QA/QC
                        </Badge>
                      ) : (
                        <Badge variant="outline">Manuel</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setSelectedComponent(comp);
                            setHistoryDialogOpen(true);
                          }}
                        >
                          <History className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedComponent(comp);
                            setMoveDialogOpen(true);
                          }}
                        >
                          <ArrowRight className="w-4 h-4 mr-1" />
                          Flyt
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          {filteredComponents.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <Package className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>Ingen komponenter fundet</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* History Dialog */}
      <Dialog open={historyDialogOpen} onOpenChange={setHistoryDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Historik - {selectedComponent?.serial_number}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {selectedComponent?.history?.length > 0 ? (
              selectedComponent.history.map((entry, idx) => (
                <div key={idx} className="flex gap-4 border-l-2 border-blue-200 pl-4 py-2">
                  <div className="flex-shrink-0">
                    <Calendar className="w-5 h-5 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline">{entry.action.replace(/_/g, ' ')}</Badge>
                      <span className="text-sm text-slate-500">{entry.date}</span>
                    </div>
                    {entry.from_location && entry.to_location && (
                      <div className="text-sm">
                        {entry.from_location} → {entry.to_location}
                      </div>
                    )}
                    {entry.project && (
                      <div className="text-sm text-slate-600">Projekt: {entry.project}</div>
                    )}
                    {entry.notes && (
                      <div className="text-sm text-slate-500 mt-1">{entry.notes}</div>
                    )}
                    {entry.performed_by && (
                      <div className="text-xs text-slate-400 mt-1">Udført af: {entry.performed_by}</div>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <p className="text-slate-500 text-center py-8">Ingen historik endnu</p>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Move Dialog */}
      <Dialog open={moveDialogOpen} onOpenChange={setMoveDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Flyt Komponent - {selectedComponent?.serial_number}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleMove} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="action">Handling *</Label>
                <Select name="action" defaultValue="moved">
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="moved">Flyttet</SelectItem>
                    <SelectItem value="installed">Installeret</SelectItem>
                    <SelectItem value="removed">Fjernet</SelectItem>
                    <SelectItem value="shipped">Afsendt</SelectItem>
                    <SelectItem value="received">Modtaget</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="new_status">Ny Status *</Label>
                <Select name="new_status" defaultValue={selectedComponent?.status}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="in_stock">På lager</SelectItem>
                    <SelectItem value="deployed">Udstationeret</SelectItem>
                    <SelectItem value="in_transit">I transit</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="new_location">Ny Lokation *</Label>
                <Select name="new_location" defaultValue={selectedComponent?.current_location}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {locations.map(loc => (
                      <SelectItem key={loc.id} value={loc.name}>{loc.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="new_project_id">Projekt</Label>
                <Select name="new_project_id" defaultValue={selectedComponent?.current_project_id}>
                  <SelectTrigger>
                    <SelectValue placeholder="Vælg (valgfrit)" />
                  </SelectTrigger>
                  <SelectContent>
                    {projects.map(project => (
                      <SelectItem key={project.id} value={project.id}>
                        {project.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="performed_by">Udført af *</Label>
              <Input id="performed_by" name="performed_by" placeholder="Dit navn" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Noter</Label>
              <Textarea id="notes" name="notes" rows={2} />
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setMoveDialogOpen(false)}>
                Annuller
              </Button>
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                Bekræft
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}