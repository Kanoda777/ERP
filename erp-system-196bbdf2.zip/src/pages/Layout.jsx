
import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
        LayoutDashboard, 
        Package, 
        Truck, 
        ShoppingCart, 
        ShoppingBag,
        Factory,
        Bell,
        User,
        Languages,
        Settings as SettingsIcon,
        Settings,
        Briefcase,
        MapPin,
        Wrench,
        RefreshCw,
        ClipboardCheck,
        Box,
        QrCode,
        Calendar as CalendarIcon
      } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { LanguageProvider, useLanguage } from "@/components/LanguageContext";

function LayoutContent({ children, currentPageName }) {
  const location = useLocation();
  const { language, setLanguage, t } = useLanguage();

  const navigationItems = [
    {
      title: t('dashboard'),
      url: createPageUrl("Dashboard"),
      icon: LayoutDashboard,
    },
    {
      title: 'Master Tracker',
      url: createPageUrl("MasterTracker"),
      icon: QrCode,
    },
    {
      title: t('inventory'),
      url: createPageUrl("Inventory"),
      icon: Package,
    },
    {
      title: 'Komponenter',
      url: createPageUrl("Components"),
      icon: Settings,
    },
    {
      title: t('tools') || 'Værktøj',
      url: createPageUrl("Tools"),
      icon: Wrench,
    },
    {
      title: t('testEquipment') || 'Test Udstyr',
      url: createPageUrl("TestEquipment"),
      icon: Box,
    },
    {
      title: 'Lokations Kalender',
      url: createPageUrl("LocationCalendar"),
      icon: CalendarIcon,
    },
    {
      title: t('qualityInspections') || 'QA/QC',
      url: createPageUrl("QualityInspections"),
      icon: ClipboardCheck,
    },
    {
      title: t('autoReorder') || 'Auto-Genbestilling',
      url: createPageUrl("AutoReorder"),
      icon: RefreshCw,
    },
    {
      title: t('projects') || 'Projekter & O&M',
      url: createPageUrl("Projects"),
      icon: Briefcase,
    },
    {
      title: t('centralSpares') || 'Centrale Reservedele',
      url: createPageUrl("SparePartsCentral"),
      icon: Wrench,
    },
    {
      title: t('locations') || 'Lokationer',
      url: createPageUrl("Locations"),
      icon: MapPin,
    },
    {
      title: t('suppliers'),
      url: createPageUrl("Suppliers"),
      icon: Truck,
    },
    {
      title: t('purchases'),
      url: createPageUrl("Purchases"),
      icon: ShoppingCart,
    },
    {
      title: t('sales'),
      url: createPageUrl("Sales"),
      icon: ShoppingBag,
    },
    {
      title: t('production'),
      url: createPageUrl("Production"),
      icon: Factory,
    },
    {
      title: t('settings') || 'Indstillinger',
      url: createPageUrl("Settings"),
      icon: SettingsIcon,
    },
  ];

  const languageNames = {
    da: 'Dansk',
    en: 'English',
    pl: 'Polski'
  };

  return (
    <SidebarProvider>
      <style>{`
        :root {
          --primary: 217 91% 60%;
          --primary-foreground: 0 0% 100%;
          --secondary: 217 20% 95%;
          --accent: 217 40% 90%;
        }
      `}</style>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-slate-50 via-blue-50 to-slate-50">
        <Sidebar className="border-r border-slate-200/60 bg-white/80 backdrop-blur-xl">
          <SidebarHeader className="border-b border-slate-200/60 p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
                <Factory className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-slate-900 text-lg">ERP System</h2>
                <p className="text-xs text-slate-500">
                  {language === 'da' ? 'Virksomhedsstyring' : language === 'en' ? 'Business Management' : 'Zarządzanie Firmą'}
                </p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-3">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 py-2 mb-1">
                {language === 'da' ? 'Navigation' : language === 'en' ? 'Navigation' : 'Nawigacja'}
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu className="space-y-1">
                  {navigationItems.map((item) => {
                    const isActive = location.pathname === item.url;
                    return (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton 
                          asChild 
                          className={`transition-all duration-200 rounded-xl ${
                            isActive 
                              ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg shadow-blue-500/30' 
                              : 'hover:bg-slate-100 text-slate-700'
                          }`}
                        >
                          <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                            <item.icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                            <span className="font-medium">{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-white/80 backdrop-blur-xl border-b border-slate-200/60 px-6 py-4 sticky top-0 z-10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <SidebarTrigger className="lg:hidden hover:bg-slate-100 p-2 rounded-lg transition-colors" />
                <div>
                  <h1 className="text-2xl font-bold text-slate-900">{currentPageName}</h1>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="flex items-center gap-2 p-2 hover:bg-slate-100 rounded-lg transition-colors">
                      <Languages className="w-5 h-5 text-slate-600" />
                      <span className="text-sm font-medium text-slate-700">{languageNames[language]}</span>
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => setLanguage('da')} className="cursor-pointer">
                      🇩🇰 Dansk
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setLanguage('en')} className="cursor-pointer">
                      🇬🇧 English
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setLanguage('pl')} className="cursor-pointer">
                      🇵🇱 Polski
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <button className="relative p-2 hover:bg-slate-100 rounded-lg transition-colors">
                  <Bell className="w-5 h-5 text-slate-600" />
                  <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                </button>
                <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
                  <User className="w-5 h-5 text-slate-600" />
                </button>
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-auto p-6">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}

export default function Layout({ children, currentPageName }) {
  return (
    <LanguageProvider>
      <LayoutContent children={children} currentPageName={currentPageName} />
    </LanguageProvider>
  );
}
