import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Plus,
  ClipboardCheck,
  CheckCircle2,
  XCircle,
  Clock,
  AlertTriangle,
  Camera,
  FileText,
  Upload,
  Download,
  Trash2,
  Loader2,
  Package,
  Eye
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useLanguage } from "@/components/LanguageContext";
import ExportButton from "@/components/ExportButton";
import InspectionViewDialog from "@/components/quality/InspectionViewDialog";
import { format } from "date-fns";

export default function QualityInspections() {
  const { t } = useLanguage();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [editingInspection, setEditingInspection] = useState(null);
  const [viewingInspection, setViewingInspection] = useState(null);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [uploadingCert, setUploadingCert] = useState(false);
  const [photos, setPhotos] = useState([]);
  const [certificates, setCertificates] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [productNameInput, setProductNameInput] = useState("");
  const queryClient = useQueryClient();

  const { data: inspections = [] } = useQuery({
    queryKey: ['qualityInspections'],
    queryFn: () => base44.entities.QualityInspection.list('-created_date'),
  });

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
  });

  const { data: purchaseOrders = [] } = useQuery({
    queryKey: ['purchaseOrders'],
    queryFn: () => base44.entities.PurchaseOrder.list('-created_date'),
  });

  // Auto-fill SKU when product name changes
  useEffect(() => {
    if (productNameInput && !editingInspection) {
      const matchedProduct = products.find(p => 
        p.name.toLowerCase() === productNameInput.toLowerCase() ||
        p.sku.toLowerCase() === productNameInput.toLowerCase()
      );
      
      if (matchedProduct) {
        setSelectedProduct(matchedProduct);
        const skuInput = document.getElementById('product_sku');
        if (skuInput) {
          skuInput.value = matchedProduct.sku;
        }
      } else {
        setSelectedProduct(null);
      }
    }
  }, [productNameInput, products, editingInspection]);

  const createInspectionMutation = useMutation({
    mutationFn: (data) => base44.entities.QualityInspection.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['qualityInspections']);
      setDialogOpen(false);
      setEditingInspection(null);
      setPhotos([]);
      setCertificates([]);
      setSelectedProduct(null);
      setProductNameInput("");
    },
  });

  const updateInspectionMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.QualityInspection.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['qualityInspections']);
      setDialogOpen(false);
      setEditingInspection(null);
      setPhotos([]);
      setCertificates([]);
      setSelectedProduct(null);
      setProductNameInput("");
    },
  });

  const deleteInspectionMutation = useMutation({
    mutationFn: (id) => base44.entities.QualityInspection.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['qualityInspections']);
    },
  });

  const handlePhotoUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setUploadingPhoto(true);
    try {
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        const photo = {
          url: file_url,
          caption: file.name,
          uploaded_date: format(new Date(), 'yyyy-MM-dd'),
        };
        setPhotos(prev => [...prev, photo]);
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Fejl ved upload af billede');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleCertUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setUploadingCert(true);
    try {
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        const cert = {
          name: file.name,
          url: file_url,
          type: 'quality',
          uploaded_date: format(new Date(), 'yyyy-MM-dd'),
        };
        setCertificates(prev => [...prev, cert]);
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Fejl ved upload af certifikat');
    } finally {
      setUploadingCert(false);
    }
  };

  const handleRemovePhoto = (index) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const handleRemoveCert = (index) => {
    setCertificates(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    
    const data = {
      purchase_order_id: formData.get('purchase_order_id') || '',
      purchase_order_number: formData.get('purchase_order_number') || '',
      product_id: selectedProduct?.id || '',
      product_name: formData.get('product_name'),
      product_sku: formData.get('product_sku') || '',
      quantity_received: parseFloat(formData.get('quantity_received')),
      inspection_date: formData.get('inspection_date'),
      inspector: formData.get('inspector'),
      added_by: formData.get('added_by'),
      status: formData.get('status'),
      visual_inspection: formData.get('visual_inspection'),
      functional_test: formData.get('functional_test'),
      dimensions_check: formData.get('dimensions_check'),
      packaging_condition: formData.get('packaging_condition'),
      serial_number: formData.get('serial_number'),
      batch_number: formData.get('batch_number'),
      supplier_batch_ref: formData.get('supplier_batch_ref'),
      photos: photos,
      certificates: certificates,
      notes: formData.get('notes'),
      deviation_report: formData.get('deviation_report'),
      corrective_actions: formData.get('corrective_actions'),
    };

    if (data.status === 'approved') {
      data.approved_by = formData.get('inspector');
      data.approved_date = format(new Date(), 'yyyy-MM-dd');
    }

    if (editingInspection) {
      updateInspectionMutation.mutate({ id: editingInspection.id, data });
    } else {
      createInspectionMutation.mutate(data);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved': return <CheckCircle2 className="w-4 h-4" />;
      case 'rejected': return <XCircle className="w-4 h-4" />;
      case 'conditional': return <AlertTriangle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-800",
      approved: "bg-green-100 text-green-800",
      rejected: "bg-red-100 text-red-800",
      conditional: "bg-orange-100 text-orange-800",
    };
    return colors[status] || colors.pending;
  };

  const pendingCount = inspections.filter(i => i.status === 'pending').length;
  const approvedCount = inspections.filter(i => i.status === 'approved').length;
  const rejectedCount = inspections.filter(i => i.status === 'rejected').length;

  const handleDelete = (inspection) => {
    const code = prompt('Indtast admin kode for at slette:');
    if (code === 'DDigital') {
      if (confirm(`Er du sikker på at du vil slette inspektion for "${inspection.product_name}"?`)) {
        deleteInspectionMutation.mutate(inspection.id);
      }
    } else if (code !== null) {
      alert('Forkert admin kode');
    }
  };

  const exportColumns = [
    { label: t('date') || 'Dato', accessor: (item) => format(new Date(item.inspection_date), 'dd/MM/yyyy') },
    { label: t('product'), accessor: (item) => item.product_name },
    { label: 'SKU', accessor: (item) => item.product_sku },
    { label: t('quantity'), accessor: (item) => item.quantity_received },
    { label: t('inspector') || 'Inspektør', accessor: (item) => item.inspector },
    { label: t('status'), accessor: (item) => t(item.status) },
    { label: t('visualInspection') || 'Visuel', accessor: (item) => item.visual_inspection || '-' },
    { label: t('functionalTest') || 'Funktionstest', accessor: (item) => item.functional_test || '-' },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">{t('qualityInspections') || 'Kvalitetsinspektioner'}</h2>
          <p className="text-slate-500 mt-1">{t('manageQualityControl') || 'QA/QC af modtagne komponenter'}</p>
        </div>
        <div className="flex gap-3">
          <ExportButton
            data={inspections}
            filename={`quality-inspections-${new Date().toISOString().split('T')[0]}`}
            columns={exportColumns}
          />
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => {
                setEditingInspection(null);
                setPhotos([]);
                setCertificates([]);
                setSelectedProduct(null);
                setProductNameInput("");
              }}>
                <Plus className="w-4 h-4 mr-2" />
                {t('newInspection') || 'Ny Inspektion'}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingInspection ? t('editInspection') : t('newInspection') || 'Ny Kvalitetsinspektion'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="product_name">{t('product')} *</Label>
                    <Input
                      id="product_name"
                      name="product_name"
                      list="products-list"
                      defaultValue={editingInspection?.product_name}
                      placeholder="Skriv produktnavn eller vælg fra liste..."
                      onChange={(e) => setProductNameInput(e.target.value)}
                      required
                    />
                    <datalist id="products-list">
                      {products.map(product => (
                        <option key={product.id} value={product.name}>
                          {product.sku}
                        </option>
                      ))}
                    </datalist>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="product_sku">SKU {selectedProduct && '✓'}</Label>
                    <Input
                      id="product_sku"
                      name="product_sku"
                      defaultValue={editingInspection?.product_sku}
                      placeholder="Udfyldes automatisk..."
                      className={selectedProduct ? "bg-green-50 border-green-200" : ""}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="purchase_order_number">{t('orderNumber') || 'Ordrenummer'}</Label>
                  <Input
                    id="purchase_order_number"
                    name="purchase_order_number"
                    defaultValue={editingInspection?.purchase_order_number}
                    placeholder="PO-123456"
                  />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="quantity_received">{t('quantityReceived') || 'Modtaget antal'} *</Label>
                    <Input
                      id="quantity_received"
                      name="quantity_received"
                      type="number"
                      defaultValue={editingInspection?.quantity_received}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="inspection_date">{t('inspectionDate') || 'Inspektionsdato'} *</Label>
                    <Input
                      id="inspection_date"
                      name="inspection_date"
                      type="date"
                      defaultValue={editingInspection?.inspection_date || format(new Date(), 'yyyy-MM-dd')}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="inspector">{t('inspector') || 'Inspektør'} *</Label>
                    <Input
                      id="inspector"
                      name="inspector"
                      defaultValue={editingInspection?.inspector}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="added_by">{t('addedBy') || 'Tilføjet af'}</Label>
                  <Input id="added_by" name="added_by" defaultValue={editingInspection?.added_by} placeholder={t('yourName') || 'Dit navn'} />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="serial_number">{t('serialNumber') || 'Serienummer'}</Label>
                    <Input
                      id="serial_number"
                      name="serial_number"
                      defaultValue={editingInspection?.serial_number}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="batch_number">{t('batchNumber')}</Label>
                    <Input
                      id="batch_number"
                      name="batch_number"
                      defaultValue={editingInspection?.batch_number}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="supplier_batch_ref">{t('supplierBatchRef') || 'Leverandør Batch'}</Label>
                    <Input
                      id="supplier_batch_ref"
                      name="supplier_batch_ref"
                      defaultValue={editingInspection?.supplier_batch_ref}
                    />
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h3 className="text-lg font-semibold mb-4">{t('inspectionResults') || 'Inspektionsresultater'}</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="visual_inspection">{t('visualInspection') || 'Visuel Inspektion'}</Label>
                      <Select name="visual_inspection" defaultValue={editingInspection?.visual_inspection || 'ok'}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ok">✅ OK</SelectItem>
                          <SelectItem value="minor_issues">⚠️ {t('minorIssues') || 'Mindre problemer'}</SelectItem>
                          <SelectItem value="not_ok">❌ {t('notOk') || 'Ikke OK'}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="functional_test">{t('functionalTest') || 'Funktionstest'}</Label>
                      <Select name="functional_test" defaultValue={editingInspection?.functional_test || 'not_applicable'}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="passed">✅ {t('passed') || 'Bestået'}</SelectItem>
                          <SelectItem value="failed">❌ {t('failed') || 'Fejlet'}</SelectItem>
                          <SelectItem value="not_applicable">➖ {t('notApplicable') || 'Ikke relevant'}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="dimensions_check">{t('dimensionsCheck') || 'Dimensionskontrol'}</Label>
                      <Select name="dimensions_check" defaultValue={editingInspection?.dimensions_check || 'not_checked'}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ok">✅ OK</SelectItem>
                          <SelectItem value="not_ok">❌ {t('notOk') || 'Ikke OK'}</SelectItem>
                          <SelectItem value="not_checked">➖ {t('notChecked') || 'Ikke kontrolleret'}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="packaging_condition">{t('packagingCondition') || 'Emballage tilstand'}</Label>
                      <Select name="packaging_condition" defaultValue={editingInspection?.packaging_condition || 'intact'}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="intact">✅ {t('intact') || 'Intakt'}</SelectItem>
                          <SelectItem value="minor_damage">⚠️ {t('minorDamage') || 'Mindre skader'}</SelectItem>
                          <SelectItem value="major_damage">❌ {t('majorDamage') || 'Alvorlige skader'}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Photos Section */}
                <div className="space-y-2 p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2">
                      <Camera className="w-4 h-4" />
                      {t('inspectionPhotos') || 'Inspektionsfotos'}
                    </Label>
                    <label htmlFor="photo-upload" className="cursor-pointer">
                      <div className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                        {uploadingPhoto ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            {t('uploading')}...
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4" />
                            {t('uploadPhoto') || 'Upload Foto'}
                          </>
                        )}
                      </div>
                      <input
                        id="photo-upload"
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={handlePhotoUpload}
                        className="hidden"
                        disabled={uploadingPhoto}
                      />
                    </label>
                  </div>

                  {photos.length > 0 ? (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
                      {photos.map((photo, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={photo.url}
                            alt={photo.caption}
                            className="w-full h-32 object-cover rounded border border-slate-200"
                          />
                          <Button
                            type="button"
                            size="sm"
                            variant="destructive"
                            className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => handleRemovePhoto(index)}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                          <p className="text-xs text-slate-600 mt-1 truncate">{photo.caption}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-slate-500 text-center py-4">
                      {t('noPhotosYet') || 'Ingen fotos uploadet endnu'}
                    </p>
                  )}
                </div>

                {/* Certificates Section */}
                <div className="space-y-2 p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      {t('certificates') || 'Certifikater'}
                    </Label>
                    <label htmlFor="cert-upload" className="cursor-pointer">
                      <div className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                        {uploadingCert ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            {t('uploading')}...
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4" />
                            {t('uploadCertificate') || 'Upload Certifikat'}
                          </>
                        )}
                      </div>
                      <input
                        id="cert-upload"
                        type="file"
                        multiple
                        accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                        onChange={handleCertUpload}
                        className="hidden"
                        disabled={uploadingCert}
                      />
                    </label>
                  </div>

                  {certificates.length > 0 ? (
                    <div className="space-y-2 mt-3">
                      {certificates.map((cert, index) => (
                        <div key={index} className="flex items-center justify-between p-2 bg-white rounded border border-slate-200">
                          <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4 text-blue-600" />
                            <div>
                              <div className="text-sm font-medium">{cert.name}</div>
                              <div className="text-xs text-slate-500">{cert.uploaded_date}</div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <a href={cert.url} target="_blank" rel="noopener noreferrer">
                              <Button type="button" size="sm" variant="ghost">
                                <Download className="w-4 h-4" />
                              </Button>
                            </a>
                            <Button
                              type="button"
                              size="sm"
                              variant="ghost"
                              onClick={() => handleRemoveCert(index)}
                            >
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-slate-500 text-center py-4">
                      {t('noCertificatesYet') || 'Ingen certifikater uploadet endnu'}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">{t('notes')}</Label>
                  <Textarea
                    id="notes"
                    name="notes"
                    placeholder={t('inspectionNotes') || 'Inspektionsnoter...'}
                    defaultValue={editingInspection?.notes}
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="deviation_report">{t('deviationReport') || 'Afvigelsesrapport'}</Label>
                  <Textarea
                    id="deviation_report"
                    name="deviation_report"
                    placeholder={t('deviationReportPlaceholder') || 'Beskriv eventuelle afvigelser...'}
                    defaultValue={editingInspection?.deviation_report}
                    rows={2}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="corrective_actions">{t('correctiveActions') || 'Korrigerende handlinger'}</Label>
                  <Textarea
                    id="corrective_actions"
                    name="corrective_actions"
                    placeholder={t('correctiveActionsPlaceholder') || 'Hvilke handlinger er taget...'}
                    defaultValue={editingInspection?.corrective_actions}
                    rows={2}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="status">{t('finalStatus') || 'Endelig Status'} *</Label>
                  <Select name="status" defaultValue={editingInspection?.status || 'pending'}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          {t('pending')}
                        </div>
                      </SelectItem>
                      <SelectItem value="approved">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          {t('approved')}
                        </div>
                      </SelectItem>
                      <SelectItem value="conditional">
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 text-orange-600" />
                          {t('conditional') || 'Betinget godkendt'}
                        </div>
                      </SelectItem>
                      <SelectItem value="rejected">
                        <div className="flex items-center gap-2">
                          <XCircle className="w-4 h-4 text-red-600" />
                          {t('rejected')}
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    {t('cancel')}
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    {editingInspection ? t('saveChanges') : t('createInspection') || 'Opret inspektion'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <ClipboardCheck className="w-4 h-4" />
              {t('totalInspections') || 'Total Inspektioner'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">{inspections.length}</div>
          </CardContent>
        </Card>

        <Card className="border-yellow-200/60 bg-yellow-50/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <Clock className="w-4 h-4 text-yellow-600" />
              {t('pending')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{pendingCount}</div>
          </CardContent>
        </Card>

        <Card className="border-green-200/60 bg-green-50/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-600" />
              {t('approved')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{approvedCount}</div>
          </CardContent>
        </Card>

        <Card className="border-red-200/60 bg-red-50/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <XCircle className="w-4 h-4 text-red-600" />
              {t('rejected')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{rejectedCount}</div>
          </CardContent>
        </Card>
      </div>

      {/* Inspections Table */}
      <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
        <CardHeader className="border-b border-slate-200/60">
          <CardTitle>{t('allInspections') || 'Alle Inspektioner'}</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead>{t('date')}</TableHead>
                <TableHead>{t('product')}</TableHead>
                <TableHead>{t('quantity')}</TableHead>
                <TableHead>{t('inspector') || 'Inspektør'}</TableHead>
                <TableHead className="text-center">{t('photos') || 'Fotos'}</TableHead>
                <TableHead className="text-center">{t('certificates') || 'Certifikater'}</TableHead>
                <TableHead>{t('status')}</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {inspections.map((inspection) => (
                <TableRow
                  key={inspection.id}
                  className="hover:bg-slate-50 cursor-pointer"
                  onClick={() => {
                    setViewingInspection(inspection);
                    setViewDialogOpen(true);
                  }}
                >
                  <TableCell>
                    {format(new Date(inspection.inspection_date), 'dd/MM/yyyy')}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Package className="w-4 h-4 text-slate-400" />
                      <div>
                        <div className="font-medium">{inspection.product_name}</div>
                        <div className="text-sm text-slate-500">{inspection.product_sku}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{inspection.quantity_received}</TableCell>
                  <TableCell>{inspection.inspector}</TableCell>
                  <TableCell className="text-center">
                    {inspection.photos?.length > 0 ? (
                      <Badge className="bg-blue-100 text-blue-800">
                        <Camera className="w-3 h-3 mr-1" />
                        {inspection.photos.length}
                      </Badge>
                    ) : (
                      <span className="text-slate-400">-</span>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    {inspection.certificates?.length > 0 ? (
                      <Badge className="bg-purple-100 text-purple-800">
                        <FileText className="w-3 h-3 mr-1" />
                        {inspection.certificates.length}
                      </Badge>
                    ) : (
                      <span className="text-slate-400">-</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(inspection.status)}>
                      {getStatusIcon(inspection.status)}
                      <span className="ml-1">{t(inspection.status)}</span>
                    </Badge>
                  </TableCell>
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      onClick={() => handleDelete(inspection)} 
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {inspections.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <ClipboardCheck className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>{t('noInspectionsYet') || 'Ingen inspektioner endnu'}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Dialog */}
      <InspectionViewDialog
        inspection={viewingInspection}
        open={viewDialogOpen}
        onClose={() => {
          setViewDialogOpen(false);
          setViewingInspection(null);
        }}
        onEdit={(inspection) => {
          setEditingInspection(inspection);
          setPhotos(inspection.photos || []);
          setCertificates(inspection.certificates || []);
          const matchedProduct = products.find(p => p.id === inspection.product_id);
          setSelectedProduct(matchedProduct || { id: inspection.product_id || '', sku: inspection.product_sku || '' });
          setProductNameInput(inspection.product_name || '');
          setDialogOpen(true);
          setViewDialogOpen(false);
        }}
      />
    </div>
  );
}