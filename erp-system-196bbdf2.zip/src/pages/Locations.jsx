import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, MapPin, Mail, Phone, Edit, Warehouse } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useLanguage } from "@/components/LanguageContext";

export default function Locations() {
  const { t } = useLanguage();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingLocation, setEditingLocation] = useState(null);
  const queryClient = useQueryClient();

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.Location.list('-created_date'),
  });

  const createLocationMutation = useMutation({
    mutationFn: (data) => base44.entities.Location.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['locations']);
      setDialogOpen(false);
      setEditingLocation(null);
    },
  });

  const updateLocationMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Location.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['locations']);
      setDialogOpen(false);
      setEditingLocation(null);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = {
      name: formData.get('name'),
      type: formData.get('type'),
      address: formData.get('address'),
      contact_person: formData.get('contact_person'),
      phone: formData.get('phone'),
      email: formData.get('email'),
      notes: formData.get('notes'),
      status: formData.get('status'),
    };

    if (editingLocation) {
      updateLocationMutation.mutate({ id: editingLocation.id, data });
    } else {
      createLocationMutation.mutate(data);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">{t('locations') || 'Lagerlokationer'}</h2>
          <p className="text-slate-500 mt-1">{t('manageLocations') || 'Administrer dine lagerlokationer'}</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setEditingLocation(null)}>
              <Plus className="w-4 h-4 mr-2" />
              {t('addLocation') || 'Tilføj Lokation'}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingLocation ? (t('editLocation') || 'Rediger Lokation') : (t('newLocation') || 'Ny Lokation')}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">{t('locationName') || 'Lokationsnavn'} *</Label>
                  <Input id="name" name="name" defaultValue={editingLocation?.name} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="type">{t('locationType') || 'Type'} *</Label>
                  <Select name="type" defaultValue={editingLocation?.type || 'main_warehouse'}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="main_warehouse">{t('main_warehouse') || 'Hovedlager'}</SelectItem>
                      <SelectItem value="customer_site">{t('customer_site') || 'Kundelokation'}</SelectItem>
                      <SelectItem value="project_site">{t('project_site') || 'Projektlokation'}</SelectItem>
                      <SelectItem value="other">{t('other')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">{t('address')}</Label>
                <Input id="address" name="address" defaultValue={editingLocation?.address} />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="contact_person">{t('contactPerson')}</Label>
                  <Input id="contact_person" name="contact_person" defaultValue={editingLocation?.contact_person} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">{t('phone')}</Label>
                  <Input id="phone" name="phone" defaultValue={editingLocation?.phone} />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">{t('email')}</Label>
                <Input id="email" name="email" type="email" defaultValue={editingLocation?.email} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">{t('status')}</Label>
                <Select name="status" defaultValue={editingLocation?.status || 'active'}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">{t('active')}</SelectItem>
                    <SelectItem value="inactive">{t('inactive')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">{t('notes')}</Label>
                <Textarea id="notes" name="notes" defaultValue={editingLocation?.notes} rows={2} />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  {t('cancel')}
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  {editingLocation ? t('saveChanges') : (t('createLocation') || 'Opret lokation')}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {locations.map((location) => (
          <Card key={location.id} className="hover:shadow-lg transition-all border-slate-200">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg shadow-green-500/30">
                    <Warehouse className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900">{location.name}</h3>
                    <p className="text-sm text-slate-500">{t(location.type)}</p>
                  </div>
                </div>
                <Badge variant={location.status === 'active' ? 'default' : 'secondary'}>
                  {t(location.status)}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {location.address && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <MapPin className="w-4 h-4 text-slate-400" />
                  <span className="truncate">{location.address}</span>
                </div>
              )}
              {location.contact_person && (
                <div className="text-sm text-slate-600">
                  <span className="font-medium">{t('contactPerson')}:</span> {location.contact_person}
                </div>
              )}
              {location.phone && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Phone className="w-4 h-4 text-slate-400" />
                  <span>{location.phone}</span>
                </div>
              )}
              {location.email && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Mail className="w-4 h-4 text-slate-400" />
                  <span className="truncate">{location.email}</span>
                </div>
              )}
              <Button
                variant="outline"
                size="sm"
                className="w-full mt-4"
                onClick={() => {
                  setEditingLocation(location);
                  setDialogOpen(true);
                }}
              >
                <Edit className="w-4 h-4 mr-2" />
                {t('edit')}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {locations.length === 0 && (
        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardContent className="text-center py-12 text-slate-500">
            <Warehouse className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p>{t('noLocations') || 'Ingen lokationer endnu'}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}