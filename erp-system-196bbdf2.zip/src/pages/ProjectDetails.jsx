import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Plus, Package, Trash2, Calendar, Edit, Info, Settings, Download, FileText, Wrench } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format } from "date-fns";
import { useLanguage } from "@/components/LanguageContext";
import ExportButton from "@/components/ExportButton";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function ProjectDetails() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const projectId = urlParams.get('id');
  
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [componentDialogOpen, setComponentDialogOpen] = useState(false);
  const [selectedTab, setSelectedTab] = useState('inventory');
  const queryClient = useQueryClient();

  const { data: project } = useQuery({
    queryKey: ['project', projectId],
    queryFn: async () => {
      const projects = await base44.entities.Project.list();
      return projects.find(p => p.id === projectId);
    },
    enabled: !!projectId,
  });

  const { data: projectInventory = [] } = useQuery({
    queryKey: ['projectInventory', projectId],
    queryFn: () => base44.entities.ProjectInventory.filter({ project_id: projectId }),
    enabled: !!projectId,
  });

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
  });

  const { data: allProjectInventory = [] } = useQuery({
    queryKey: ['allProjectInventory'],
    queryFn: () => base44.entities.ProjectInventory.list(),
  });

  const { data: components = [] } = useQuery({
    queryKey: ['components'],
    queryFn: () => base44.entities.Component.list(),
  });

  const { data: maintenanceTasks = [] } = useQuery({
    queryKey: ['maintenanceTasks'],
    queryFn: () => base44.entities.MaintenanceTask.list(),
  });

  const addItemMutation = useMutation({
    mutationFn: (data) => base44.entities.ProjectInventory.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['projectInventory']);
      setDialogOpen(false);
      setEditingItem(null);
    },
  });

  const updateItemMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ProjectInventory.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['projectInventory']);
      setDialogOpen(false);
      setEditingItem(null);
    },
  });

  const deleteItemMutation = useMutation({
    mutationFn: (id) => base44.entities.ProjectInventory.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['projectInventory']);
    },
  });

  const updateProjectMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Project.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['project']);
      setComponentDialogOpen(false);
    },
  });

  // Analyser reservedele der er delte
  const sharedSparesInfo = projectInventory.map(item => {
    const product = products.find(p => p.id === item.product_id);
    if (!product || (product.category !== 'spare_parts' && product.category !== 'components')) {
      return null;
    }

    // Find andre projekter der bruger samme del
    const otherProjects = allProjectInventory.filter(
      pi => pi.product_id === item.product_id && pi.project_id !== projectId
    );

    const centralStock = product.current_stock || 0;
    // This value is not used in the UI, but kept for completeness based on outline logic
    const totalInProjects = allProjectInventory
      .filter(pi => pi.product_id === item.product_id)
      .reduce((sum, pi) => sum + (pi.quantity || 0), 0);

    return {
      ...item,
      product,
      otherProjectsCount: otherProjects.length,
      centralStock,
      totalInProjects,
      isShared: otherProjects.length > 0,
    };
  }).filter(Boolean);

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const productId = formData.get('product_id');
    const product = products.find(p => p.id === productId);
    
    const data = {
      project_id: projectId,
      project_name: project?.name,
      product_id: productId,
      product_name: product?.name,
      product_sku: product?.sku,
      quantity: parseFloat(formData.get('quantity')),
      location_id: project?.location_id,
      location_name: project?.location_name,
      installation_date: formData.get('installation_date'),
      last_maintenance: formData.get('last_maintenance'),
      next_maintenance: formData.get('next_maintenance'),
      condition: formData.get('condition'),
      notes: formData.get('notes'),
    };

    if (editingItem) {
      updateItemMutation.mutate({ id: editingItem.id, data });
    } else {
      addItemMutation.mutate(data);
    }
  };

  const getConditionColor = (condition) => {
    const colors = {
      excellent: "bg-green-100 text-green-800",
      good: "bg-blue-100 text-blue-800",
      fair: "bg-yellow-100 text-yellow-800",
      poor: "bg-orange-100 text-orange-800",
      needs_replacement: "bg-red-100 text-red-800",
    };
    return colors[condition] || colors.good;
  };

  const handleAddComponent = (e) => {
    e.preventDefault();
    if (!project) return;
    
    const formData = new FormData(e.target);
    const componentId = formData.get('component_id');
    const component = components.find(c => c.id === componentId);
    
    const newComponent = {
      component_id: componentId,
      component_name: component?.name,
      quantity: parseInt(formData.get('quantity')),
      installation_date: formData.get('installation_date'),
      notes: formData.get('notes'),
    };

    const updatedComponents = [...(project.components || []), newComponent];
    updateProjectMutation.mutate({
      id: projectId,
      data: { ...project, components: updatedComponents }
    });
  };

  const handleRemoveComponent = (index) => {
    if (!project) return;
    
    const updatedComponents = (project.components || []).filter((_, i) => i !== index);
    updateProjectMutation.mutate({
      id: projectId,
      data: { ...project, components: updatedComponents }
    });
  };

  // Generate maintenance plan
  const generateMaintenancePlan = () => {
    if (!project) return [];
    const plan = [];
    (project.components || []).forEach(projComp => {
      const tasks = maintenanceTasks.filter(t => t.component_id === projComp.component_id);
      tasks.forEach(task => {
        plan.push({
          component: projComp.component_name,
          task: task.task_name,
          type: task.task_type,
          interval: `${task.interval_value} ${task.interval_type}`,
          duration: task.estimated_duration_hours ? `${task.estimated_duration_hours}t` : '-',
          priority: task.priority,
          procedure: task.procedure || '-',
        });
      });
    });
    return plan;
  };

  const maintenancePlan = generateMaintenancePlan();

  const exportMaintenancePlan = [
    { label: 'Komponent', accessor: (item) => item.component },
    { label: 'Task', accessor: (item) => item.task },
    { label: 'Type', accessor: (item) => item.type },
    { label: 'Interval', accessor: (item) => item.interval },
    { label: 'Varighed', accessor: (item) => item.duration },
    { label: 'Prioritet', accessor: (item) => item.priority },
    { label: 'Procedure', accessor: (item) => item.procedure },
  ];

  const exportColumns = [
    { label: t('product'), accessor: (item) => item.product_name },
    { label: 'SKU', accessor: (item) => item.product_sku },
    { label: t('quantity'), accessor: (item) => item.quantity },
    { label: t('location') || 'Lokation', accessor: (item) => item.location_name || '' },
    { label: t('installationDate') || 'Installation', accessor: (item) => item.installation_date ? format(new Date(item.installation_date), 'dd/MM/yyyy') : '-' },
    { label: t('lastMaintenance') || 'Sidste service', accessor: (item) => item.last_maintenance ? format(new Date(item.last_maintenance), 'dd/MM/yyyy') : '-' },
    { label: t('nextMaintenance') || 'Næste service', accessor: (item) => item.next_maintenance ? format(new Date(item.next_maintenance), 'dd/MM/yyyy') : '-' },
    { label: t('condition') || 'Tilstand', accessor: (item) => t(item.condition) },
  ];

  if (!project) return <div className="p-8">Loading...</div>;

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl('Projects'))}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1">
          <h2 className="text-3xl font-bold text-slate-900">{project.name}</h2>
          <p className="text-slate-500 mt-1">{project.project_number} - {project.customer_name}</p>
        </div>
        <div className="flex gap-3">
          <ExportButton 
            data={projectInventory}
            filename={`project-${project.project_number}-inventory-${new Date().toISOString().split('T')[0]}`}
            columns={exportColumns}
          />
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setEditingItem(null)}>
                <Plus className="w-4 h-4 mr-2" />
                {t('addItem') || 'Tilføj Del'}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingItem ? (t('editItem') || 'Rediger Del') : (t('addItem') || 'Tilføj Del')}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="product_id">{t('product')} *</Label>
                    <Select name="product_id" defaultValue={editingItem?.product_id} required>
                      <SelectTrigger>
                        <SelectValue placeholder={t('selectProduct')} />
                      </SelectTrigger>
                      <SelectContent>
                        {products.map(product => (
                          <SelectItem key={product.id} value={product.id}>
                            {product.name} ({product.sku})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="quantity">{t('quantity')} *</Label>
                    <Input id="quantity" name="quantity" type="number" min="1" defaultValue={editingItem?.quantity} required />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="installation_date">{t('installationDate') || 'Installations dato'}</Label>
                    <Input id="installation_date" name="installation_date" type="date" defaultValue={editingItem?.installation_date} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="condition">{t('condition') || 'Tilstand'}</Label>
                    <Select name="condition" defaultValue={editingItem?.condition || 'good'}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="excellent">{t('excellent') || 'Fremragende'}</SelectItem>
                        <SelectItem value="good">{t('good') || 'God'}</SelectItem>
                        <SelectItem value="fair">{t('fair') || 'Rimelig'}</SelectItem>
                        <SelectItem value="poor">{t('poor') || 'Dårlig'}</SelectItem>
                        <SelectItem value="needs_replacement">{t('needs_replacement') || 'Skal udskiftes'}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="last_maintenance">{t('lastMaintenance') || 'Sidste vedligeholdelse'}</Label>
                    <Input id="last_maintenance" name="last_maintenance" type="date" defaultValue={editingItem?.last_maintenance} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="next_maintenance">{t('nextMaintenance') || 'Næste vedligeholdelse'}</Label>
                    <Input id="next_maintenance" name="next_maintenance" type="date" defaultValue={editingItem?.next_maintenance} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">{t('notes')}</Label>
                  <Textarea id="notes" name="notes" defaultValue={editingItem?.notes} rows={3} />
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    {t('cancel')}
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    {editingItem ? t('saveChanges') : (t('addItem') || 'Tilføj')}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {sharedSparesInfo.some(s => s.isShared) && (
        <Alert className="bg-blue-50 border-blue-200">
          <Info className="w-4 h-4 text-blue-600" />
          <AlertDescription className="text-blue-800">
            💡 <strong>{t('sharedSparesTip') || 'Tip'}:</strong> {' '}
            {t('sharedSparesDesc') || 'Dette projekt deler reservedele med andre projekter. Check'} {' '}
            <Button
              variant="link"
              className="text-blue-600 underline p-0 h-auto"
              onClick={() => navigate(createPageUrl('SparePartsCentral'))}
            >
              {t('centralSpares') || 'Centrale Reservedele'}
            </Button> {' '}
            {t('forOptimization') || 'for optimering.'}
          </AlertDescription>
        </Alert>
      )}

      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="inventory">Lager & Dele</TabsTrigger>
          <TabsTrigger value="components">
            Komponenter ({(project.components || []).length})
          </TabsTrigger>
          <TabsTrigger value="maintenance">
            Vedligeholdelsesplan ({maintenancePlan.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="inventory">
          <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
        <CardHeader className="border-b border-slate-200/60">
          <CardTitle>{t('projectInventory') || 'Projekt Lager'}</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead>{t('product')}</TableHead>
                <TableHead>SKU</TableHead>
                <TableHead className="text-right">{t('quantity')}</TableHead>
                <TableHead>{t('installationDate') || 'Installation'}</TableHead>
                <TableHead>{t('nextMaintenance') || 'Næste service'}</TableHead>
                <TableHead>{t('condition') || 'Tilstand'}</TableHead>
                <TableHead>{t('sparePartsInfo') || 'Reservedele'}</TableHead>
                <TableHead className="text-right">{t('actions')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {projectInventory.map((item) => {
                const spareInfo = sharedSparesInfo.find(s => s.id === item.id);
                
                return (
                  <TableRow key={item.id} className="hover:bg-slate-50">
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                          <Package className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <div className="font-medium text-slate-900">{item.product_name}</div>
                          {item.notes && (
                            <div className="text-xs text-slate-500">{item.notes}</div>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-sm">{item.product_sku}</TableCell>
                    <TableCell className="text-right font-semibold">{item.quantity}</TableCell>
                    <TableCell>
                      {item.installation_date ? (
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-slate-400" />
                          {format(new Date(item.installation_date), 'dd/MM/yyyy')}
                        </div>
                      ) : '-'}
                    </TableCell>
                    <TableCell>
                      {item.next_maintenance ? format(new Date(item.next_maintenance), 'dd/MM/yyyy') : '-'}
                    </TableCell>
                    <TableCell>
                      <Badge className={getConditionColor(item.condition)}>
                        {t(item.condition)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {spareInfo && spareInfo.isShared ? (
                        <div className="text-xs">
                          <Badge variant="outline" className="mb-1">
                            {t('shared') || 'Delt'}: +{spareInfo.otherProjectsCount}
                          </Badge>
                          <div className="text-slate-500">
                            {t('centralStock') || 'Central'}: {spareInfo.centralStock} {t('pcs')}
                          </div>
                        </div>
                      ) : spareInfo ? ( // if spareInfo exists but is not shared, it's dedicated
                        <Badge variant="secondary" className="text-xs">
                          {t('dedicated') || 'Dedikeret'}
                        </Badge>
                      ) : ( // if spareInfo does not exist (not a spare part/component)
                        <span className="text-xs text-slate-400">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setEditingItem(item);
                            setDialogOpen(true);
                          }}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteItemMutation.mutate(item.id)}
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          {projectInventory.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <Package className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>{t('noItems') || 'Ingen dele på projektet endnu'}</p>
            </div>
          )}
        </CardContent>
      </Card>
        </TabsContent>

        <TabsContent value="components">
          <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
            <CardHeader className="border-b border-slate-200/60">
              <div className="flex justify-between items-center">
                <CardTitle>Projekt Komponenter</CardTitle>
                <Dialog open={componentDialogOpen} onOpenChange={setComponentDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Tilføj Komponent
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Tilføj Komponent til Projekt</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleAddComponent} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="component_id">Komponent *</Label>
                        <Select name="component_id" required>
                          <SelectTrigger>
                            <SelectValue placeholder="Vælg komponent" />
                          </SelectTrigger>
                          <SelectContent>
                            {components.map(comp => (
                              <SelectItem key={comp.id} value={comp.id}>
                                {comp.name} ({comp.component_id})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="quantity">Antal *</Label>
                          <Input id="quantity" name="quantity" type="number" min="1" defaultValue="1" required />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="installation_date">Installation</Label>
                          <Input id="installation_date" name="installation_date" type="date" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="notes">Noter</Label>
                        <Textarea id="notes" name="notes" rows={2} />
                      </div>
                      <div className="flex justify-end gap-3">
                        <Button type="button" variant="outline" onClick={() => setComponentDialogOpen(false)}>
                          Annuller
                        </Button>
                        <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                          Tilføj
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50">
                    <TableHead>Komponent</TableHead>
                    <TableHead className="text-right">Antal</TableHead>
                    <TableHead>Installation</TableHead>
                    <TableHead className="text-center">Vedligehold</TableHead>
                    <TableHead>Noter</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(project.components || []).map((comp, index) => {
                    const component = components.find(c => c.id === comp.component_id);
                    const taskCount = maintenanceTasks.filter(t => t.component_id === comp.component_id).length;
                    
                    return (
                      <TableRow key={index} className="hover:bg-slate-50">
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Settings className="w-5 h-5 text-blue-600" />
                            <div>
                              <div className="font-medium">{comp.component_name}</div>
                              {component && (
                                <div className="text-xs text-slate-500">
                                  {component.manufacturer} {component.model}
                                </div>
                              )}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-right font-semibold">{comp.quantity}</TableCell>
                        <TableCell>
                          {comp.installation_date ? format(new Date(comp.installation_date), 'dd/MM/yyyy') : '-'}
                        </TableCell>
                        <TableCell className="text-center">
                          <Badge className="bg-blue-100 text-blue-800">
                            <Wrench className="w-3 h-3 mr-1" />
                            {taskCount}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-slate-600">{comp.notes || '-'}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemoveComponent(index)}
                          >
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              {(project.components || []).length === 0 && (
                <div className="text-center py-12 text-slate-500">
                  <Settings className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                  <p>Ingen komponenter tilføjet endnu</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="maintenance">
          <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
            <CardHeader className="border-b border-slate-200/60">
              <div className="flex justify-between items-center">
                <CardTitle>Vedligeholdelsesplan</CardTitle>
                {maintenancePlan.length > 0 && (
                  <ExportButton
                    data={maintenancePlan}
                    filename={`${project.project_number}-vedligeholdelsesplan-${new Date().toISOString().split('T')[0]}`}
                    columns={exportMaintenancePlan}
                  />
                )}
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50">
                    <TableHead>Komponent</TableHead>
                    <TableHead>Task</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Interval</TableHead>
                    <TableHead>Varighed</TableHead>
                    <TableHead>Prioritet</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {maintenancePlan.map((item, index) => (
                    <TableRow key={index} className="hover:bg-slate-50">
                      <TableCell className="font-medium">{item.component}</TableCell>
                      <TableCell>{item.task}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{item.type}</Badge>
                      </TableCell>
                      <TableCell>{item.interval}</TableCell>
                      <TableCell>{item.duration}</TableCell>
                      <TableCell>
                        <Badge className={
                          item.priority === 'critical' ? 'bg-red-100 text-red-800' :
                          item.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                          'bg-blue-100 text-blue-800'
                        }>
                          {item.priority}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {maintenancePlan.length === 0 && (
                <div className="text-center py-12 text-slate-500">
                  <Wrench className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                  <p>Ingen vedligeholdelsesopgaver</p>
                  <p className="text-sm mt-2">Tilføj komponenter med vedligeholdelsesopgaver for at se planen</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}