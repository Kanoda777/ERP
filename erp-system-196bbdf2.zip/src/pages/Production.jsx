import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Factory, Calendar, CheckCircle, XCircle, Clock, Edit, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { useLanguage } from "@/components/LanguageContext";
import ExportButton from "@/components/ExportButton";

export default function Production() {
  const { t } = useLanguage();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState(null);
  const queryClient = useQueryClient();

  const { data: productionRecords = [] } = useQuery({
    queryKey: ['productionRecords'],
    queryFn: () => base44.entities.ProductionRecord.list('-created_date'),
  });

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
  });

  const createRecordMutation = useMutation({
    mutationFn: async (data) => {
      const record = await base44.entities.ProductionRecord.create(data);
      if (data.quality_status === 'approved') {
        const product = products.find(p => p.id === data.product_id);
        if (product) {
          await base44.entities.Product.update(data.product_id, {
            current_stock: product.current_stock + data.quantity_produced
          });
        }
      }
      return record;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['productionRecords']);
      queryClient.invalidateQueries(['products']);
      setDialogOpen(false);
      setEditingRecord(null);
    },
  });

  const updateRecordMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ProductionRecord.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['productionRecords']);
      setDialogOpen(false);
      setEditingRecord(null);
    },
  });

  const deleteRecordMutation = useMutation({
    mutationFn: (id) => base44.entities.ProductionRecord.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['productionRecords']);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const productId = formData.get('product_id');
    const product = products.find(p => p.id === productId);
    
    const data = {
      product_id: productId,
      product_name: product?.name,
      quantity_produced: parseFloat(formData.get('quantity_produced')),
      production_date: formData.get('production_date'),
      batch_number: formData.get('batch_number'),
      production_cost: parseFloat(formData.get('production_cost')) || 0,
      operator: formData.get('operator'),
      quality_status: formData.get('quality_status'),
      notes: formData.get('notes'),
    };

    if (editingRecord) {
      updateRecordMutation.mutate({ id: editingRecord.id, data });
    } else {
      createRecordMutation.mutate(data);
    }
  };

  const handleDelete = (record) => {
    const code = prompt('Indtast admin kode for at slette:');
    if (code === 'DDigital') {
      if (confirm(`Er du sikker på at du vil slette produktion "${record.product_name}" (${record.batch_number})?`)) {
        deleteRecordMutation.mutate(record.id);
      }
    } else if (code !== null) {
      alert('Forkert admin kode');
    }
  };

  const getQualityColor = (status) => {
    const colors = {
      approved: "bg-green-100 text-green-800",
      pending: "bg-yellow-100 text-yellow-800",
      rejected: "bg-red-100 text-red-800",
    };
    return colors[status] || colors.pending;
  };

  const getQualityIcon = (status) => {
    const icons = {
      approved: CheckCircle,
      pending: Clock,
      rejected: XCircle,
    };
    return icons[status] || Clock;
  };

  const exportColumns = [
    { label: t('product'), accessor: (item) => item.product_name },
    { label: t('batch'), accessor: (item) => item.batch_number || '-' },
    { label: t('date'), accessor: (item) => format(new Date(item.production_date), 'dd/MM/yyyy') },
    { label: t('quantity'), accessor: (item) => `${item.quantity_produced} ${t('pcs')}` },
    { label: t('operator'), accessor: (item) => item.operator || '-' },
    { label: t('cost'), accessor: (item) => item.production_cost ? `${item.production_cost.toLocaleString('da-DK')} ${t('kr')}` : '-' },
    { label: t('status'), accessor: (item) => t(item.quality_status) },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">{t('productionManagement')}</h2>
          <p className="text-slate-500 mt-1">{t('manageProduction')}</p>
        </div>
        <div className="flex gap-3">
          <ExportButton 
            data={productionRecords}
            filename={`production-${new Date().toISOString().split('T')[0]}`}
            columns={exportColumns}
          />
          <Dialog open={dialogOpen} onOpenChange={(open) => {
            setDialogOpen(open);
            if (!open) setEditingRecord(null);
          }}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setEditingRecord(null)}>
                <Plus className="w-4 h-4 mr-2" />
                {t('registerProduction')}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingRecord ? t('editProduct') : t('newProductionRecord')}</DialogTitle>
              </DialogHeader>
              <form key={editingRecord?.id || 'new'} onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="product_id">{t('product')} *</Label>
                    <Select name="product_id" defaultValue={editingRecord?.product_id} required>
                      <SelectTrigger>
                        <SelectValue placeholder={t('selectProduct')} />
                      </SelectTrigger>
                      <SelectContent>
                        {products.map(product => (
                          <SelectItem key={product.id} value={product.id}>
                            {product.name} ({product.sku})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="quantity_produced">{t('quantityProduced')} *</Label>
                    <Input 
                      id="quantity_produced" 
                      name="quantity_produced" 
                      type="number" 
                      min="1" 
                      defaultValue={editingRecord?.quantity_produced}
                      required 
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="production_date">{t('productionDate')} *</Label>
                    <Input 
                      id="production_date" 
                      name="production_date" 
                      type="date" 
                      defaultValue={editingRecord?.production_date || format(new Date(), 'yyyy-MM-dd')} 
                      required 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="batch_number">{t('batchNumber')}</Label>
                    <Input 
                      id="batch_number" 
                      name="batch_number" 
                      placeholder="f.eks. B-2024-001"
                      defaultValue={editingRecord?.batch_number || `B-${format(new Date(), 'yyyyMMdd')}`}
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="production_cost">{t('productionCost')} ({t('kr')})</Label>
                    <Input 
                      id="production_cost" 
                      name="production_cost" 
                      type="number" 
                      step="0.01"
                      defaultValue={editingRecord?.production_cost}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="operator">{t('operator')}</Label>
                    <Input 
                      id="operator" 
                      name="operator" 
                      placeholder={t('operatorNamePlaceholder')}
                      defaultValue={editingRecord?.operator}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="quality_status">{t('qualityStatus')} *</Label>
                  <Select name="quality_status" defaultValue={editingRecord?.quality_status || "pending"}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">{t('pending_approval')}</SelectItem>
                      <SelectItem value="approved">{t('approved')}</SelectItem>
                      <SelectItem value="rejected">{t('rejected')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">{t('notes')}</Label>
                  <Textarea 
                    id="notes" 
                    name="notes" 
                    rows={3} 
                    placeholder={t('extraInfo')}
                    defaultValue={editingRecord?.notes}
                  />
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => {
                    setDialogOpen(false);
                    setEditingRecord(null);
                  }}>
                    {t('cancel')}
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    {editingRecord ? t('saveChanges') : t('registerProd')}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600">{t('totalProduction')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-900">
              {productionRecords.reduce((sum, r) => sum + (r.quantity_produced || 0), 0)}
            </div>
            <p className="text-sm text-slate-500 mt-1">{t('pcsProduced')}</p>
          </CardContent>
        </Card>

        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600">{t('approved')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">
              {productionRecords.filter(r => r.quality_status === 'approved').length}
            </div>
            <p className="text-sm text-slate-500 mt-1">{t('productionBatches')}</p>
          </CardContent>
        </Card>

        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600">{t('totalCost')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-900">
              {productionRecords.reduce((sum, r) => sum + (r.production_cost || 0), 0).toLocaleString('da-DK')} {t('kr')}
            </div>
            <p className="text-sm text-slate-500 mt-1">{t('productionCosts')}</p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
        <CardHeader className="border-b border-slate-200/60">
          <CardTitle>{t('productionHistory')}</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead>{t('product')}</TableHead>
                <TableHead>{t('batch')}</TableHead>
                <TableHead>{t('date')}</TableHead>
                <TableHead className="text-right">{t('quantity')}</TableHead>
                <TableHead>{t('operator')}</TableHead>
                <TableHead className="text-right">{t('cost')}</TableHead>
                <TableHead>{t('status')}</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {productionRecords.map((record) => {
                const QualityIcon = getQualityIcon(record.quality_status);
                return (
                  <TableRow key={record.id} className="hover:bg-slate-50">
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                          <Factory className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <div className="font-medium">{record.product_name}</div>
                          {record.notes && (
                            <div className="text-xs text-slate-500">{record.notes}</div>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-sm">{record.batch_number || '-'}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-slate-400" />
                        {format(new Date(record.production_date), 'dd/MM/yyyy')}
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-semibold">
                      {record.quantity_produced} {t('pcs')}
                    </TableCell>
                    <TableCell>{record.operator || '-'}</TableCell>
                    <TableCell className="text-right">
                      {record.production_cost ? `${record.production_cost.toLocaleString('da-DK')} ${t('kr')}` : '-'}
                    </TableCell>
                    <TableCell>
                      <Badge className={`${getQualityColor(record.quality_status)} gap-1`}>
                        <QualityIcon className="w-3 h-3" />
                        {t(record.quality_status)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => {
                            setEditingRecord(record);
                            setDialogOpen(true);
                          }}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => handleDelete(record)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          {productionRecords.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <Factory className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>{t('noProductionData')}</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}