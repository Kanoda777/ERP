import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Package, Search, AlertTriangle, TrendingUp, Briefcase } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useLanguage } from "@/components/LanguageContext";
import ExportButton from "@/components/ExportButton";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function SparePartsCentral() {
  const { t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState("");

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
  });

  const { data: projectInventory = [] } = useQuery({
    queryKey: ['projectInventory'],
    queryFn: () => base44.entities.ProjectInventory.list(),
  });

  const { data: projects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.list(),
  });

  // Beregn hvilke produkter der bruges i projekter og anbefalede lagerniveauer
  const sparePartsAnalysis = products
    .filter(p => p.category === 'spare_parts' || p.category === 'components')
    .map(product => {
      // Find alle projekter der bruger dette produkt
      const projectsUsingThis = projectInventory
        .filter(pi => pi.product_id === product.id)
        .map(pi => projects.find(proj => proj.id === pi.project_id))
        .filter(Boolean);

      // Total antal af denne del på tværs af alle projekter
      const totalInProjects = projectInventory
        .filter(pi => pi.product_id === product.id)
        .reduce((sum, pi) => sum + (pi.quantity || 0), 0);

      // Anbefalet minimum baseret på projekter
      // Logik: For hver 5 dele i brug, hold minimum 1 reservedel
      const recommendedMinSpares = Math.ceil(totalInProjects * 0.2); // 20% af dele i brug
      
      // Besparelse hvis man deler reservedele vs at have dem på hvert projekt
      const ifSeparate = projectsUsingThis.length * 2; // Hvis hvert projekt skulle have 2 reservedele
      const centralStock = Math.max(recommendedMinSpares, 2); // Centralt: minimum 2, eller anbefalet
      const savings = ifSeparate - centralStock;

      return {
        ...product,
        projectsUsing: projectsUsingThis,
        projectCount: projectsUsingThis.length,
        totalInProjects,
        recommendedMinSpares,
        currentSpares: product.current_stock,
        needsReorder: product.current_stock < recommendedMinSpares,
        savings: savings > 0 ? savings : 0,
      };
    })
    .filter(p => p.projectCount > 0) // Kun vis produkter der bruges i projekter
    .sort((a, b) => b.projectCount - a.projectCount);

  const filteredSpares = sparePartsAnalysis.filter(spare =>
    spare.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    spare.sku?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalSavings = sparePartsAnalysis.reduce((sum, sp) => sum + sp.savings, 0);
  const lowStockCount = sparePartsAnalysis.filter(sp => sp.needsReorder).length;

  const exportColumns = [
    { label: t('product'), accessor: (item) => item.name },
    { label: 'SKU', accessor: (item) => item.sku },
    { label: t('projectsUsing') || 'Projekter', accessor: (item) => item.projectCount },
    { label: t('totalInProjects') || 'I brug', accessor: (item) => item.totalInProjects },
    { label: t('currentStock'), accessor: (item) => item.currentSpares },
    { label: t('recommendedSpares') || 'Anbefalet', accessor: (item) => item.recommendedMinSpares },
    { label: t('savings') || 'Besparelse', accessor: (item) => `${item.savings} stk` },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">{t('centralSpares') || 'Centrale Reservedele'}</h2>
          <p className="text-slate-500 mt-1">{t('sharedSpares') || 'Delte reservedele på tværs af projekter'}</p>
        </div>
        <ExportButton 
          data={filteredSpares}
          filename={`spare-parts-analysis-${new Date().toISOString().split('T')[0]}`}
          columns={exportColumns}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <Package className="w-4 h-4" />
              {t('totalSparePartsTypes') || 'Reservedels-typer'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-900">{sparePartsAnalysis.length}</div>
            <p className="text-sm text-slate-500 mt-1">{t('sharedAcrossProjects') || 'Delt på tværs af projekter'}</p>
          </CardContent>
        </Card>

        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              {t('potentialSavings') || 'Potentiel Besparelse'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{totalSavings}</div>
            <p className="text-sm text-slate-500 mt-1">{t('sparesVsSeparate') || 'Reservedele vs separate lagre'}</p>
          </CardContent>
        </Card>

        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              {t('lowStockSpares') || 'Lav Beholdning'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">{lowStockCount}</div>
            <p className="text-sm text-slate-500 mt-1">{t('needsReordering') || 'Skal genbestilles'}</p>
          </CardContent>
        </Card>
      </div>

      {lowStockCount > 0 && (
        <Card className="border-orange-200 bg-gradient-to-br from-orange-50 to-white">
          <CardHeader>
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
              <CardTitle className="text-orange-900">{t('reorderAlert') || 'Genbestillings-alarm'}</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-orange-700 mb-4">
              {t('reorderAlertDesc') || 'Følgende reservedele har lavere lagerbeholdning end anbefalet baseret på projekter der bruger dem:'}
            </p>
            <div className="space-y-2">
              {sparePartsAnalysis.filter(sp => sp.needsReorder).map((spare) => (
                <div key={spare.id} className="flex items-center justify-between p-3 bg-white rounded-lg border border-orange-100">
                  <div>
                    <div className="font-medium text-slate-900">{spare.name}</div>
                    <div className="text-sm text-slate-500">{spare.projectCount} {t('projects') || 'projekter'} bruger denne</div>
                  </div>
                  <div className="text-right">
                    <div className="text-orange-600 font-semibold">
                      {spare.currentSpares} / {spare.recommendedMinSpares} {t('pcs')}
                    </div>
                    <Link to={createPageUrl('Purchases')}>
                      <Button size="sm" className="mt-2 bg-orange-600 hover:bg-orange-700">
                        {t('reorder')}
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
        <CardHeader className="border-b border-slate-200/60">
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <CardTitle>{t('sparePartsInventory') || 'Reservedels Oversigt'}</CardTitle>
            <div className="relative max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                placeholder={t('searchProduct')}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead>{t('product')}</TableHead>
                <TableHead>SKU</TableHead>
                <TableHead className="text-center">{t('projectsUsing') || 'Projekter'}</TableHead>
                <TableHead className="text-right">{t('totalInUse') || 'I Brug'}</TableHead>
                <TableHead className="text-right">{t('onStock') || 'På Lager'}</TableHead>
                <TableHead className="text-right">{t('recommended') || 'Anbefalet'}</TableHead>
                <TableHead className="text-right">{t('savings') || 'Besparelse'}</TableHead>
                <TableHead>{t('status')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSpares.map((spare) => (
                <TableRow key={spare.id} className="hover:bg-slate-50">
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Package className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <div className="font-medium text-slate-900">{spare.name}</div>
                        <div className="text-xs text-slate-500">
                          {spare.projectsUsing.slice(0, 2).map(p => p.name).join(', ')}
                          {spare.projectCount > 2 && ` +${spare.projectCount - 2} mere`}
                        </div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="font-mono text-sm">{spare.sku}</TableCell>
                  <TableCell className="text-center">
                    <Badge variant="outline" className="gap-1">
                      <Briefcase className="w-3 h-3" />
                      {spare.projectCount}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right font-medium">{spare.totalInProjects}</TableCell>
                  <TableCell className="text-right">
                    <span className={spare.needsReorder ? "text-orange-600 font-semibold" : "text-slate-900"}>
                      {spare.currentSpares}
                    </span>
                  </TableCell>
                  <TableCell className="text-right text-blue-600 font-semibold">
                    {spare.recommendedMinSpares}
                  </TableCell>
                  <TableCell className="text-right">
                    {spare.savings > 0 && (
                      <Badge className="bg-green-100 text-green-800">
                        +{spare.savings} {t('pcs')}
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    {spare.needsReorder ? (
                      <Badge variant="destructive" className="gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        {t('low')}
                      </Badge>
                    ) : (
                      <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                        {t('ok')}
                      </Badge>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredSpares.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <Package className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>{t('noSparePartsFound') || 'Ingen reservedele fundet'}</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-white">
        <CardHeader>
          <CardTitle className="text-blue-900 flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            {t('optimizationTip') || 'Optimeringstip'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-blue-800">
            💡 <strong>{t('smartSharing') || 'Smart deling'}:</strong> {' '}
            {t('sharingDesc') || 'Ved at dele reservedele centralt i stedet for at have dem på hvert projekt, sparer du potentielt'} {' '}
            <strong className="text-blue-900">{totalSavings} reservedele</strong>. {' '}
            {t('recommendationLogic') || 'Anbefalingen er at holde ~20% af dele i brug som centralt lager.'}
          </p>
          <div className="mt-4 p-3 bg-white rounded-lg">
            <div className="text-sm font-medium text-slate-700 mb-2">{t('example') || 'Eksempel'}:</div>
            <div className="text-sm text-slate-600">
              • 5 projekter bruger samme pumpe<br/>
              • Total i brug: 25 pumper<br/>
              • {t('withoutSharing') || 'Uden deling'}: 5 projekter × 2 reservedele = 10 reservedele<br/>
              • {t('withSharing') || 'Med central deling'}: 5 reservedele (20% af 25)<br/>
              • <strong className="text-green-600">✓ Besparelse: 5 pumper</strong>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}