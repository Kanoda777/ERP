
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, ShoppingCart, Trash2, Calendar } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { format } from "date-fns";
import { useLanguage } from "@/components/LanguageContext";
import ExportButton from "@/components/ExportButton";

export default function Purchases() {
  const { t } = useLanguage();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState("");
  const [orderItems, setOrderItems] = useState([{ product_id: "", quantity: 0, unit_price: 0 }]);
  const queryClient = useQueryClient();

  const { data: purchaseOrders = [] } = useQuery({
    queryKey: ['purchaseOrders'],
    queryFn: () => base44.entities.PurchaseOrder.list('-created_date'),
  });

  const { data: suppliers = [] } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => base44.entities.Supplier.filter({ status: 'active' }),
  });

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
  });

  const createOrderMutation = useMutation({
    mutationFn: async (data) => {
      const order = await base44.entities.PurchaseOrder.create(data);
      if (data.status === 'delivered') {
        for (const item of data.items) {
          const product = products.find(p => p.id === item.product_id);
          if (product) {
            await base44.entities.Product.update(item.product_id, {
              current_stock: product.current_stock + item.quantity
            });
          }
        }
      }
      return order;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['purchaseOrders']);
      queryClient.invalidateQueries(['products']);
      setDialogOpen(false);
      setOrderItems([{ product_id: "", quantity: 0, unit_price: 0 }]);
      setSelectedSupplier("");
    },
  });

  const handleAddItem = () => {
    setOrderItems([...orderItems, { product_id: "", quantity: 0, unit_price: 0 }]);
  };

  const handleRemoveItem = (index) => {
    setOrderItems(orderItems.filter((_, i) => i !== index));
  };

  const handleItemChange = (index, field, value) => {
    const newItems = [...orderItems];
    newItems[index][field] = value;
    
    if (field === 'product_id') {
      const product = products.find(p => p.id === value);
      if (product) {
        newItems[index].unit_price = product.unit_price;
        newItems[index].product_name = product.name;
      }
    }
    
    newItems[index].total = newItems[index].quantity * newItems[index].unit_price;
    setOrderItems(newItems);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const supplier = suppliers.find(s => s.id === selectedSupplier);
    
    const totalAmount = orderItems.reduce((sum, item) => sum + (item.total || 0), 0);
    
    const data = {
      order_number: `PO-${Date.now()}`,
      supplier_id: selectedSupplier,
      supplier_name: supplier?.name,
      order_date: formData.get('order_date'),
      expected_delivery: formData.get('expected_delivery'),
      status: formData.get('status'),
      items: orderItems.filter(item => item.product_id),
      total_amount: totalAmount,
      notes: formData.get('notes'),
    };

    createOrderMutation.mutate(data);
  };

  const getStatusColor = (status) => {
    const colors = {
      draft: "bg-slate-100 text-slate-800",
      sent: "bg-blue-100 text-blue-800",
      confirmed: "bg-purple-100 text-purple-800",
      delivered: "bg-green-100 text-green-800",
      cancelled: "bg-red-100 text-red-800",
    };
    return colors[status] || colors.draft;
  };

  const exportColumns = [
    { label: t('orderNumber'), accessor: (item) => item.order_number },
    { label: t('supplier'), accessor: (item) => item.supplier_name },
    { label: t('orderDate'), accessor: (item) => format(new Date(item.order_date), 'dd/MM/yyyy') },
    { label: t('expectedDelivery'), accessor: (item) => item.expected_delivery ? format(new Date(item.expected_delivery), 'dd/MM/yyyy') : '-' },
    { label: t('amount'), accessor: (item) => `${item.total_amount?.toLocaleString('da-DK')} ${t('kr')}` },
    { label: t('status'), accessor: (item) => t(item.status) },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">{t('purchaseOrders')}</h2>
          <p className="text-slate-500 mt-1">{t('managePurchases')}</p>
        </div>
        <div className="flex gap-3">
          <ExportButton 
            data={purchaseOrders}
            filename={`purchases-${new Date().toISOString().split('T')[0]}`}
            columns={exportColumns}
          />
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                {t('createPurchaseOrder')}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{t('newPurchaseOrder')}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="supplier">{t('supplier')} *</Label>
                    <Select value={selectedSupplier} onValueChange={setSelectedSupplier} required>
                      <SelectTrigger>
                        <SelectValue placeholder={t('selectSupplier')} />
                      </SelectTrigger>
                      <SelectContent>
                        {suppliers.map(supplier => (
                          <SelectItem key={supplier.id} value={supplier.id}>
                            {supplier.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="status">{t('status')} *</Label>
                    <Select name="status" defaultValue="draft">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">{t('draft')}</SelectItem>
                        <SelectItem value="sent">{t('sent')}</SelectItem>
                        <SelectItem value="confirmed">{t('confirmed')}</SelectItem>
                        <SelectItem value="delivered">{t('delivered')}</SelectItem>
                        <SelectItem value="cancelled">{t('cancelled')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="order_date">{t('orderDate')} *</Label>
                    <Input id="order_date" name="order_date" type="date" defaultValue={format(new Date(), 'yyyy-MM-dd')} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="expected_delivery">{t('expectedDelivery')}</Label>
                    <Input id="expected_delivery" name="expected_delivery" type="date" />
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>{t('orderLines')}</Label>
                    <Button type="button" variant="outline" size="sm" onClick={handleAddItem}>
                      <Plus className="w-4 h-4 mr-2" />
                      {t('addItem')}
                    </Button>
                  </div>
                  
                  <div className="border rounded-lg overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-slate-50">
                          <TableHead>{t('product')}</TableHead>
                          <TableHead className="w-24">{t('quantity')}</TableHead>
                          <TableHead className="w-32">{t('unitPrice')}</TableHead>
                          <TableHead className="w-32">{t('total')}</TableHead>
                          <TableHead className="w-12"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {orderItems.map((item, index) => (
                          <TableRow key={index}>
                            <TableCell>
                              <Select
                                value={item.product_id}
                                onValueChange={(value) => handleItemChange(index, 'product_id', value)}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder={t('selectProduct')} />
                                </SelectTrigger>
                                <SelectContent>
                                  {products.map(product => (
                                    <SelectItem key={product.id} value={product.id}>
                                      {product.name} ({product.sku})
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell>
                              <Input
                                type="number"
                                min="1"
                                value={item.quantity || ""}
                                onChange={(e) => handleItemChange(index, 'quantity', parseFloat(e.target.value) || 0)}
                              />
                            </TableCell>
                            <TableCell>
                              <Input
                                type="number"
                                step="0.01"
                                value={item.unit_price || ""}
                                onChange={(e) => handleItemChange(index, 'unit_price', parseFloat(e.target.value) || 0)}
                              />
                            </TableCell>
                            <TableCell>
                              <div className="font-semibold">{(item.total || 0).toFixed(2)} {t('kr')}</div>
                            </TableCell>
                            <TableCell>
                              <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                onClick={() => handleRemoveItem(index)}
                              >
                                <Trash2 className="w-4 h-4 text-red-500" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  
                  <div className="flex justify-end items-center gap-4 pt-3 border-t">
                    <span className="text-lg font-medium">{t('total')}:</span>
                    <span className="text-2xl font-bold text-blue-600">
                      {orderItems.reduce((sum, item) => sum + (item.total || 0), 0).toFixed(2)} {t('kr')}
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">{t('notes')}</Label>
                  <Input id="notes" name="notes" placeholder={t('extraInfo')} />
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    {t('cancel')}
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    {t('createOrder')}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
        <CardHeader className="border-b border-slate-200/60">
          <CardTitle>{t('allPurchaseOrders')}</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead>{t('orderNumber')}</TableHead>
                <TableHead>{t('supplier')}</TableHead>
                <TableHead>{t('orderDate')}</TableHead>
                <TableHead>{t('expectedDelivery')}</TableHead>
                <TableHead className="text-right">{t('amount')}</TableHead>
                <TableHead>{t('status')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {purchaseOrders.map((order) => (
                <TableRow key={order.id} className="hover:bg-slate-50">
                  <TableCell className="font-mono text-sm font-medium">{order.order_number}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <ShoppingCart className="w-4 h-4 text-slate-400" />
                      {order.supplier_name}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-slate-400" />
                      {format(new Date(order.order_date), 'dd/MM/yyyy')}
                    </div>
                  </TableCell>
                  <TableCell>
                    {order.expected_delivery ? format(new Date(order.expected_delivery), 'dd/MM/yyyy') : '-'}
                  </TableCell>
                  <TableCell className="text-right font-semibold">
                    {order.total_amount?.toLocaleString('da-DK')} {t('kr')}
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(order.status)}>
                      {t(order.status)}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {purchaseOrders.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <ShoppingCart className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>{t('noPurchaseOrders')}</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
