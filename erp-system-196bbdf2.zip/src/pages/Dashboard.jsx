
import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Package, 
  AlertTriangle, 
  ShoppingBag, 
  ShoppingCart, 
  TrendingUp, // Added
  Factory,
  ArrowRight, // Added
  RefreshCw // Added
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useLanguage } from "@/components/LanguageContext";
import { format } from "date-fns";

export default function Dashboard() {
  const { t } = useLanguage();

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
  });

  const { data: salesOrders = [] } = useQuery({
    queryKey: ['salesOrders'],
    queryFn: () => base44.entities.SalesOrder.list('-created_date', 5),
  });

  const { data: purchaseOrders = [] } = useQuery({
    queryKey: ['purchaseOrders'],
    queryFn: () => base44.entities.PurchaseOrder.list('-created_date'), // Changed from 5 to no limit
  });

  const { data: productionRecords = [] } = useQuery({
    queryKey: ['productionRecords'],
    queryFn: () => base44.entities.ProductionRecord.list('-created_date', 5),
  });

  // Beregn total lagerværdi
  const totalInventoryValue = products.reduce((sum, p) => 
    sum + ((p.current_stock || 0) * (p.unit_price || 0)), 0
  );

  // Find produkter med lav lagerbeholdning
  const lowStockProducts = products.filter(p => 
    p.current_stock <= p.min_stock_level
  );

  // Find produkter der skal auto-genbestilles
  const autoReorderProducts = products.filter(p => {
    const isLowStock = p.current_stock <= p.min_stock_level;
    const needsStock = p.stock_strategy !== 'order_when_needed' || p.criticality === 'critical';
    const hasSupplier = p.supplier_id;
    return isLowStock && needsStock && hasSupplier;
  });

  // Aktive salgsordrer
  const activeSalesOrders = salesOrders.filter(o => 
    ['pending', 'confirmed', 'in_production'].includes(o.status)
  );

  // Åbne indkøbsordrer
  const openPurchaseOrders = purchaseOrders.filter(o => 
    ['draft', 'sent', 'confirmed'].includes(o.status)
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center"> {/* Added flex container */}
        <div>
          <h2 className="text-3xl font-bold text-slate-900">{t('welcomeBack')}</h2>
          <p className="text-slate-500 mt-1">{t('companyOverview')}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm hover:shadow-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <Package className="w-4 h-4" />
              {t('inventoryValue')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">
              {totalInventoryValue.toLocaleString('da-DK')} {t('kr')}
            </div>
            <p className="text-xs text-slate-500 mt-1">{products.length} {t('products')}</p> {/* Changed 'produkter' to t('products') */}
          </CardContent>
        </Card>

        <Card className="border-orange-200/60 bg-orange-50/50 backdrop-blur-sm hover:shadow-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-orange-600" />
              {t('lowStock')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{lowStockProducts.length}</div>
            <p className="text-xs text-slate-500 mt-1">{t('requiresAction')}</p>
          </CardContent>
        </Card>

        <Card className="border-blue-200/60 bg-blue-50/50 backdrop-blur-sm hover:shadow-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-blue-600" />
              {t('activeSalesOrders')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{activeSalesOrders.length}</div>
            <p className="text-xs text-slate-500 mt-1">{salesOrders.length} {t('ordersTotal')}</p> {/* Changed 'ordrer i alt' to t('ordersTotal') */}
          </CardContent>
        </Card>

        <Card className="border-purple-200/60 bg-purple-50/50 backdrop-blur-sm hover:shadow-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <ShoppingCart className="w-4 h-4 text-purple-600" />
              {t('openPurchases')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{openPurchaseOrders.length}</div>
            <p className="text-xs text-slate-500 mt-1">{purchaseOrders.length} {t('ordersTotal')}</p> {/* Changed 'ordrer i alt' to t('ordersTotal') */}
          </CardContent>
        </Card>
      </div>

      {autoReorderProducts.length > 0 && (
        <Card className="border-red-200 bg-gradient-to-br from-red-50 to-white">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <RefreshCw className="w-5 h-5 text-red-600" />
                <CardTitle className="text-red-900">
                  {t('autoReorderAlert') || 'Automatisk Genbestilling Påkrævet'}
                </CardTitle>
              </div>
              <Link to={createPageUrl('AutoReorder')}>
                <Button className="bg-red-600 hover:bg-red-700">
                  {t('viewAll') || 'Se alle'} ({autoReorderProducts.length})
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-red-700 mb-4">
              {autoReorderProducts.filter(p => p.criticality === 'critical').length > 0 && (
                <span className="font-semibold">
                  ⚠️ {autoReorderProducts.filter(p => p.criticality === 'critical').length} {t('criticalComponents')} 
                </span>
              )}
              {' '}{t('needsReordering') || 'skal genbestilles'}.
            </p>
            <div className="grid gap-2">
              {autoReorderProducts.slice(0, 3).map((product) => (
                <div key={product.id} className="flex items-center justify-between p-3 bg-white rounded-lg border border-red-100">
                  <div className="flex items-center gap-3">
                    <Package className="w-5 h-5 text-red-600" />
                    <div>
                      <div className="font-medium text-slate-900">{product.name}</div>
                      <div className="text-sm text-slate-500">
                        {product.current_stock} / {product.min_stock_level} {product.unit}
                        {product.criticality === 'critical' && (
                          <Badge className="ml-2 bg-red-100 text-red-800">{t('critical')}</Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  <Link to={createPageUrl('Purchases')}> {/* This link would typically go to a specific reorder page or a purchase order creation page, here it defaults to Purchases */}
                    <Button size="sm" variant="outline">
                      {t('reorder')}
                    </Button>
                  </Link>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="border-b border-slate-200/60">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600" />
                {t('lowStockProducts')}
              </CardTitle>
              <Link to={createPageUrl('Inventory')}>
                <Button variant="ghost" size="sm">
                  {t('seeAll')} <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-4">
              {lowStockProducts.slice(0, 5).map((product) => (
                <div key={product.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                      <Package className="w-5 h-5 text-orange-600" />
                    </div>
                    <div>
                      <div className="font-medium text-slate-900">{product.name}</div>
                      <div className="text-sm text-slate-500">
                        {product.current_stock} {product.unit} ({product.min_stock_level} {product.unit} {t('min')})
                      </div>
                    </div>
                  </div>
                  <Link to={createPageUrl('Purchases')}>
                    <Button size="sm" variant="outline">
                      {t('reorder')}
                    </Button>
                  </Link>
                </div>
              ))}
              {lowStockProducts.length === 0 && (
                <div className="text-center py-8 text-slate-500">
                  <Package className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                  <p>{t('allStocked') || 'Alt er på lager'}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="border-b border-slate-200/60">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-blue-600" />
                {t('recentSalesOrders')}
              </CardTitle>
              <Link to={createPageUrl('Sales')}>
                <Button variant="ghost" size="sm">
                  {t('seeAll')} <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-4">
              {salesOrders.slice(0, 5).map((order) => (
                <div key={order.id} className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-slate-900">{order.customer_name}</div>
                    <div className="text-sm text-slate-500">
                      {order.order_date && format(new Date(order.order_date), 'dd/MM/yyyy')} • {order.total_amount?.toLocaleString('da-DK')} {t('kr')}
                    </div>
                  </div>
                  <Badge className={
                    order.status === 'delivered' ? 'bg-green-100 text-green-800' :
                    order.status === 'shipped' ? 'bg-blue-100 text-blue-800' :
                    order.status === 'in_production' ? 'bg-purple-100 text-purple-800' :
                    'bg-yellow-100 text-yellow-800'
                  }>
                    {t(order.status)}
                  </Badge>
                </div>
              ))}
              {salesOrders.length === 0 && (
                <div className="text-center py-8 text-slate-500">
                  <ShoppingBag className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                  <p>{t('noSalesOrders')}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
        <CardHeader className="border-b border-slate-200/60">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Factory className="w-5 h-5 text-purple-600" />
              {t('recentProduction')}
            </CardTitle>
            <Link to={createPageUrl('Production')}>
              <Button variant="ghost" size="sm">
                {t('seeAll')} <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4">
            {productionRecords.slice(0, 5).map((record) => (
              <div key={record.id} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Factory className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <div className="font-medium text-slate-900">{record.product_name}</div>
                    <div className="text-sm text-slate-500">
                      {record.production_date && format(new Date(record.production_date), 'dd/MM/yyyy')} • {t('batch')}: {record.batch_number}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-slate-900">{record.quantity_produced} {t('pcs')}</div>
                  <Badge className={
                    record.quality_status === 'approved' ? 'bg-green-100 text-green-800' :
                    record.quality_status === 'rejected' ? 'bg-red-100 text-red-800' :
                    'bg-yellow-100 text-yellow-800'
                  }>
                    {t(record.quality_status)}
                  </Badge>
                </div>
              </div>
            ))}
            {productionRecords.length === 0 && (
              <div className="text-center py-8 text-slate-500">
                <Factory className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                <p>{t('noProductionData')}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
