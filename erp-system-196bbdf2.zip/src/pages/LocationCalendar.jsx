import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Calendar as CalendarIcon,
  Plus,
  MapPin,
  CheckCircle2,
  Clock,
  XCircle,
  AlertCircle,
} from "lucide-react";
import { useLanguage } from "@/components/LanguageContext";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, isWithinInterval, startOfWeek, endOfWeek } from "date-fns";
import { da } from "date-fns/locale";

export default function LocationCalendar() {
  const { t } = useLanguage();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingBooking, setEditingBooking] = useState(null);
  const [selectedLocation, setSelectedLocation] = useState("Ebeltoft");
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const queryClient = useQueryClient();

  const { data: bookings = [] } = useQuery({
    queryKey: ['locationBookings'],
    queryFn: () => base44.entities.LocationBooking.list('-start_date'),
  });

  const { data: projects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.filter({ status: 'active' }),
  });

  const createBookingMutation = useMutation({
    mutationFn: (data) => base44.entities.LocationBooking.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['locationBookings']);
      setDialogOpen(false);
      setEditingBooking(null);
      alert('✅ Booking oprettet succesfuldt!');
    },
  });

  const updateBookingMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.LocationBooking.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['locationBookings']);
      setDialogOpen(false);
      setEditingBooking(null);
      alert('✅ Booking opdateret succesfuldt!');
    },
  });

  const deleteBookingMutation = useMutation({
    mutationFn: (id) => base44.entities.LocationBooking.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['locationBookings']);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = {
      location: "Ebeltoft",
      project_name: formData.get('project_name'),
      start_date: formData.get('start_date'),
      end_date: formData.get('end_date'),
      purpose: formData.get('purpose'),
      booked_by: formData.get('booked_by'),
      contact_person: formData.get('contact_person'),
      notes: formData.get('notes'),
      status: formData.get('status'),
    };

    console.log('Submitting booking:', data);

    if (editingBooking) {
      updateBookingMutation.mutate({ id: editingBooking.id, data });
    } else {
      createBookingMutation.mutate(data);
    }
  };

  const handleDelete = (booking) => {
    const code = prompt('Indtast admin kode for at slette:');
    if (code === 'DDigital') {
      if (confirm(`Er du sikker på at du vil slette booking for "${booking.project_name}"?`)) {
        deleteBookingMutation.mutate(booking.id);
      }
    } else if (code !== null) {
      alert('Forkert admin kode');
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'confirmed': return <CheckCircle2 className="w-4 h-4" />;
      case 'in_use': return <AlertCircle className="w-4 h-4" />;
      case 'completed': return <CheckCircle2 className="w-4 h-4" />;
      case 'cancelled': return <XCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      planned: "bg-blue-100 text-blue-800",
      confirmed: "bg-green-100 text-green-800",
      in_use: "bg-orange-100 text-orange-800",
      completed: "bg-slate-100 text-slate-800",
      cancelled: "bg-red-100 text-red-800",
    };
    return colors[status] || colors.planned;
  };

  // Get bookings for selected location
  const locationBookings = bookings.filter(b => b.location === selectedLocation);

  // Generate calendar days
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calendarStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const calendarEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  // Check if a day has bookings
  const getBookingsForDay = (day) => {
    return locationBookings.filter(booking => {
      if (!booking.start_date || !booking.end_date) return false;
      
      const start = new Date(booking.start_date + 'T00:00:00');
      const end = new Date(booking.end_date + 'T23:59:59');
      const checkDay = new Date(day.getFullYear(), day.getMonth(), day.getDate(), 12, 0, 0);
      
      return checkDay >= start && checkDay <= end;
    });
  };

  const upcomingBookings = locationBookings.filter(b => 
    new Date(b.start_date) >= new Date() && b.status !== 'cancelled' && b.status !== 'completed'
  ).slice(0, 5);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Lokations Kalender</h2>
          <p className="text-slate-500 mt-1">Se og administrer lokationsbookinger</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setEditingBooking(null)}>
              <Plus className="w-4 h-4 mr-2" />
              Ny Booking
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingBooking ? 'Rediger Booking' : 'Ny Booking'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input type="hidden" name="location" value="Ebeltoft" />
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="location">Lokation</Label>
                  <Input 
                    name="location" 
                    value="Ebeltoft" 
                    disabled 
                    className="bg-slate-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="project_name">Projekt *</Label>
                  <Input
                    id="project_name"
                    name="project_name"
                    list="projects-list"
                    defaultValue={editingBooking?.project_name}
                    required
                  />
                  <datalist id="projects-list">
                    {projects.map(p => (
                      <option key={p.id} value={p.name} />
                    ))}
                  </datalist>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="start_date">Start Dato *</Label>
                  <Input
                    id="start_date"
                    name="start_date"
                    type="date"
                    defaultValue={editingBooking?.start_date}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="end_date">Slut Dato *</Label>
                  <Input
                    id="end_date"
                    name="end_date"
                    type="date"
                    defaultValue={editingBooking?.end_date}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="purpose">Formål</Label>
                <Input
                  id="purpose"
                  name="purpose"
                  defaultValue={editingBooking?.purpose}
                  placeholder="Eks. Test af radar system"
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="booked_by">Booket af</Label>
                  <Input
                    id="booked_by"
                    name="booked_by"
                    defaultValue={editingBooking?.booked_by}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contact_person">Kontaktperson</Label>
                  <Input
                    id="contact_person"
                    name="contact_person"
                    defaultValue={editingBooking?.contact_person}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Noter</Label>
                <Textarea
                  id="notes"
                  name="notes"
                  defaultValue={editingBooking?.notes}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status *</Label>
                <Select name="status" defaultValue={editingBooking?.status || 'planned'}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="planned">Planlagt</SelectItem>
                    <SelectItem value="confirmed">Bekræftet</SelectItem>
                    <SelectItem value="in_use">I brug</SelectItem>
                    <SelectItem value="completed">Afsluttet</SelectItem>
                    <SelectItem value="cancelled">Annulleret</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <input type="hidden" name="status" value="planned" />

              <div className="flex justify-end gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Annuller
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  {editingBooking ? 'Gem ændringer' : 'Opret booking'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Location Info & Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="md:col-span-2 border-blue-200/60 bg-blue-50/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Ebeltoft Test Lokation</h3>
                <p className="text-sm text-slate-600">Booking kalender for test aktiviteter</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-slate-200/60 bg-white/80">
          <CardContent className="p-4">
            <div className="text-sm text-slate-600 mb-1">Total Bookinger</div>
            <div className="text-2xl font-bold text-blue-600">{locationBookings.length}</div>
          </CardContent>
        </Card>
        
        <Card className="border-green-200/60 bg-green-50/50">
          <CardContent className="p-4">
            <div className="text-sm text-slate-600 mb-1">Kommende</div>
            <div className="text-2xl font-bold text-green-600">{upcomingBookings.length}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Calendar */}
        <Card className="lg:col-span-2 border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="border-b border-slate-200/60">
            <div className="flex justify-between items-center">
              <CardTitle>{format(currentMonth, 'MMMM yyyy', { locale: da })}</CardTitle>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))}
                >
                  ←
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentMonth(new Date())}
                >
                  I dag
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))}
                >
                  →
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <div className="grid grid-cols-7 gap-2">
              {['Man', 'Tir', 'Ons', 'Tor', 'Fre', 'Lør', 'Søn'].map(day => (
                <div key={day} className="text-center text-sm font-semibold text-slate-600 py-2">
                  {day}
                </div>
              ))}
              {calendarDays.map((day, index) => {
                const dayBookings = getBookingsForDay(day);
                const isCurrentMonth = isSameMonth(day, currentMonth);
                const isToday = isSameDay(day, new Date());

                return (
                  <div
                    key={index}
                    className={`min-h-24 p-2 border rounded-lg transition-all ${
                      !isCurrentMonth ? 'bg-slate-50 text-slate-400' : 'bg-white hover:bg-slate-50'
                    } ${isToday ? 'border-blue-600 border-2 bg-blue-50' : 'border-slate-200'}
                    ${dayBookings.length > 0 && isCurrentMonth ? 'ring-2 ring-blue-200' : ''}`}
                  >
                    <div className="text-sm font-medium mb-1">{format(day, 'd')}</div>
                    {dayBookings.length > 0 && (
                      <div className="text-xs text-blue-600 font-semibold mb-1">
                        📍 {dayBookings.length} booking{dayBookings.length > 1 ? 's' : ''}
                      </div>
                    )}
                    {dayBookings.map((booking, idx) => (
                      <div
                        key={idx}
                        className={`text-xs px-2 py-1 rounded mb-1 cursor-pointer font-medium shadow-sm border-l-2 ${
                          booking.status === 'confirmed' ? 'bg-green-100 text-green-800 border-green-500' :
                          booking.status === 'in_use' ? 'bg-orange-100 text-orange-800 border-orange-500' :
                          booking.status === 'planned' ? 'bg-blue-100 text-blue-800 border-blue-500' :
                          'bg-slate-100 text-slate-600 border-slate-400'
                        }`}
                        onClick={() => {
                          setEditingBooking(booking);
                          setDialogOpen(true);
                        }}
                      >
                        <div className="font-semibold truncate">{booking.project_name}</div>
                        <div className="text-[10px] opacity-75">{booking.status}</div>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Bookings */}
        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="border-b border-slate-200/60">
            <CardTitle className="flex items-center gap-2">
              <CalendarIcon className="w-5 h-5" />
              Kommende Bookinger
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            {upcomingBookings.length > 0 ? (
              <div className="space-y-3">
                {upcomingBookings.map(booking => (
                  <div
                    key={booking.id}
                    className="p-3 bg-slate-50 rounded-lg border border-slate-200 hover:bg-slate-100"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div 
                        className="font-medium text-sm cursor-pointer flex-1"
                        onClick={() => {
                          setEditingBooking(booking);
                          setDialogOpen(true);
                        }}
                      >
                        {booking.project_name}
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={getStatusColor(booking.status)}>
                          {getStatusIcon(booking.status)}
                        </Badge>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDelete(booking);
                          }}
                          className="h-6 w-6 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    <div 
                      className="text-xs text-slate-600 space-y-1 cursor-pointer"
                      onClick={() => {
                        setEditingBooking(booking);
                        setDialogOpen(true);
                      }}
                    >
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {booking.location}
                      </div>
                      <div className="flex items-center gap-1">
                        <CalendarIcon className="w-3 h-3" />
                        {format(new Date(booking.start_date), 'dd/MM')} - {format(new Date(booking.end_date), 'dd/MM')}
                      </div>
                      {booking.purpose && (
                        <div className="text-slate-500">{booking.purpose}</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-slate-500 text-center py-8">
                Ingen kommende bookinger
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}