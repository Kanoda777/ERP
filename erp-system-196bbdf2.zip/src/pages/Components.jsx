import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Plus,
  Search,
  Settings,
  FileText,
  Upload,
  Download,
  Trash2,
  Loader2,
  Eye,
  Wrench,
  Clock
} from "lucide-react";
import { useLanguage } from "@/components/LanguageContext";
import ExportButton from "@/components/ExportButton";
import { format } from "date-fns";

export default function Components() {
  const { t } = useLanguage();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [taskDialogOpen, setTaskDialogOpen] = useState(false);
  const [editingComponent, setEditingComponent] = useState(null);
  const [viewingComponent, setViewingComponent] = useState(null);
  const [selectedComponentForTask, setSelectedComponentForTask] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [uploadingManual, setUploadingManual] = useState(false);
  const [uploadingDrawing, setUploadingDrawing] = useState(false);
  const [manualFiles, setManualFiles] = useState([]);
  const [drawingFiles, setDrawingFiles] = useState([]);
  const [maintenanceTasksToAdd, setMaintenanceTasksToAdd] = useState([]);
  const [analyzingDatasheet, setAnalyzingDatasheet] = useState(false);
  const queryClient = useQueryClient();

  const { data: components = [] } = useQuery({
    queryKey: ['components'],
    queryFn: () => base44.entities.Component.list('-created_date'),
  });

  const { data: maintenanceTasks = [] } = useQuery({
    queryKey: ['maintenanceTasks'],
    queryFn: () => base44.entities.MaintenanceTask.list(),
  });

  const { data: suppliers = [] } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => base44.entities.Supplier.filter({ status: 'active' }),
  });

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
  });

  const createComponentMutation = useMutation({
    mutationFn: async (data) => {
      const component = await base44.entities.Component.create(data);
      
      // Create product in inventory with 0 stock
      await base44.entities.Product.create({
        name: component.name,
        sku: component.component_id,
        description: component.description || `Komponent: ${component.name}`,
        category: 'components',
        unit_price: component.unit_price || 0,
        current_stock: 0,
        min_stock_level: 0,
        reorder_quantity: 0,
        supplier_id: component.supplier_id,
        unit: 'stk',
      });
      
      // Create maintenance tasks if any
      if (maintenanceTasksToAdd.length > 0) {
        for (const task of maintenanceTasksToAdd) {
          await base44.entities.MaintenanceTask.create({
            ...task,
            component_id: component.id,
            component_name: component.name,
          });
        }
      }
      
      return component;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['components']);
      queryClient.invalidateQueries(['maintenanceTasks']);
      queryClient.invalidateQueries(['products']);
      setDialogOpen(false);
      setEditingComponent(null);
      setManualFiles([]);
      setDrawingFiles([]);
      setMaintenanceTasksToAdd([]);
    },
  });

  const updateComponentMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      const component = await base44.entities.Component.update(id, data);
      
      // Create new maintenance tasks if any
      if (maintenanceTasksToAdd.length > 0) {
        for (const task of maintenanceTasksToAdd) {
          await base44.entities.MaintenanceTask.create({
            ...task,
            component_id: id,
            component_name: data.name,
          });
        }
      }
      
      return component;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['components']);
      queryClient.invalidateQueries(['maintenanceTasks']);
      setDialogOpen(false);
      setEditingComponent(null);
      setManualFiles([]);
      setDrawingFiles([]);
      setMaintenanceTasksToAdd([]);
    },
  });

  const deleteComponentMutation = useMutation({
    mutationFn: (id) => base44.entities.Component.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['components']);
    },
  });

  const createTaskMutation = useMutation({
    mutationFn: (data) => base44.entities.MaintenanceTask.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['maintenanceTasks']);
      setTaskDialogOpen(false);
      setSelectedComponentForTask(null);
    },
  });

  const handleFileUpload = async (e, type) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    type === 'manual' ? setUploadingManual(true) : setUploadingDrawing(true);
    try {
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        const fileData = {
          name: file.name,
          file_url,
          file_type: file.name.split('.').pop(),
          uploaded_date: format(new Date(), 'yyyy-MM-dd'),
        };
        if (type === 'manual') {
          setManualFiles(prev => [...prev, fileData]);
        } else {
          setDrawingFiles(prev => [...prev, { ...fileData, type: 'assembly' }]);
        }
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Fejl ved upload');
    } finally {
      type === 'manual' ? setUploadingManual(false) : setUploadingDrawing(false);
    }
  };

  const handleDatasheetAnalysis = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setAnalyzingDatasheet(true);
    try {
      // Upload file first
      const { file_url } = await base44.integrations.Core.UploadFile({ file });

      // Analyze with AI
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyser dette tekniske datasheet og udtræk følgende specifikationer i JSON format:
        - name (produkt navn)
        - component_id (produkt nummer/model nummer)
        - manufacturer (producent)
        - model (model nummer)
        - description (kort beskrivelse)
        - voltage (spænding)
        - power (effekt)
        - dimensions (dimensioner i cm eller mm)
        - weight (vægt i kg)
        - operating_temp (driftstemperatur)
        - ip_rating (IP klassificering)
        - certifications (certificeringer)
        - lifecycle_expectancy_years (forventet levetid i år, hvis nævnt)
        
        Returnér kun de felter du finder information om. Hvis et felt ikke findes, udelad det.`,
        file_urls: [file_url],
        response_json_schema: {
          type: "object",
          properties: {
            name: { type: "string" },
            component_id: { type: "string" },
            manufacturer: { type: "string" },
            model: { type: "string" },
            description: { type: "string" },
            voltage: { type: "string" },
            power: { type: "string" },
            dimensions: { type: "string" },
            weight: { type: "string" },
            operating_temp: { type: "string" },
            ip_rating: { type: "string" },
            certifications: { type: "string" },
            lifecycle_expectancy_years: { type: "number" }
          }
        }
      });

      // Populate form fields
      if (result.name) document.getElementById('name').value = result.name;
      if (result.component_id) document.getElementById('component_id').value = result.component_id;
      if (result.manufacturer) document.getElementById('manufacturer').value = result.manufacturer;
      if (result.model) document.getElementById('model').value = result.model;
      if (result.description) document.getElementById('description').value = result.description;
      if (result.voltage) document.getElementById('voltage').value = result.voltage;
      if (result.power) document.getElementById('power').value = result.power;
      if (result.dimensions) document.getElementById('dimensions').value = result.dimensions;
      if (result.weight) document.getElementById('weight').value = result.weight;
      if (result.operating_temp) document.getElementById('operating_temp').value = result.operating_temp;
      if (result.ip_rating) document.getElementById('ip_rating').value = result.ip_rating;
      if (result.certifications) document.getElementById('certifications').value = result.certifications;
      if (result.lifecycle_expectancy_years) document.getElementById('lifecycle_expectancy_years').value = result.lifecycle_expectancy_years;

      // Add the datasheet as a manual
      setManualFiles(prev => [...prev, {
        name: file.name,
        file_url,
        file_type: file.name.split('.').pop(),
        uploaded_date: format(new Date(), 'yyyy-MM-dd'),
      }]);

      alert('✅ Datasheet analyseret! Specifikationer udfyldt automatisk.');
    } catch (error) {
      console.error('Analysis error:', error);
      alert('Fejl ved analyse af datasheet. Prøv igen eller udfyld manuelt.');
    } finally {
      setAnalyzingDatasheet(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    
    const data = {
      name: formData.get('name'),
      component_id: formData.get('component_id'),
      category: formData.get('category'),
      manufacturer: formData.get('manufacturer'),
      model: formData.get('model'),
      description: formData.get('description'),
      technical_specifications: {
        voltage: formData.get('voltage'),
        power: formData.get('power'),
        dimensions: formData.get('dimensions'),
        weight: formData.get('weight'),
        operating_temp: formData.get('operating_temp'),
        ip_rating: formData.get('ip_rating'),
        certifications: formData.get('certifications'),
      },
      supplier_id: formData.get('supplier_id'),
      supplier_name: suppliers.find(s => s.id === formData.get('supplier_id'))?.name,
      lead_time_days: parseInt(formData.get('lead_time_days')) || 0,
      unit_price: parseFloat(formData.get('unit_price')) || 0,
      lifecycle_expectancy_years: parseInt(formData.get('lifecycle_expectancy_years')) || 0,
      criticality: formData.get('criticality'),
      failure_impact: formData.get('failure_impact'),
      manuals: manualFiles,
      drawings: drawingFiles,
      notes: formData.get('notes'),
      status: formData.get('status'),
    };

    if (editingComponent) {
      updateComponentMutation.mutate({ id: editingComponent.id, data });
    } else {
      createComponentMutation.mutate(data);
    }
  };

  const handleTaskSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    
    const data = {
      component_id: selectedComponentForTask.id,
      component_name: selectedComponentForTask.name,
      task_name: formData.get('task_name'),
      task_type: formData.get('task_type'),
      description: formData.get('description'),
      interval_type: formData.get('interval_type'),
      interval_value: parseInt(formData.get('interval_value')),
      estimated_duration_hours: parseFloat(formData.get('estimated_duration_hours')) || 0,
      procedure: formData.get('procedure'),
      safety_notes: formData.get('safety_notes'),
      responsible_role: formData.get('responsible_role'),
      priority: formData.get('priority'),
      status: 'active',
    };

    createTaskMutation.mutate(data);
  };

  const filteredComponents = components.filter(comp =>
    comp.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    comp.component_id?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDelete = (component) => {
    const code = prompt('Indtast admin kode for at slette:');
    if (code === 'DDigital') {
      if (confirm(`Er du sikker på at du vil slette "${component.name}"?`)) {
        deleteComponentMutation.mutate(component.id);
      }
    } else if (code !== null) {
      alert('Forkert admin kode');
    }
  };

  const exportColumns = [
    { label: 'Navn', accessor: (item) => item.name },
    { label: 'ID', accessor: (item) => item.component_id },
    { label: 'Kategori', accessor: (item) => item.category },
    { label: 'Producent', accessor: (item) => item.manufacturer || '-' },
    { label: 'Model', accessor: (item) => item.model || '-' },
    { label: 'Kritikalitet', accessor: (item) => item.criticality || '-' },
    { label: 'Levetid (år)', accessor: (item) => item.lifecycle_expectancy_years || '-' },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Komponenter</h2>
          <p className="text-slate-500 mt-1">Administrer komponenter med tekniske specs og vedligeholdelse</p>
        </div>
        <div className="flex gap-3">
          <ExportButton
            data={filteredComponents}
            filename={`components-${new Date().toISOString().split('T')[0]}`}
            columns={exportColumns}
          />
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => {
                setEditingComponent(null);
                setManualFiles([]);
                setDrawingFiles([]);
                setMaintenanceTasksToAdd([]);
              }}>
                <Plus className="w-4 h-4 mr-2" />
                Ny Komponent
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingComponent ? 'Rediger Komponent' : 'Ny Komponent'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Info & Specs Section */}
                <div className="space-y-4">
                    {/* AI Datasheet Analysis */}
                    <div className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border-2 border-dashed border-purple-200">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-base font-semibold text-purple-900">🤖 AI Datasheet Analyse</Label>
                          <p className="text-sm text-purple-700 mt-1">Upload et PDF datasheet og få specifikationer udfyldt automatisk</p>
                        </div>
                        <label htmlFor="datasheet-upload" className="cursor-pointer">
                          <div className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                            {analyzingDatasheet ? (
                              <>
                                <Loader2 className="w-4 h-4 animate-spin" />
                                Analyserer...
                              </>
                            ) : (
                              <>
                                <Upload className="w-4 h-4" />
                                Upload Datasheet
                              </>
                            )}
                          </div>
                          <input
                            id="datasheet-upload"
                            type="file"
                            accept=".pdf,.png,.jpg,.jpeg"
                            onChange={handleDatasheetAnalysis}
                            className="hidden"
                            disabled={analyzingDatasheet}
                          />
                        </label>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Navn *</Label>
                        <Input id="name" name="name" defaultValue={editingComponent?.name} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="component_id">Komponent ID *</Label>
                        <Input id="component_id" name="component_id" defaultValue={editingComponent?.component_id} required />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="category">Kategori</Label>
                        <Select name="category" defaultValue={editingComponent?.category}>
                          <SelectTrigger><SelectValue placeholder="Vælg kategori" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="mechanical">Mekanisk</SelectItem>
                            <SelectItem value="electrical">Elektrisk</SelectItem>
                            <SelectItem value="hydraulic">Hydraulisk</SelectItem>
                            <SelectItem value="pneumatic">Pneumatisk</SelectItem>
                            <SelectItem value="electronic">Elektronisk</SelectItem>
                            <SelectItem value="software">Software</SelectItem>
                            <SelectItem value="structural">Strukturel</SelectItem>
                            <SelectItem value="other">Andet</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="manufacturer">Producent</Label>
                        <Input id="manufacturer" name="manufacturer" defaultValue={editingComponent?.manufacturer} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="model">Model</Label>
                        <Input id="model" name="model" defaultValue={editingComponent?.model} />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="description">Beskrivelse</Label>
                      <Textarea id="description" name="description" defaultValue={editingComponent?.description} rows={3} />
                    </div>

                    <div className="border-t pt-4 mt-4">
                      <h3 className="font-semibold text-lg mb-4">Tekniske Specifikationer</h3>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="voltage">Spænding</Label>
                          <Input id="voltage" name="voltage" defaultValue={editingComponent?.technical_specifications?.voltage} placeholder="Eks. 230V AC" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="power">Effekt</Label>
                          <Input id="power" name="power" defaultValue={editingComponent?.technical_specifications?.power} placeholder="Eks. 1.5 kW" />
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4 mt-4">
                        <div className="space-y-2">
                          <Label htmlFor="dimensions">Dimensioner</Label>
                          <Input id="dimensions" name="dimensions" defaultValue={editingComponent?.technical_specifications?.dimensions} placeholder="Eks. 500x300x200 mm" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="weight">Vægt</Label>
                          <Input id="weight" name="weight" defaultValue={editingComponent?.technical_specifications?.weight} placeholder="Eks. 25 kg" />
                        </div>
                      </div>

                      <div className="grid md:grid-cols-3 gap-4 mt-4">
                        <div className="space-y-2">
                          <Label htmlFor="operating_temp">Driftstemperatur</Label>
                          <Input id="operating_temp" name="operating_temp" defaultValue={editingComponent?.technical_specifications?.operating_temp} placeholder="Eks. -20°C til +60°C" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="ip_rating">IP Klassificering</Label>
                          <Input id="ip_rating" name="ip_rating" defaultValue={editingComponent?.technical_specifications?.ip_rating} placeholder="Eks. IP67" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="certifications">Certificeringer</Label>
                          <Input id="certifications" name="certifications" defaultValue={editingComponent?.technical_specifications?.certifications} placeholder="Eks. CE, UL" />
                        </div>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-3 gap-4 mt-4">
                      <div className="space-y-2">
                        <Label htmlFor="criticality">Kritikalitet</Label>
                        <Select name="criticality" defaultValue={editingComponent?.criticality}>
                          <SelectTrigger><SelectValue placeholder="Vælg" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="critical">Critical</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="failure_impact">Fejlkonsekvens</Label>
                        <Select name="failure_impact" defaultValue={editingComponent?.failure_impact}>
                          <SelectTrigger><SelectValue placeholder="Vælg" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="total_shutdown">Total stopning</SelectItem>
                            <SelectItem value="partial_shutdown">Delvis stopning</SelectItem>
                            <SelectItem value="degraded_performance">Nedsat ydelse</SelectItem>
                            <SelectItem value="minimal">Minimal</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lifecycle_expectancy_years">Levetid (år)</Label>
                        <Input id="lifecycle_expectancy_years" name="lifecycle_expectancy_years" type="number" defaultValue={editingComponent?.lifecycle_expectancy_years} />
                      </div>
                    </div>
                </div>

                {/* Dokumenter Section */}
                <div className="border-t pt-6 space-y-4">
                  <h3 className="text-lg font-semibold">Dokumenter</h3>
                    <div className="space-y-2 p-4 bg-slate-50 rounded-lg border">
                      <div className="flex items-center justify-between">
                        <Label className="flex items-center gap-2">
                          <FileText className="w-4 h-4" />
                          Manualer & Dokumenter
                        </Label>
                        <label htmlFor="manual-upload" className="cursor-pointer">
                          <div className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm">
                            {uploadingManual ? <><Loader2 className="w-4 h-4 animate-spin" />Uploader...</> : <><Upload className="w-4 h-4" />Upload</>}
                          </div>
                          <input id="manual-upload" type="file" multiple accept=".pdf,.doc,.docx" onChange={(e) => handleFileUpload(e, 'manual')} className="hidden" disabled={uploadingManual} />
                        </label>
                      </div>
                      {manualFiles.length > 0 ? (
                        <div className="space-y-2 mt-3">
                          {manualFiles.map((file, idx) => (
                            <div key={idx} className="flex items-center justify-between p-2 bg-white rounded border">
                              <div className="flex items-center gap-2">
                                <FileText className="w-4 h-4 text-blue-600" />
                                <div className="text-sm">{file.name}</div>
                              </div>
                              <div className="flex gap-2">
                                <a href={file.file_url} target="_blank" rel="noopener noreferrer">
                                  <Button type="button" size="sm" variant="ghost"><Download className="w-4 h-4" /></Button>
                                </a>
                                <Button type="button" size="sm" variant="ghost" onClick={() => setManualFiles(prev => prev.filter((_, i) => i !== idx))}>
                                  <Trash2 className="w-4 h-4 text-red-500" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : <p className="text-sm text-slate-500 text-center py-4">Ingen filer uploadet</p>}
                    </div>

                    <div className="space-y-2 p-4 bg-slate-50 rounded-lg border">
                      <div className="flex items-center justify-between">
                        <Label className="flex items-center gap-2">
                          <FileText className="w-4 h-4" />
                          Tegninger & Diagrammer
                        </Label>
                        <label htmlFor="drawing-upload" className="cursor-pointer">
                          <div className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm">
                            {uploadingDrawing ? <><Loader2 className="w-4 h-4 animate-spin" />Uploader...</> : <><Upload className="w-4 h-4" />Upload</>}
                          </div>
                          <input id="drawing-upload" type="file" multiple accept=".pdf,.dwg,.dxf,.png,.jpg" onChange={(e) => handleFileUpload(e, 'drawing')} className="hidden" disabled={uploadingDrawing} />
                        </label>
                      </div>
                      {drawingFiles.length > 0 ? (
                        <div className="space-y-2 mt-3">
                          {drawingFiles.map((file, idx) => (
                            <div key={idx} className="flex items-center justify-between p-2 bg-white rounded border">
                              <div className="flex items-center gap-2">
                                <FileText className="w-4 h-4 text-purple-600" />
                                <div className="text-sm">{file.name}</div>
                              </div>
                              <div className="flex gap-2">
                                <a href={file.file_url} target="_blank" rel="noopener noreferrer">
                                  <Button type="button" size="sm" variant="ghost"><Download className="w-4 h-4" /></Button>
                                </a>
                                <Button type="button" size="sm" variant="ghost" onClick={() => setDrawingFiles(prev => prev.filter((_, i) => i !== idx))}>
                                  <Trash2 className="w-4 h-4 text-red-500" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : <p className="text-sm text-slate-500 text-center py-4">Ingen tegninger uploadet</p>}
                    </div>
                </div>

                {/* Vedligehold Section */}
                <div className="border-t pt-6 space-y-4">
                  <h3 className="text-lg font-semibold">Vedligeholdelsesopgaver ({maintenanceTasksToAdd.length})</h3>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <Label className="text-base font-semibold">Vedligeholdelsesopgaver</Label>
                        <Button
                          type="button"
                          size="sm"
                          onClick={() => {
                            setMaintenanceTasksToAdd([...maintenanceTasksToAdd, {
                              task_name: '',
                              task_type: 'inspection',
                              interval_type: 'months',
                              interval_value: 6,
                              priority: 'medium',
                            }]);
                          }}
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Tilføj Opgave
                        </Button>
                      </div>

                      {maintenanceTasksToAdd.length === 0 ? (
                        <div className="text-center py-8 text-slate-500 bg-slate-50 rounded-lg border-2 border-dashed">
                          <Wrench className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                          <p>Ingen vedligeholdelsesopgaver endnu</p>
                          <p className="text-sm mt-1">Klik "Tilføj Opgave" for at komme i gang</p>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {maintenanceTasksToAdd.map((task, index) => (
                            <Card key={index} className="p-4 bg-slate-50">
                              <div className="space-y-3">
                                <div className="flex justify-between items-start">
                                  <Label className="font-semibold">Opgave #{index + 1}</Label>
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => {
                                      setMaintenanceTasksToAdd(maintenanceTasksToAdd.filter((_, i) => i !== index));
                                    }}
                                  >
                                    <Trash2 className="w-4 h-4 text-red-500" />
                                  </Button>
                                </div>

                                <div className="grid md:grid-cols-2 gap-3">
                                  <div className="space-y-2">
                                    <Label>Opgave Navn *</Label>
                                    <Input
                                      value={task.task_name}
                                      onChange={(e) => {
                                        const updated = [...maintenanceTasksToAdd];
                                        updated[index].task_name = e.target.value;
                                        setMaintenanceTasksToAdd(updated);
                                      }}
                                      placeholder="Eks. Smøring af lejer"
                                    />
                                  </div>
                                  <div className="space-y-2">
                                    <Label>Type</Label>
                                    <Select
                                      value={task.task_type}
                                      onValueChange={(value) => {
                                        const updated = [...maintenanceTasksToAdd];
                                        updated[index].task_type = value;
                                        setMaintenanceTasksToAdd(updated);
                                      }}
                                    >
                                      <SelectTrigger><SelectValue /></SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="inspection">Inspektion</SelectItem>
                                        <SelectItem value="lubrication">Smøring</SelectItem>
                                        <SelectItem value="calibration">Kalibrering</SelectItem>
                                        <SelectItem value="cleaning">Rengøring</SelectItem>
                                        <SelectItem value="replacement">Udskiftning</SelectItem>
                                        <SelectItem value="testing">Test</SelectItem>
                                        <SelectItem value="adjustment">Justering</SelectItem>
                                        <SelectItem value="other">Andet</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                </div>

                                <div className="space-y-2">
                                  <Label>Beskrivelse</Label>
                                  <Textarea
                                    value={task.description || ''}
                                    onChange={(e) => {
                                      const updated = [...maintenanceTasksToAdd];
                                      updated[index].description = e.target.value;
                                      setMaintenanceTasksToAdd(updated);
                                    }}
                                    rows={2}
                                    placeholder="Kort beskrivelse af opgaven..."
                                  />
                                </div>

                                <div className="grid grid-cols-3 gap-3">
                                  <div className="space-y-2">
                                    <Label>Interval</Label>
                                    <Input
                                      type="number"
                                      value={task.interval_value}
                                      onChange={(e) => {
                                        const updated = [...maintenanceTasksToAdd];
                                        updated[index].interval_value = parseInt(e.target.value) || 1;
                                        setMaintenanceTasksToAdd(updated);
                                      }}
                                    />
                                  </div>
                                  <div className="space-y-2">
                                    <Label>Enhed</Label>
                                    <Select
                                      value={task.interval_type}
                                      onValueChange={(value) => {
                                        const updated = [...maintenanceTasksToAdd];
                                        updated[index].interval_type = value;
                                        setMaintenanceTasksToAdd(updated);
                                      }}
                                    >
                                      <SelectTrigger><SelectValue /></SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="hours">Timer</SelectItem>
                                        <SelectItem value="days">Dage</SelectItem>
                                        <SelectItem value="weeks">Uger</SelectItem>
                                        <SelectItem value="months">Måneder</SelectItem>
                                        <SelectItem value="years">År</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <div className="space-y-2">
                                    <Label>Prioritet</Label>
                                    <Select
                                      value={task.priority}
                                      onValueChange={(value) => {
                                        const updated = [...maintenanceTasksToAdd];
                                        updated[index].priority = value;
                                        setMaintenanceTasksToAdd(updated);
                                      }}
                                    >
                                      <SelectTrigger><SelectValue /></SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="critical">Critical</SelectItem>
                                        <SelectItem value="high">High</SelectItem>
                                        <SelectItem value="medium">Medium</SelectItem>
                                        <SelectItem value="low">Low</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                </div>
                              </div>
                            </Card>
                          ))}
                        </div>
                      )}
                    </div>
                </div>

                {/* Øvrigt Section */}
                <div className="border-t pt-6 space-y-4">
                  <h3 className="text-lg font-semibold">Øvrigt</h3>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="supplier_id">Leverandør</Label>
                        <Select name="supplier_id" defaultValue={editingComponent?.supplier_id}>
                          <SelectTrigger><SelectValue placeholder="Vælg" /></SelectTrigger>
                          <SelectContent>
                            {suppliers.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lead_time_days">Leveringstid (dage)</Label>
                        <Input id="lead_time_days" name="lead_time_days" type="number" defaultValue={editingComponent?.lead_time_days} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="unit_price">Pris (DKK)</Label>
                        <Input id="unit_price" name="unit_price" type="number" step="0.01" defaultValue={editingComponent?.unit_price} />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="notes">Noter</Label>
                      <Textarea id="notes" name="notes" defaultValue={editingComponent?.notes} rows={4} />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="status">Status</Label>
                      <Select name="status" defaultValue={editingComponent?.status || 'active'}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Aktiv</SelectItem>
                          <SelectItem value="obsolete">Forældet</SelectItem>
                          <SelectItem value="discontinued">Udgået</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                </div>

                <div className="flex justify-end gap-3 pt-6 border-t">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Annuller</Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    {editingComponent ? 'Gem' : 'Opret'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-slate-200/60 bg-white/80">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600">Total Komponenter</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{components.length}</div>
          </CardContent>
        </Card>
        <Card className="border-red-200/60 bg-red-50/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600">Kritiske</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{components.filter(c => c.criticality === 'critical').length}</div>
          </CardContent>
        </Card>
        <Card className="border-blue-200/60 bg-blue-50/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600">Vedligeholdelsesopgaver</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{maintenanceTasks.length}</div>
          </CardContent>
        </Card>
        <Card className="border-green-200/60 bg-green-50/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600">Aktive</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{components.filter(c => c.status === 'active').length}</div>
          </CardContent>
        </Card>
      </div>

      {/* View Component Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <span>{viewingComponent?.name}</span>
              <Button size="sm" onClick={() => {
                setViewDialogOpen(false);
                setTimeout(() => {
                  setEditingComponent(viewingComponent);
                  setManualFiles(viewingComponent?.manuals || []);
                  setDrawingFiles(viewingComponent?.drawings || []);
                  setDialogOpen(true);
                }, 50);
              }}>
                Rediger
              </Button>
            </DialogTitle>
            <p className="text-sm text-slate-500">ID: {viewingComponent?.component_id}</p>
          </DialogHeader>
          
          {viewingComponent && (
            <Tabs defaultValue="info">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="info">Information</TabsTrigger>
                <TabsTrigger value="maintenance">Vedligehold ({maintenanceTasks.filter(t => t.component_id === viewingComponent.id).length})</TabsTrigger>
                <TabsTrigger value="docs">Dokumenter</TabsTrigger>
              </TabsList>

              <TabsContent value="info" className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-slate-500">Kategori</Label>
                    <p className="font-medium">{viewingComponent.category}</p>
                  </div>
                  <div>
                    <Label className="text-slate-500">Kritikalitet</Label>
                    <p className="font-medium">
                      <Badge className={
                        viewingComponent.criticality === 'critical' ? 'bg-red-100 text-red-800' :
                        viewingComponent.criticality === 'high' ? 'bg-orange-100 text-orange-800' :
                        'bg-yellow-100 text-yellow-800'
                      }>
                        {viewingComponent.criticality}
                      </Badge>
                    </p>
                  </div>
                  <div>
                    <Label className="text-slate-500">Producent</Label>
                    <p className="font-medium">{viewingComponent.manufacturer || '-'}</p>
                  </div>
                  <div>
                    <Label className="text-slate-500">Model</Label>
                    <p className="font-medium">{viewingComponent.model || '-'}</p>
                  </div>
                </div>

                {viewingComponent.description && (
                  <div>
                    <Label className="text-slate-500">Beskrivelse</Label>
                    <p className="text-sm mt-1">{viewingComponent.description}</p>
                  </div>
                )}

                {viewingComponent.technical_specifications && (
                  <div className="p-4 bg-slate-50 rounded-lg space-y-2">
                    <Label className="font-semibold">Tekniske Specifikationer</Label>
                    <div className="grid md:grid-cols-2 gap-3 text-sm">
                      {viewingComponent.technical_specifications.voltage && (
                        <div><span className="text-slate-500">Spænding:</span> {viewingComponent.technical_specifications.voltage}</div>
                      )}
                      {viewingComponent.technical_specifications.power && (
                        <div><span className="text-slate-500">Effekt:</span> {viewingComponent.technical_specifications.power}</div>
                      )}
                      {viewingComponent.technical_specifications.dimensions && (
                        <div><span className="text-slate-500">Dimensioner:</span> {viewingComponent.technical_specifications.dimensions}</div>
                      )}
                      {viewingComponent.technical_specifications.weight && (
                        <div><span className="text-slate-500">Vægt:</span> {viewingComponent.technical_specifications.weight}</div>
                      )}
                      {viewingComponent.technical_specifications.ip_rating && (
                        <div><span className="text-slate-500">IP Rating:</span> {viewingComponent.technical_specifications.ip_rating}</div>
                      )}
                    </div>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="maintenance">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-semibold">Vedligeholdelsesopgaver</h3>
                    <Button size="sm" onClick={() => {
                      setSelectedComponentForTask(viewingComponent);
                      setTaskDialogOpen(true);
                    }}>
                      <Plus className="w-4 h-4 mr-2" />
                      Tilføj Opgave
                    </Button>
                  </div>

                  <Table>
                    <TableHeader>
                      <TableRow className="bg-slate-50">
                        <TableHead>Task</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Beskrivelse</TableHead>
                        <TableHead>Interval</TableHead>
                        <TableHead>Varighed</TableHead>
                        <TableHead>Prioritet</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {maintenanceTasks
                        .filter(task => task.component_id === viewingComponent.id)
                        .map(task => (
                          <TableRow key={task.id}>
                            <TableCell className="font-medium">{task.task_name}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{task.task_type}</Badge>
                            </TableCell>
                            <TableCell className="text-sm text-slate-600">{task.description || '-'}</TableCell>
                            <TableCell>
                              {task.interval_value} {task.interval_type}
                            </TableCell>
                            <TableCell>{task.estimated_duration_hours ? `${task.estimated_duration_hours}t` : '-'}</TableCell>
                            <TableCell>
                              <Badge className={
                                task.priority === 'critical' ? 'bg-red-100 text-red-800' :
                                task.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                                'bg-blue-100 text-blue-800'
                              }>
                                {task.priority}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>

                  {maintenanceTasks.filter(t => t.component_id === viewingComponent.id).length === 0 && (
                    <p className="text-center text-slate-500 py-8">Ingen vedligeholdelsesopgaver endnu</p>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="docs" className="space-y-4">
                {viewingComponent.manuals && viewingComponent.manuals.length > 0 && (
                  <div>
                    <Label className="font-semibold mb-2 block">Manualer</Label>
                    <div className="space-y-2">
                      {viewingComponent.manuals.map((manual, idx) => (
                        <div key={idx} className="flex items-center justify-between p-2 bg-slate-50 rounded">
                          <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4 text-blue-600" />
                            <span className="text-sm">{manual.name}</span>
                          </div>
                          <a href={manual.file_url} target="_blank" rel="noopener noreferrer">
                            <Button size="sm" variant="ghost"><Download className="w-4 h-4" /></Button>
                          </a>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {viewingComponent.drawings && viewingComponent.drawings.length > 0 && (
                  <div>
                    <Label className="font-semibold mb-2 block">Tegninger</Label>
                    <div className="space-y-2">
                      {viewingComponent.drawings.map((drawing, idx) => (
                        <div key={idx} className="flex items-center justify-between p-2 bg-slate-50 rounded">
                          <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4 text-purple-600" />
                            <span className="text-sm">{drawing.name}</span>
                          </div>
                          <a href={drawing.file_url} target="_blank" rel="noopener noreferrer">
                            <Button size="sm" variant="ghost"><Download className="w-4 h-4" /></Button>
                          </a>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {(!viewingComponent.manuals || viewingComponent.manuals.length === 0) && 
                 (!viewingComponent.drawings || viewingComponent.drawings.length === 0) && (
                  <p className="text-center text-slate-500 py-8">Ingen dokumenter uploadet</p>
                )}
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>

      {/* Components Table */}
      <Card className="border-slate-200/60 bg-white/80">
        <CardHeader className="border-b border-slate-200/60">
          <div className="flex justify-between items-center">
            <CardTitle>Alle Komponenter</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                placeholder="Søg komponent..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead>Komponent</TableHead>
                <TableHead>ID</TableHead>
                <TableHead>Kategori</TableHead>
                <TableHead>Kritikalitet</TableHead>
                <TableHead className="text-center">Vedligehold</TableHead>
                <TableHead className="text-center">Dokumenter</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredComponents.map((component) => {
                const taskCount = maintenanceTasks.filter(t => t.component_id === component.id).length;
                const docCount = (component.manuals?.length || 0) + (component.drawings?.length || 0);
                
                return (
                  <TableRow key={component.id} className="hover:bg-slate-50">
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Settings className="w-5 h-5 text-blue-600" />
                        <div>
                          <div className="font-medium">{component.name}</div>
                          <div className="text-sm text-slate-500">{component.manufacturer} {component.model}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-sm">{component.component_id}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{component.category}</Badge>
                    </TableCell>
                    <TableCell>
                      {component.criticality && (
                        <Badge className={
                          component.criticality === 'critical' ? 'bg-red-100 text-red-800' :
                          component.criticality === 'high' ? 'bg-orange-100 text-orange-800' :
                          'bg-yellow-100 text-yellow-800'
                        }>
                          {component.criticality}
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge className="bg-blue-100 text-blue-800">
                        <Wrench className="w-3 h-3 mr-1" />
                        {taskCount}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge className="bg-purple-100 text-purple-800">
                        <FileText className="w-3 h-3 mr-1" />
                        {docCount}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => {
                          setViewingComponent(component);
                          setViewDialogOpen(true);
                        }}>
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => {
                          setSelectedComponentForTask(component);
                          setTaskDialogOpen(true);
                        }}>
                          <Plus className="w-4 h-4 mr-1" />
                          Task
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleDelete(component)} className="text-red-600 hover:text-red-700 hover:bg-red-50">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          {filteredComponents.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <Settings className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>Ingen komponenter fundet</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Maintenance Task Dialog */}
      <Dialog open={taskDialogOpen} onOpenChange={setTaskDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Tilføj Vedligeholdelsesopgave</DialogTitle>
            <p className="text-sm text-slate-500">For: {selectedComponentForTask?.name}</p>
          </DialogHeader>
          <form onSubmit={handleTaskSubmit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="task_name">Opgave Navn *</Label>
                <Input id="task_name" name="task_name" required placeholder="Eks. Smøring af lejer" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="task_type">Type *</Label>
                <Select name="task_type" required>
                  <SelectTrigger><SelectValue placeholder="Vælg type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="inspection">Inspektion</SelectItem>
                    <SelectItem value="lubrication">Smøring</SelectItem>
                    <SelectItem value="calibration">Kalibrering</SelectItem>
                    <SelectItem value="cleaning">Rengøring</SelectItem>
                    <SelectItem value="replacement">Udskiftning</SelectItem>
                    <SelectItem value="testing">Test</SelectItem>
                    <SelectItem value="adjustment">Justering</SelectItem>
                    <SelectItem value="other">Andet</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Beskrivelse</Label>
              <Textarea id="description" name="description" rows={2} />
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="interval_value">Interval *</Label>
                <Input id="interval_value" name="interval_value" type="number" required placeholder="Eks. 6" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="interval_type">Type *</Label>
                <Select name="interval_type" required>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hours">Timer</SelectItem>
                    <SelectItem value="days">Dage</SelectItem>
                    <SelectItem value="weeks">Uger</SelectItem>
                    <SelectItem value="months">Måneder</SelectItem>
                    <SelectItem value="years">År</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="estimated_duration_hours">Varighed (timer)</Label>
                <Input id="estimated_duration_hours" name="estimated_duration_hours" type="number" step="0.5" placeholder="Eks. 2" />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="responsible_role">Ansvarlig</Label>
                <Input id="responsible_role" name="responsible_role" placeholder="Eks. Tekniker" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="priority">Prioritet</Label>
                <Select name="priority" defaultValue="medium">
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="critical">Critical</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="procedure">Procedure</Label>
              <Textarea id="procedure" name="procedure" rows={3} placeholder="Trin-for-trin instruktioner..." />
            </div>

            <div className="space-y-2">
              <Label htmlFor="safety_notes">Sikkerhedsnoter</Label>
              <Textarea id="safety_notes" name="safety_notes" rows={2} placeholder="Vigtige sikkerhedsanvisninger..." />
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setTaskDialogOpen(false)}>Annuller</Button>
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700">Opret Opgave</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}