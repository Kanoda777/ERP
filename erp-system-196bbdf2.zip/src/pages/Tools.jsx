import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Plus, 
  Wrench, 
  AlertTriangle,
  CheckCircle2,
  MapPin,
  Calendar,
  Send,
  ArrowLeftRight,
  Search,
  Filter,
  Camera,
  Upload,
  Trash2,
  Loader2,
  Eye // Added Eye icon
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useLanguage } from "@/components/LanguageContext";
import ExportButton from "@/components/ExportButton";
import ToolViewDialog from "@/components/tools/ToolViewDialog"; // Imported ToolViewDialog
import { format, addMonths, differenceInDays } from "date-fns";

export default function Tools() {
  const { t } = useLanguage();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [loanDialogOpen, setLoanDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false); // New state for view dialog
  const [editingTool, setEditingTool] = useState(null);
  const [selectedTool, setSelectedTool] = useState(null);
  const [viewingTool, setViewingTool] = useState(null); // New state for viewing tool
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSite, setFilterSite] = useState("all");
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [photos, setPhotos] = useState([]);
  const queryClient = useQueryClient();

  const { data: tools = [] } = useQuery({
    queryKey: ['tools'],
    queryFn: () => base44.entities.Tool.list('-created_date'),
  });

  const { data: loans = [] } = useQuery({
    queryKey: ['toolLoans'],
    queryFn: () => base44.entities.ToolLoan.list('-created_date'),
  });

  const createToolMutation = useMutation({
    mutationFn: (data) => base44.entities.Tool.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['tools']);
      setDialogOpen(false);
      setEditingTool(null);
      setPhotos([]);
    },
  });

  const updateToolMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Tool.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['tools']);
      setDialogOpen(false);
      setEditingTool(null);
      setPhotos([]);
      setViewDialogOpen(false); 
      setViewingTool(null);
    },
  });

  const deleteToolMutation = useMutation({
    mutationFn: (id) => base44.entities.Tool.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['tools']);
    },
  });

  const createLoanMutation = useMutation({
    mutationFn: async (data) => {
      await base44.entities.ToolLoan.create(data);
      await base44.entities.Tool.update(data.tool_id, { status: 'offshore' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['toolLoans']);
      queryClient.invalidateQueries(['tools']);
      setLoanDialogOpen(false);
      setSelectedTool(null);
    },
  });

  const handlePhotoUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setUploadingPhoto(true);
    try {
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        const photo = {
          url: file_url,
          caption: file.name,
        };
        setPhotos(prev => [...prev, photo]);
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Fejl ved upload af billede');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleRemovePhoto = (index) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    
    const data = {
      name: formData.get('name'),
      tool_id: formData.get('tool_id'),
      category: formData.get('category'),
      site: formData.get('site'),
      status: formData.get('status'),
      added_by: formData.get('added_by'),
      last_inspection_date: formData.get('last_inspection_date'),
      inspection_interval_months: parseInt(formData.get('inspection_interval_months')) || 12,
      requires_certification: formData.get('requires_certification') === 'true',
      certification_expiry: formData.get('certification_expiry'),
      serial_number: formData.get('serial_number'),
      manufacturer: formData.get('manufacturer'),
      model: formData.get('model'),
      condition: formData.get('condition'),
      notes: formData.get('notes'),
      photos: photos,
    };

    // Calculate next inspection date
    if (data.last_inspection_date) {
      data.next_inspection_date = format(
        addMonths(new Date(data.last_inspection_date), data.inspection_interval_months),
        'yyyy-MM-dd'
      );
    }

    if (editingTool) {
      updateToolMutation.mutate({ id: editingTool.id, data });
    } else {
      createToolMutation.mutate(data);
    }
  };

  const handleLoanSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    
    const data = {
      tool_id: selectedTool.id,
      tool_name: selectedTool.name,
      borrowed_by: formData.get('borrowed_by'),
      borrowed_by_email: formData.get('borrowed_by_email'),
      purpose: formData.get('purpose'),
      destination: formData.get('destination'),
      loan_start_date: formData.get('loan_start_date'),
      expected_return_date: formData.get('expected_return_date'),
      notes: formData.get('notes'),
      status: 'active',
    };

    createLoanMutation.mutate(data);
  };

  // Check for expiring certifications and inspections
  const today = new Date();
  const needsCertification = tools.filter(t => 
    t.requires_certification && 
    t.certification_expiry && 
    differenceInDays(new Date(t.certification_expiry), today) <= 30
  );

  const needsInspection = tools.filter(t => 
    t.next_inspection_date && 
    differenceInDays(new Date(t.next_inspection_date), today) <= 30
  );

  const activeLoans = loans.filter(l => l.status === 'active');

  const filteredTools = tools.filter(tool => {
    const matchesSearch = tool.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tool.tool_id?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSite = filterSite === "all" || tool.site === filterSite;
    return matchesSearch && matchesSite;
  });

  const handleDelete = (tool) => {
    const code = prompt('Indtast admin kode for at slette:');
    if (code === 'DDigital') {
      if (confirm(`Er du sikker på at du vil slette "${tool.name}"?`)) {
        deleteToolMutation.mutate(tool.id);
      }
    } else if (code !== null) {
      alert('Forkert admin kode');
    }
  };

  const toolsBySite = {
    HQ: tools.filter(t => t.site === 'HQ').length,
    Ebeltoft: tools.filter(t => t.site === 'Ebeltoft').length,
    Polen: tools.filter(t => t.site === 'Polen').length,
  };

  const exportColumns = [
    { label: t('toolName') || 'Værktøj', accessor: (item) => item.name },
    { label: t('toolId') || 'ID', accessor: (item) => item.tool_id },
    { label: t('site'), accessor: (item) => item.site },
    { label: t('status'), accessor: (item) => t(item.status) },
    { label: t('category'), accessor: (item) => t(item.category) },
    { label: t('lastInspection') || 'Sidste inspektion', accessor: (item) => item.last_inspection_date || '-' },
    { label: t('nextInspection') || 'Næste inspektion', accessor: (item) => item.next_inspection_date || '-' },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">{t('toolManagement') || 'Værktøjsstyring'}</h2>
          <p className="text-slate-500 mt-1">{t('manageTools') || 'Administrer værktøjer, inspektioner og udlån'}</p>
        </div>
        <div className="flex gap-3">
          <ExportButton 
            data={filteredTools}
            filename={`tools-${new Date().toISOString().split('T')[0]}`}
            columns={exportColumns}
          />
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => {
                setEditingTool(null);
                setPhotos([]);
              }}>
                <Plus className="w-4 h-4 mr-2" />
                {t('addTool') || 'Tilføj Værktøj'}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingTool ? t('editTool') : t('newTool') || 'Nyt Værktøj'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">{t('toolName') || 'Værktøjsnavn'} *</Label>
                    <Input id="name" name="name" defaultValue={editingTool?.name} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tool_id">{t('toolId') || 'Værktøjs ID'} *</Label>
                    <Input id="tool_id" name="tool_id" defaultValue={editingTool?.tool_id} required />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="added_by">{t('addedBy') || 'Tilføjet af'}</Label>
                  <Input id="added_by" name="added_by" defaultValue={editingTool?.added_by} placeholder={t('yourName') || 'Dit navn'} />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">{t('category')} *</Label>
                    <Select name="category" defaultValue={editingTool?.category || 'power_tools'}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="power_tools">{t('powerTools') || 'Elværktøj'}</SelectItem>
                        <SelectItem value="hand_tools">{t('handTools') || 'Håndværktøj'}</SelectItem>
                        <SelectItem value="measuring">{t('measuring') || 'Måleværktøj'}</SelectItem>
                        <SelectItem value="safety">{t('safety') || 'Sikkerhedsudstyr'}</SelectItem>
                        <SelectItem value="lifting">{t('lifting') || 'Løfteudstyr'}</SelectItem>
                        <SelectItem value="other">{t('other')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="site">{t('site')} *</Label>
                    <Select name="site" defaultValue={editingTool?.site || 'HQ'}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="HQ">🏢 HQ</SelectItem>
                        <SelectItem value="Ebeltoft">🏭 Ebeltoft</SelectItem>
                        <SelectItem value="Polen">🇵🇱 Polen</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="status">{t('status')} *</Label>
                    <Select name="status" defaultValue={editingTool?.status || 'available'}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="available">{t('available') || 'Tilgængelig'}</SelectItem>
                        <SelectItem value="in_use">{t('in_use') || 'I brug'}</SelectItem>
                        <SelectItem value="maintenance">{t('maintenance')}</SelectItem>
                        <SelectItem value="offshore">{t('offshore') || 'Offshore'}</SelectItem>
                        <SelectItem value="retired">{t('retired') || 'Udtjent'}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="serial_number">{t('serialNumber')}</Label>
                    <Input id="serial_number" name="serial_number" defaultValue={editingTool?.serial_number} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="manufacturer">{t('manufacturer') || 'Producent'}</Label>
                    <Input id="manufacturer" name="manufacturer" defaultValue={editingTool?.manufacturer} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="model">{t('model') || 'Model'}</Label>
                    <Input id="model" name="model" defaultValue={editingTool?.model} />
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h3 className="text-lg font-semibold mb-4">{t('inspectionCertification') || 'Inspektion & Certificering'}</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="last_inspection_date">{t('lastInspection') || 'Sidste inspektion'}</Label>
                      <Input 
                        id="last_inspection_date" 
                        name="last_inspection_date" 
                        type="date" 
                        defaultValue={editingTool?.last_inspection_date} 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="inspection_interval_months">{t('inspectionInterval') || 'Inspektionsinterval (måneder)'}</Label>
                      <Input 
                        id="inspection_interval_months" 
                        name="inspection_interval_months" 
                        type="number" 
                        defaultValue={editingTool?.inspection_interval_months || 12}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="requires_certification">{t('requiresCertification') || 'Kræver certificering'}</Label>
                      <Select name="requires_certification" defaultValue={editingTool?.requires_certification ? 'true' : 'false'}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="true">{t('yes') || 'Ja'}</SelectItem>
                          <SelectItem value="false">{t('no') || 'Nej'}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="certification_expiry">{t('certificationExpiry') || 'Certificering udløber'}</Label>
                      <Input 
                        id="certification_expiry" 
                        name="certification_expiry" 
                        type="date" 
                        defaultValue={editingTool?.certification_expiry}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="condition">{t('condition')}</Label>
                  <Select name="condition" defaultValue={editingTool?.condition || 'good'}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="excellent">{t('excellent')}</SelectItem>
                      <SelectItem value="good">{t('good')}</SelectItem>
                      <SelectItem value="fair">{t('fair')}</SelectItem>
                      <SelectItem value="poor">{t('poor')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">{t('notes')}</Label>
                  <Textarea id="notes" name="notes" defaultValue={editingTool?.notes} rows={3} />
                </div>

                {/* Photos Section */}
                <div className="space-y-2 p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2">
                      <Camera className="w-4 h-4" />
                      {t('toolPhotos') || 'Værktøjsfotos'}
                    </Label>
                    <label htmlFor="photo-upload" className="cursor-pointer">
                      <div className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                        {uploadingPhoto ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            {t('uploading')}...
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4" />
                            {t('uploadPhoto') || 'Upload Foto'}
                          </>
                        )}
                      </div>
                      <input
                        id="photo-upload"
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={handlePhotoUpload}
                        className="hidden"
                        disabled={uploadingPhoto}
                      />
                    </label>
                  </div>
                  
                  {photos.length > 0 ? (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
                      {photos.map((photo, index) => (
                        <div key={index} className="relative group">
                          <img 
                            src={photo.url} 
                            alt={photo.caption}
                            className="w-full h-32 object-cover rounded border border-slate-200"
                          />
                          <Button
                            type="button"
                            size="sm"
                            variant="destructive"
                            className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => handleRemovePhoto(index)}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                          <p className="text-xs text-slate-600 mt-1 truncate">{photo.caption}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-slate-500 text-center py-4">
                      {t('noPhotosYet') || 'Ingen fotos uploadet endnu'}
                    </p>
                  )}
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    {t('cancel')}
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    {editingTool ? t('saveChanges') : t('createTool') || 'Opret værktøj'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Alerts */}
      {(needsCertification.length > 0 || needsInspection.length > 0) && (
        <div className="space-y-3">
          {needsCertification.length > 0 && (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-red-900">{t('certificationExpiring') || 'Certificering udløber snart'}</h3>
                    <p className="text-sm text-red-700 mt-1">
                      {needsCertification.length} {t('toolsNeedCertification') || 'værktøjer skal certificeres inden for 30 dage'}
                    </p>
                    <div className="mt-2 space-y-1">
                      {needsCertification.map(tool => (
                        <div key={tool.id} className="text-sm text-red-800">
                          • {tool.name} ({tool.tool_id}) - {format(new Date(tool.certification_expiry), 'dd/MM/yyyy')}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {needsInspection.length > 0 && (
            <Card className="border-orange-200 bg-orange-50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 text-orange-600 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-orange-900">{t('inspectionDue') || 'Inspektion forfald'}</h3>
                    <p className="text-sm text-orange-700 mt-1">
                      {needsInspection.length} {t('toolsNeedInspection') || 'værktøjer skal inspiceres inden for 30 dage'}
                    </p>
                    <div className="mt-2 space-y-1">
                      {needsInspection.map(tool => (
                        <div key={tool.id} className="text-sm text-orange-800">
                          • {tool.name} ({tool.tool_id}) - {format(new Date(tool.next_inspection_date), 'dd/MM/yyyy')}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <Wrench className="w-4 h-4" />
              {t('totalTools') || 'Total Værktøjer'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">{tools.length}</div>
            <div className="text-xs text-slate-500 mt-1">
              🏢 HQ: {toolsBySite.HQ} • 🏭 Ebeltoft: {toolsBySite.Ebeltoft} • 🇵🇱 Polen: {toolsBySite.Polen}
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-200/60 bg-blue-50/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <Send className="w-4 h-4 text-blue-600" />
              {t('activeLoans') || 'Aktive Udlån'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{activeLoans.length}</div>
          </CardContent>
        </Card>

        <Card className="border-orange-200/60 bg-orange-50/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-orange-600" />
              {t('inspectionDue') || 'Inspektion forfald'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{needsInspection.length}</div>
          </CardContent>
        </Card>

        <Card className="border-red-200/60 bg-red-50/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              {t('certificationExpiring') || 'Certificering udløber'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{needsCertification.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Tools Table */}
      <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
        <CardHeader className="border-b border-slate-200/60">
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                placeholder={t('searchTool') || 'Søg værktøj...'}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterSite} onValueChange={setFilterSite}>
              <SelectTrigger className="w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('allSites') || 'Alle lokationer'}</SelectItem>
                <SelectItem value="HQ">🏢 HQ</SelectItem>
                <SelectItem value="Ebeltoft">🏭 Ebeltoft</SelectItem>
                <SelectItem value="Polen">🇵🇱 Polen</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead>{t('tool') || 'Værktøj'}</TableHead>
                <TableHead>{t('site')}</TableHead>
                <TableHead>{t('status')}</TableHead>
                <TableHead>{t('nextInspection') || 'Næste inspektion'}</TableHead>
                <TableHead>{t('certification') || 'Certificering'}</TableHead>
                <TableHead className="text-right">{t('actions')}</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTools.map((tool) => (
                <TableRow 
                  key={tool.id} 
                  className="hover:bg-slate-50 cursor-pointer"
                  onClick={() => {
                    setViewingTool(tool);
                    setViewDialogOpen(true);
                  }}
                >
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Wrench className="w-4 h-4 text-slate-400" />
                      <div>
                        <div className="font-medium">{tool.name}</div>
                        <div className="text-sm text-slate-500">{tool.tool_id}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="gap-1">
                      <MapPin className="w-3 h-3" />
                      {tool.site}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={
                      tool.status === 'available' ? 'bg-green-100 text-green-800' :
                      tool.status === 'offshore' ? 'bg-blue-100 text-blue-800' :
                      tool.status === 'maintenance' ? 'bg-orange-100 text-orange-800' :
                      'bg-slate-100 text-slate-800'
                    }>
                      {t(tool.status)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {tool.next_inspection_date ? (
                      <div className={differenceInDays(new Date(tool.next_inspection_date), today) <= 30 ? 'text-orange-600 font-semibold' : ''}>
                        {format(new Date(tool.next_inspection_date), 'dd/MM/yyyy')}
                      </div>
                    ) : '-'}
                  </TableCell>
                  <TableCell>
                    {tool.requires_certification ? (
                      tool.certification_expiry ? (
                        <div className={differenceInDays(new Date(tool.certification_expiry), today) <= 30 ? 'text-red-600 font-semibold' : ''}>
                          {format(new Date(tool.certification_expiry), 'dd/MM/yyyy')}
                        </div>
                      ) : <span className="text-slate-400">-</span>
                    ) : <Badge variant="outline" className="text-xs">{t('notRequired') || 'Ikke påkrævet'}</Badge>}
                  </TableCell>
                  <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                    <div className="flex justify-end gap-2">
                      {tool.status === 'available' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedTool(tool);
                            setLoanDialogOpen(true);
                          }}
                        >
                          <Send className="w-4 h-4 mr-1" />
                          {t('loan') || 'Udlån'}
                        </Button>
                      )}
                    </div>
                  </TableCell>
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      onClick={() => handleDelete(tool)} 
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredTools.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <Wrench className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>{t('noToolsFound') || 'Ingen værktøjer fundet'}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Dialog */}
      <ToolViewDialog
        tool={viewingTool}
        open={viewDialogOpen}
        onClose={() => {
          setViewDialogOpen(false);
          setViewingTool(null);
        }}
        onEdit={(tool) => {
          setViewDialogOpen(false); // Close view dialog before opening edit dialog
          setEditingTool(tool);
          setPhotos(tool.photos || []);
          setDialogOpen(true); // Open edit dialog
        }}
      />

      {/* Loan Dialog */}
      <Dialog open={loanDialogOpen} onOpenChange={setLoanDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{t('loanTool') || 'Udlån Værktøj'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleLoanSubmit} className="space-y-4">
            <div className="p-3 bg-slate-50 rounded-lg">
              <div className="font-medium">{selectedTool?.name}</div>
              <div className="text-sm text-slate-500">{selectedTool?.tool_id}</div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="borrowed_by">{t('borrowedBy') || 'Lånt af'} *</Label>
                <Input id="borrowed_by" name="borrowed_by" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="borrowed_by_email">{t('email')}</Label>
                <Input id="borrowed_by_email" name="borrowed_by_email" type="email" />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="purpose">{t('purpose') || 'Formål'} *</Label>
                <Select name="purpose" defaultValue="offshore">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="offshore">{t('offshore') || 'Offshore'}</SelectItem>
                    <SelectItem value="project">{t('project') || 'Projekt'}</SelectItem>
                    <SelectItem value="maintenance">{t('maintenance')}</SelectItem>
                    <SelectItem value="other">{t('other')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="destination">{t('destination') || 'Destination'} *</Label>
                <Input id="destination" name="destination" placeholder="Ecowende, OWF, etc." required />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="loan_start_date">{t('startDate')} *</Label>
                <Input 
                  id="loan_start_date" 
                  name="loan_start_date" 
                  type="date" 
                  defaultValue={format(new Date(), 'yyyy-MM-dd')}
                  required 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="expected_return_date">{t('expectedReturn') || 'Forventet retur'} *</Label>
                <Input 
                  id="expected_return_date" 
                  name="expected_return_date" 
                  type="date"
                  required 
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">{t('notes')}</Label>
              <Textarea id="notes" name="notes" rows={3} />
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setLoanDialogOpen(false)}>
                {t('cancel')}
              </Button>
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                <Send className="w-4 h-4 mr-2" />
                {t('confirmLoan') || 'Bekræft udlån'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}