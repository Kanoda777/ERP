import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Briefcase, Calendar, MapPin, User, Edit, Package } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { useLanguage } from "@/components/LanguageContext";
import ExportButton from "@/components/ExportButton";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Projects() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProject, setEditingProject] = useState(null);
  const queryClient = useQueryClient();

  const { data: projects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.list('-created_date'),
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['locations'],
    queryFn: () => base44.entities.Location.filter({ status: 'active' }),
  });

  const createProjectMutation = useMutation({
    mutationFn: (data) => base44.entities.Project.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['projects']);
      setDialogOpen(false);
      setEditingProject(null);
    },
  });

  const updateProjectMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Project.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['projects']);
      setDialogOpen(false);
      setEditingProject(null);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const locationId = formData.get('location_id');
    const location = locations.find(l => l.id === locationId);
    
    const data = {
      name: formData.get('name'),
      project_number: formData.get('project_number'),
      customer_name: formData.get('customer_name'),
      location_id: locationId,
      location_name: location?.name,
      start_date: formData.get('start_date'),
      end_date: formData.get('end_date'),
      status: formData.get('status'),
      project_manager: formData.get('project_manager'),
      description: formData.get('description'),
      budget: parseFloat(formData.get('budget')) || 0,
      notes: formData.get('notes'),
    };

    if (editingProject) {
      updateProjectMutation.mutate({ id: editingProject.id, data });
    } else {
      createProjectMutation.mutate(data);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      planning: "bg-slate-100 text-slate-800",
      active: "bg-green-100 text-green-800",
      maintenance: "bg-blue-100 text-blue-800",
      completed: "bg-purple-100 text-purple-800",
      on_hold: "bg-orange-100 text-orange-800",
    };
    return colors[status] || colors.planning;
  };

  const exportColumns = [
    { label: t('projectName') || 'Projektnavn', accessor: (item) => item.name },
    { label: t('projectNumber') || 'Projektnummer', accessor: (item) => item.project_number },
    { label: t('customer'), accessor: (item) => item.customer_name || '' },
    { label: t('location') || 'Lokation', accessor: (item) => item.location_name || '' },
    { label: t('projectManager') || 'Projektleder', accessor: (item) => item.project_manager || '' },
    { label: t('status'), accessor: (item) => t(item.status) },
    { label: t('startDate') || 'Start dato', accessor: (item) => item.start_date ? format(new Date(item.start_date), 'dd/MM/yyyy') : '-' },
    { label: t('endDate') || 'Slut dato', accessor: (item) => item.end_date ? format(new Date(item.end_date), 'dd/MM/yyyy') : '-' },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">{t('projects') || 'Projekter & O&M'}</h2>
          <p className="text-slate-500 mt-1">{t('manageProjects') || 'Administrer projekter og deres lager'}</p>
        </div>
        <div className="flex gap-3">
          <ExportButton 
            data={projects}
            filename={`projects-${new Date().toISOString().split('T')[0]}`}
            columns={exportColumns}
          />
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setEditingProject(null)}>
                <Plus className="w-4 h-4 mr-2" />
                {t('addProject') || 'Tilføj Projekt'}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingProject ? (t('editProject') || 'Rediger Projekt') : (t('newProject') || 'Nyt Projekt')}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">{t('projectName') || 'Projektnavn'} *</Label>
                    <Input id="name" name="name" defaultValue={editingProject?.name} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="project_number">{t('projectNumber') || 'Projektnummer'} *</Label>
                    <Input id="project_number" name="project_number" defaultValue={editingProject?.project_number} required />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="customer_name">{t('customerName')}</Label>
                    <Input id="customer_name" name="customer_name" defaultValue={editingProject?.customer_name} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="location_id">{t('location') || 'Lokation'}</Label>
                    <Select name="location_id" defaultValue={editingProject?.location_id}>
                      <SelectTrigger>
                        <SelectValue placeholder={t('selectLocation') || 'Vælg lokation'} />
                      </SelectTrigger>
                      <SelectContent>
                        {locations.map(location => (
                          <SelectItem key={location.id} value={location.id}>
                            {location.name} ({t(location.type)})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">{t('description')}</Label>
                  <Textarea id="description" name="description" defaultValue={editingProject?.description} rows={2} />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="start_date">{t('startDate') || 'Start dato'}</Label>
                    <Input id="start_date" name="start_date" type="date" defaultValue={editingProject?.start_date} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="end_date">{t('endDate') || 'Slut dato'}</Label>
                    <Input id="end_date" name="end_date" type="date" defaultValue={editingProject?.end_date} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="budget">{t('budget') || 'Budget'}</Label>
                    <Input id="budget" name="budget" type="number" step="0.01" defaultValue={editingProject?.budget} />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="project_manager">{t('projectManager') || 'Projektleder'}</Label>
                    <Input id="project_manager" name="project_manager" defaultValue={editingProject?.project_manager} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="status">{t('status')}</Label>
                    <Select name="status" defaultValue={editingProject?.status || 'planning'}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="planning">{t('planning') || 'Planlægning'}</SelectItem>
                        <SelectItem value="active">{t('active')}</SelectItem>
                        <SelectItem value="maintenance">{t('maintenance') || 'Vedligehold'}</SelectItem>
                        <SelectItem value="completed">{t('completed') || 'Afsluttet'}</SelectItem>
                        <SelectItem value="on_hold">{t('on_hold') || 'På hold'}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">{t('notes')}</Label>
                  <Textarea id="notes" name="notes" defaultValue={editingProject?.notes} rows={2} />
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    {t('cancel')}
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    {editingProject ? t('saveChanges') : (t('createProject') || 'Opret projekt')}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project) => (
          <Card key={project.id} className="hover:shadow-xl transition-all border-slate-200 cursor-pointer" onClick={() => navigate(createPageUrl(`ProjectDetails?id=${project.id}`))}>
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/30">
                    <Briefcase className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900">{project.name}</h3>
                    <p className="text-sm text-slate-500">{project.project_number}</p>
                  </div>
                </div>
                <Badge className={getStatusColor(project.status)}>
                  {t(project.status)}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {project.customer_name && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <User className="w-4 h-4 text-slate-400" />
                  <span>{project.customer_name}</span>
                </div>
              )}
              {project.location_name && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <MapPin className="w-4 h-4 text-slate-400" />
                  <span>{project.location_name}</span>
                </div>
              )}
              {project.start_date && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Calendar className="w-4 h-4 text-slate-400" />
                  <span>{format(new Date(project.start_date), 'dd/MM/yyyy')}</span>
                  {project.end_date && (
                    <span>- {format(new Date(project.end_date), 'dd/MM/yyyy')}</span>
                  )}
                </div>
              )}
              {project.project_manager && (
                <div className="pt-2 border-t">
                  <p className="text-xs text-slate-500">{t('projectManager') || 'Projektleder'}:</p>
                  <p className="text-sm font-medium text-slate-700">{project.project_manager}</p>
                </div>
              )}
              <div className="flex gap-2 pt-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={(e) => {
                    e.stopPropagation();
                    setEditingProject(project);
                    setDialogOpen(true);
                  }}
                >
                  <Edit className="w-4 h-4 mr-2" />
                  {t('edit')}
                </Button>
                <Button
                  size="sm"
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(createPageUrl(`ProjectDetails?id=${project.id}`));
                  }}
                >
                  <Package className="w-4 h-4 mr-2" />
                  {t('inventory') || 'Lager'}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {projects.length === 0 && (
        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardContent className="text-center py-12 text-slate-500">
            <Briefcase className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p>{t('noProjects') || 'Ingen projekter endnu'}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}