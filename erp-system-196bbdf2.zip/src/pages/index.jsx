import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Inventory from "./Inventory";

import Suppliers from "./Suppliers";

import Purchases from "./Purchases";

import Sales from "./Sales";

import Production from "./Production";

import Settings from "./Settings";

import Projects from "./Projects";

import ProjectDetails from "./ProjectDetails";

import Locations from "./Locations";

import SparePartsCentral from "./SparePartsCentral";

import AutoReorder from "./AutoReorder";

import QualityInspections from "./QualityInspections";

import Tools from "./Tools";

import TestEquipment from "./TestEquipment";

import MasterTracker from "./MasterTracker";

import LocationCalendar from "./LocationCalendar";

import Components from "./Components";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Inventory: Inventory,
    
    Suppliers: Suppliers,
    
    Purchases: Purchases,
    
    Sales: Sales,
    
    Production: Production,
    
    Settings: Settings,
    
    Projects: Projects,
    
    ProjectDetails: ProjectDetails,
    
    Locations: Locations,
    
    SparePartsCentral: SparePartsCentral,
    
    AutoReorder: AutoReorder,
    
    QualityInspections: QualityInspections,
    
    Tools: Tools,
    
    TestEquipment: TestEquipment,
    
    MasterTracker: MasterTracker,
    
    LocationCalendar: LocationCalendar,
    
    Components: Components,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Inventory" element={<Inventory />} />
                
                <Route path="/Suppliers" element={<Suppliers />} />
                
                <Route path="/Purchases" element={<Purchases />} />
                
                <Route path="/Sales" element={<Sales />} />
                
                <Route path="/Production" element={<Production />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Projects" element={<Projects />} />
                
                <Route path="/ProjectDetails" element={<ProjectDetails />} />
                
                <Route path="/Locations" element={<Locations />} />
                
                <Route path="/SparePartsCentral" element={<SparePartsCentral />} />
                
                <Route path="/AutoReorder" element={<AutoReorder />} />
                
                <Route path="/QualityInspections" element={<QualityInspections />} />
                
                <Route path="/Tools" element={<Tools />} />
                
                <Route path="/TestEquipment" element={<TestEquipment />} />
                
                <Route path="/MasterTracker" element={<MasterTracker />} />
                
                <Route path="/LocationCalendar" element={<LocationCalendar />} />
                
                <Route path="/Components" element={<Components />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}