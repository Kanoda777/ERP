import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Search, Truck, Mail, Phone, MapPin, Edit } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useLanguage } from "@/components/LanguageContext";
import ExportButton from "@/components/ExportButton";

export default function Suppliers() {
  const { t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState(null);
  const queryClient = useQueryClient();

  const { data: suppliers = [], isLoading } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => base44.entities.Supplier.list('-created_date'),
  });

  const createSupplierMutation = useMutation({
    mutationFn: (data) => base44.entities.Supplier.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['suppliers']);
      setDialogOpen(false);
      setEditingSupplier(null);
    },
  });

  const updateSupplierMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Supplier.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['suppliers']);
      setDialogOpen(false);
      setEditingSupplier(null);
    },
  });

  const filteredSuppliers = suppliers.filter(supplier =>
    supplier.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    supplier.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = {
      name: formData.get('name'),
      contact_person: formData.get('contact_person'),
      email: formData.get('email'),
      phone: formData.get('phone'),
      address: formData.get('address'),
      cvr: formData.get('cvr'),
      payment_terms: formData.get('payment_terms'),
      notes: formData.get('notes'),
      status: formData.get('status'),
    };

    if (editingSupplier) {
      updateSupplierMutation.mutate({ id: editingSupplier.id, data });
    } else {
      createSupplierMutation.mutate(data);
    }
  };

  const exportColumns = [
    { label: t('supplierName'), accessor: (item) => item.name },
    { label: t('contactPerson'), accessor: (item) => item.contact_person || '' },
    { label: t('email'), accessor: (item) => item.email },
    { label: t('phone'), accessor: (item) => item.phone },
    { label: t('address'), accessor: (item) => item.address || '' },
    { label: t('cvrNumber'), accessor: (item) => item.cvr || '' },
    { label: t('paymentTerms'), accessor: (item) => item.payment_terms || '' },
    { label: t('status'), accessor: (item) => t(item.status) },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">{t('suppliersManagement')}</h2>
          <p className="text-slate-500 mt-1">{t('manageSuppliers')}</p>
        </div>
        <div className="flex gap-3">
          <ExportButton 
            data={filteredSuppliers}
            filename={`suppliers-${new Date().toISOString().split('T')[0]}`}
            columns={exportColumns}
          />
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setEditingSupplier(null)}>
                <Plus className="w-4 h-4 mr-2" />
                {t('addSupplier')}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingSupplier ? t('editSupplier') : t('newSupplier')}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">{t('supplierName')} *</Label>
                    <Input id="name" name="name" defaultValue={editingSupplier?.name} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contact_person">{t('contactPerson')}</Label>
                    <Input id="contact_person" name="contact_person" defaultValue={editingSupplier?.contact_person} />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">{t('email')} *</Label>
                    <Input id="email" name="email" type="email" defaultValue={editingSupplier?.email} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">{t('phone')} *</Label>
                    <Input id="phone" name="phone" defaultValue={editingSupplier?.phone} required />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">{t('address')}</Label>
                  <Input id="address" name="address" defaultValue={editingSupplier?.address} />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="cvr">{t('cvrNumber')}</Label>
                    <Input id="cvr" name="cvr" defaultValue={editingSupplier?.cvr} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="payment_terms">{t('paymentTerms')}</Label>
                    <Input id="payment_terms" name="payment_terms" placeholder="f.eks. Netto 30 dage" defaultValue={editingSupplier?.payment_terms} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="status">{t('status')}</Label>
                  <Select name="status" defaultValue={editingSupplier?.status || 'active'}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">{t('active')}</SelectItem>
                      <SelectItem value="inactive">{t('inactive')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">{t('notes')}</Label>
                  <Textarea id="notes" name="notes" defaultValue={editingSupplier?.notes} rows={3} />
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    {t('cancel')}
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    {editingSupplier ? t('saveChanges') : t('createSupplier')}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
        <CardHeader className="border-b border-slate-200/60">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
            <Input
              placeholder={t('searchSupplier')}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSuppliers.map((supplier) => (
              <Card key={supplier.id} className="hover:shadow-lg transition-all border-slate-200">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/30">
                        <Truck className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-900">{supplier.name}</h3>
                        {supplier.contact_person && (
                          <p className="text-sm text-slate-500">{supplier.contact_person}</p>
                        )}
                      </div>
                    </div>
                    <Badge variant={supplier.status === 'active' ? 'default' : 'secondary'}>
                      {t(supplier.status)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <span className="truncate">{supplier.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Phone className="w-4 h-4 text-slate-400" />
                    <span>{supplier.phone}</span>
                  </div>
                  {supplier.address && (
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <MapPin className="w-4 h-4 text-slate-400" />
                      <span className="truncate">{supplier.address}</span>
                    </div>
                  )}
                  {supplier.payment_terms && (
                    <div className="pt-2 border-t">
                      <p className="text-xs text-slate-500">{t('paymentTerms')}:</p>
                      <p className="text-sm font-medium text-slate-700">{supplier.payment_terms}</p>
                    </div>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full mt-4"
                    onClick={() => {
                      setEditingSupplier(supplier);
                      setDialogOpen(true);
                    }}
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    {t('edit')}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
          {filteredSuppliers.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <Truck className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>{t('noSuppliersFound')}</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}