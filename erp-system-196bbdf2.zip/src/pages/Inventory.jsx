import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Plus, 
  Search, 
  AlertTriangle, 
  Package,
  Edit,
  TrendingDown,
  Filter,
  Lightbulb,
  FileText,
  Upload,
  Download,
  Trash2,
  Loader2,
  Eye,
  Settings
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { useLanguage } from "@/components/LanguageContext";
import ExportButton from "@/components/ExportButton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import ProductViewDialog from "@/components/inventory/ProductViewDialog";
import SkuBuilder from "@/components/inventory/SkuBuilder";
import { format } from "date-fns";

// Intelligent strategi-anbefaling baseret på komponent type
const getRecommendedStrategy = (componentType, name = '', description = '') => {
  const nameLower = (name + ' ' + description).toLowerCase();
  
  if (componentType === 'mechanical_standard' || 
      nameLower.match(/bolt|møtrik|skrue|washer|nut|screw/i)) {
    return {
      criticality: 'low',
      stock_strategy: 'order_when_needed',
      failure_impact: 'minimal',
      reasoning: 'Standard mekaniske dele er nemme at skaffe og ikke kritiske'
    };
  }
  
  if (componentType === 'network_equipment' || 
      nameLower.match(/switch|router|gateway|network|netværk/i)) {
    return {
      criticality: 'critical',
      stock_strategy: 'always_stock',
      failure_impact: 'total_shutdown',
      reasoning: 'Netværksudstyr er kritisk - nedbrud fører til total stopning'
    };
  }
  
  if (componentType === 'control_systems' || 
      nameLower.match(/plc|controller|control|styring/i)) {
    return {
      criticality: 'critical',
      stock_strategy: 'always_stock',
      failure_impact: 'total_shutdown',
      reasoning: 'Kontrolsystemer er kritiske for drift'
    };
  }
  
  if (componentType === 'sensors' || 
      nameLower.match(/sensor|probe|måler|detector/i)) {
    return {
      criticality: 'high',
      stock_strategy: 'stock_on_demand',
      failure_impact: 'degraded_performance',
      reasoning: 'Sensorer er vigtige men kan ofte overvåges inden fejl'
    };
  }
  
  if (componentType === 'electrical_critical' || 
      nameLower.match(/power supply|transformer|inverter|motor|pump/i)) {
    return {
      criticality: 'high',
      stock_strategy: 'always_stock',
      failure_impact: 'partial_shutdown',
      reasoning: 'Elektriske komponenter kan føre til betydelig nedetid'
    };
  }
  
  if (componentType === 'hydraulic' || componentType === 'pneumatic' ||
      nameLower.match(/hydraulic|pneumatic|cylinder|valve|ventil/i)) {
    return {
      criticality: 'medium',
      stock_strategy: 'stock_on_demand',
      failure_impact: 'degraded_performance',
      reasoning: 'Hydrauliske/pneumatiske dele kan ofte erstattes midlertidigt'
    };
  }
  
  if (componentType === 'consumables' || 
      nameLower.match(/filter|oil|grease|lubric/i)) {
    return {
      criticality: 'low',
      stock_strategy: 'stock_on_demand',
      failure_impact: 'minimal',
      reasoning: 'Forbrugsvarer kan planlægges og bestilles i god tid'
    };
  }
  
  return {
    criticality: 'medium',
    stock_strategy: 'stock_on_demand',
    failure_impact: 'degraded_performance',
    reasoning: 'Standard anbefaling - juster baseret på din erfaring'
  };
};

export default function Inventory() {
  const { t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [showLowStock, setShowLowStock] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [viewingProduct, setViewingProduct] = useState(null);
  const [selectedComponentType, setSelectedComponentType] = useState("");
  const [generatedSku, setGeneratedSku] = useState("");
  const [aiRecommendation, setAiRecommendation] = useState(null);
  const [uploadingManual, setUploadingManual] = useState(false);
  const [manualFiles, setManualFiles] = useState([]);
  const [skuMode, setSkuMode] = useState("advanced"); // "advanced" or "simple"
  const [formCategory, setFormCategory] = useState("");
  const [formUnit, setFormUnit] = useState("");
  const [formCriticality, setFormCriticality] = useState("");
  const [formStockStrategy, setFormStockStrategy] = useState("");
  const [formFailureImpact, setFormFailureImpact] = useState("");
  const [formSupplierId, setFormSupplierId] = useState("");
  const queryClient = useQueryClient();

  const { data: products = [], isLoading } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list('-created_date'),
  });

  const { data: suppliers = [] } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => base44.entities.Supplier.filter({ status: 'active' }),
  });

  const createProductMutation = useMutation({
    mutationFn: (data) => base44.entities.Product.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['products']);
      setDialogOpen(false);
      setEditingProduct(null);
      setAiRecommendation(null);
      setManualFiles([]);
      setGeneratedSku("");
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Product.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['products']);
      setDialogOpen(false);
      setEditingProduct(null);
      setAiRecommendation(null);
      setManualFiles([]);
      setGeneratedSku("");
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: (id) => base44.entities.Product.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['products']);
    },
  });

  useEffect(() => {
    if (selectedComponentType && !editingProduct) {
      const formName = document.getElementById('name')?.value || '';
      const formDesc = document.getElementById('description')?.value || '';
      const recommendation = getRecommendedStrategy(selectedComponentType, formName, formDesc);
      setAiRecommendation(recommendation);
    }
  }, [selectedComponentType, editingProduct]);

  useEffect(() => {
    if (editingProduct) {
      setManualFiles(editingProduct.manuals || []);
      setSelectedComponentType(editingProduct.component_type || "");
      setFormCategory(editingProduct.category || "spare_parts");
      setFormUnit(editingProduct.unit || "stk");
      setFormCriticality(editingProduct.criticality || "");
      setFormStockStrategy(editingProduct.stock_strategy || "");
      setFormFailureImpact(editingProduct.failure_impact || "");
      setFormSupplierId(editingProduct.supplier_id || "");
      if (editingProduct.component_type) {
        const recommendation = getRecommendedStrategy(editingProduct.component_type, editingProduct.name, editingProduct.description);
        setAiRecommendation(recommendation);
      }
    } else {
      setManualFiles([]);
      setSelectedComponentType("");
      setFormCategory("spare_parts");
      setFormUnit("stk");
      setFormCriticality("");
      setFormStockStrategy("");
      setFormFailureImpact("");
      setFormSupplierId("");
      setAiRecommendation(null);
    }
  }, [editingProduct]);

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setUploadingManual(true);
    try {
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        const manual = {
          name: file.name,
          file_url,
          file_type: file.name.split('.').pop(),
          uploaded_date: format(new Date(), 'yyyy-MM-dd'),
        };
        setManualFiles(prev => [...prev, manual]);
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Fejl ved upload af fil');
    } finally {
      setUploadingManual(false);
    }
  };

  const handleRemoveManual = (index) => {
    setManualFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleDelete = (product) => {
    const code = prompt('Indtast admin kode for at slette:');
    if (code === 'DDigital') {
      if (confirm(`Er du sikker på at du vil slette "${product.name}"?`)) {
        deleteProductMutation.mutate(product.id);
      }
    } else if (code !== null) {
      alert('Forkert admin kode');
    }
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.sku?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === "all" || product.category === filterCategory;
    const matchesLowStock = !showLowStock || product.current_stock <= product.min_stock_level;
    return matchesSearch && matchesCategory && matchesLowStock;
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = {
      name: formData.get('name'),
      sku: generatedSku || formData.get('sku') || editingProduct?.sku,
      description: formData.get('description'),
      category: formCategory,
      component_type: selectedComponentType,
      unit_price: parseFloat(formData.get('unit_price')),
      current_stock: parseFloat(formData.get('current_stock')),
      min_stock_level: parseFloat(formData.get('min_stock_level')),
      reorder_quantity: parseFloat(formData.get('reorder_quantity')),
      supplier_id: formSupplierId || null,
      unit: formUnit,
      criticality: formCriticality || null,
      stock_strategy: formStockStrategy || null,
      failure_impact: formFailureImpact || null,
      lead_time_days: parseInt(formData.get('lead_time_days')) || 0,
      manuals: manualFiles,
    };

    if (editingProduct) {
      updateProductMutation.mutate({ id: editingProduct.id, data });
    } else {
      createProductMutation.mutate(data);
    }
  };

  const exportColumns = [
    { label: t('productName'), accessor: (item) => item.name },
    { label: 'SKU', accessor: (item) => item.sku },
    { label: t('category'), accessor: (item) => t(item.category) },
    { label: t('componentType') || 'Type', accessor: (item) => item.component_type || '-' },
    { label: t('criticality') || 'Kritikalitet', accessor: (item) => item.criticality || '-' },
    { label: t('currentStock'), accessor: (item) => `${item.current_stock} ${item.unit}` },
    { label: t('minLevel'), accessor: (item) => `${item.min_stock_level} ${item.unit}` },
    { label: t('unitPrice'), accessor: (item) => `${item.unit_price} ${t('kr')}` },
    { label: t('value'), accessor: (item) => `${(item.current_stock * item.unit_price).toFixed(2)} ${t('kr')}` },
    { label: t('manuals') || 'Manualer', accessor: (item) => item.manuals?.length || 0 },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">{t('inventoryManagement')}</h2>
          <p className="text-slate-500 mt-1">{t('manageProducts')}</p>
        </div>
        <div className="flex gap-3">
          <ExportButton 
            data={filteredProducts}
            filename={`inventory-${new Date().toISOString().split('T')[0]}`}
            columns={exportColumns}
          />
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => {
                setEditingProduct(null);
                setAiRecommendation(null);
                setSelectedComponentType("");
                setManualFiles([]);
                setGeneratedSku("");
              }}>
                <Plus className="w-4 h-4 mr-2" />
                {t('addProduct')}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingProduct ? t('editProduct') : t('newProduct')}</DialogTitle>
              </DialogHeader>
              <form key={editingProduct?.id || 'new'} onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">{t('productName')} *</Label>
                    <Input id="name" name="name" defaultValue={editingProduct?.name} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">{t('description')}</Label>
                    <Input id="description" name="description" defaultValue={editingProduct?.description} />
                  </div>
                </div>

                {/* SKU Builder */}
                {!editingProduct && (
                  <Tabs value={skuMode} onValueChange={setSkuMode} className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="advanced">
                        <Settings className="w-4 h-4 mr-2" />
                        Avanceret SKU
                      </TabsTrigger>
                      <TabsTrigger value="simple">Manuel SKU</TabsTrigger>
                    </TabsList>
                    <TabsContent value="advanced">
                      <SkuBuilder 
                        value={generatedSku} 
                        onChange={setGeneratedSku}
                        existingProducts={products}
                      />
                    </TabsContent>
                    <TabsContent value="simple">
                      <div className="space-y-2 p-4 bg-slate-50 rounded-lg border border-slate-200">
                        <Label htmlFor="sku_simple">SKU *</Label>
                        <Input 
                          id="sku_simple" 
                          name="sku" 
                          placeholder="Indtast SKU manuelt..."
                          onChange={(e) => setGeneratedSku(e.target.value)}
                        />
                      </div>
                    </TabsContent>
                  </Tabs>
                )}

                {editingProduct && (
                  <div className="space-y-2">
                    <Label>SKU (kan ikke ændres)</Label>
                    <Input value={editingProduct.sku} disabled className="bg-slate-100" />
                  </div>
                )}

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">{t('category')} *</Label>
                    <Select value={formCategory} onValueChange={setFormCategory}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="spare_parts">{t('spare_parts')}</SelectItem>
                        <SelectItem value="components">{t('components')}</SelectItem>
                        <SelectItem value="tools">{t('tools')}</SelectItem>
                        <SelectItem value="raw_materials">{t('raw_materials')}</SelectItem>
                        <SelectItem value="finished_goods">{t('finished_goods')}</SelectItem>
                        <SelectItem value="packaging">{t('packaging')}</SelectItem>
                        <SelectItem value="assembly">{t('assembly')}</SelectItem>
                        <SelectItem value="other">{t('other')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="component_type">{t('componentType') || 'Komponent Type'}</Label>
                    <Select 
                      value={selectedComponentType}
                      onValueChange={setSelectedComponentType}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={t('selectType') || 'Vælg type'} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mechanical_standard">Mekanisk Standard</SelectItem>
                        <SelectItem value="mechanical_custom">Mekanisk Special</SelectItem>
                        <SelectItem value="network_equipment">Netværksudstyr</SelectItem>
                        <SelectItem value="control_systems">Kontrolsystemer</SelectItem>
                        <SelectItem value="sensors">Sensorer</SelectItem>
                        <SelectItem value="electrical_critical">Elektrisk Kritisk</SelectItem>
                        <SelectItem value="electrical_standard">Elektrisk Standard</SelectItem>
                        <SelectItem value="hydraulic">Hydraulisk</SelectItem>
                        <SelectItem value="pneumatic">Pneumatisk</SelectItem>
                        <SelectItem value="consumables">Forbrugsvarer</SelectItem>
                        <SelectItem value="other">{t('other')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {aiRecommendation && (
                  <Alert className="bg-blue-50 border-blue-200">
                    <Lightbulb className="w-4 h-4 text-blue-600" />
                    <AlertDescription className="text-blue-800">
                      <strong>💡 AI Anbefaling:</strong> {aiRecommendation.reasoning}
                      <div className="mt-2 flex gap-2 flex-wrap">
                        <Badge className="bg-blue-100 text-blue-800">
                          Kritikalitet: {aiRecommendation.criticality}
                        </Badge>
                        <Badge className="bg-blue-100 text-blue-800">
                          Strategi: {aiRecommendation.stock_strategy.replace(/_/g, ' ')}
                        </Badge>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}

                {/* Manuals Section */}
                <div className="space-y-2 p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      {t('manuals') || 'Manualer'}
                    </Label>
                    <label htmlFor="manual-upload" className="cursor-pointer">
                      <div className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                        {uploadingManual ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            Uploader...
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4" />
                            Upload
                          </>
                        )}
                      </div>
                      <input
                        id="manual-upload"
                        type="file"
                        multiple
                        accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg"
                        onChange={handleFileUpload}
                        className="hidden"
                        disabled={uploadingManual}
                      />
                    </label>
                  </div>
                  
                  {manualFiles.length > 0 ? (
                    <div className="space-y-2 mt-3">
                      {manualFiles.map((manual, index) => (
                        <div key={index} className="flex items-center justify-between p-2 bg-white rounded border">
                          <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4 text-blue-600" />
                            <div className="text-sm font-medium">{manual.name}</div>
                          </div>
                          <div className="flex gap-2">
                            <a href={manual.file_url} target="_blank" rel="noopener noreferrer">
                              <Button type="button" size="sm" variant="ghost">
                                <Download className="w-4 h-4" />
                              </Button>
                            </a>
                            <Button type="button" size="sm" variant="ghost" onClick={() => handleRemoveManual(index)}>
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-slate-500 text-center py-4">Ingen manualer uploadet</p>
                  )}
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="criticality">Kritikalitet</Label>
                    <Select value={formCriticality} onValueChange={setFormCriticality}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="critical">Critical</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="stock_strategy">Lagerstrategi</Label>
                    <Select value={formStockStrategy} onValueChange={setFormStockStrategy}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="always_stock">Altid på lager</SelectItem>
                        <SelectItem value="stock_on_demand">Ved behov</SelectItem>
                        <SelectItem value="order_when_needed">Bestil ved behov</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="failure_impact">Nedbrud Konsekvens</Label>
                    <Select value={formFailureImpact} onValueChange={setFormFailureImpact}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="total_shutdown">Total stopning</SelectItem>
                        <SelectItem value="partial_shutdown">Delvis stopning</SelectItem>
                        <SelectItem value="degraded_performance">Nedsat ydelse</SelectItem>
                        <SelectItem value="minimal">Minimal</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="unit">Enhed *</Label>
                    <Select value={formUnit} onValueChange={setFormUnit}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="stk">Stk</SelectItem>
                        <SelectItem value="kg">Kg</SelectItem>
                        <SelectItem value="liter">Liter</SelectItem>
                        <SelectItem value="meter">Meter</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unit_price">Pris (DKK) *</Label>
                    <Input id="unit_price" name="unit_price" type="number" step="0.01" defaultValue={editingProduct?.unit_price} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="current_stock">Lager *</Label>
                    <Input 
                      id="current_stock" 
                      name="current_stock" 
                      type="number" 
                      defaultValue={editingProduct?.current_stock || 0}
                      required 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lead_time_days">Leveringstid (dage)</Label>
                    <Input id="lead_time_days" name="lead_time_days" type="number" defaultValue={editingProduct?.lead_time_days || 0} />
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="min_stock_level">Min. niveau *</Label>
                    <Input id="min_stock_level" name="min_stock_level" type="number" defaultValue={editingProduct?.min_stock_level || 10} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reorder_quantity">Genbestil antal</Label>
                    <Input id="reorder_quantity" name="reorder_quantity" type="number" defaultValue={editingProduct?.reorder_quantity || 50} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="supplier_id">Leverandør</Label>
                    <Select value={formSupplierId} onValueChange={setFormSupplierId}>
                      <SelectTrigger><SelectValue placeholder="Vælg" /></SelectTrigger>
                      <SelectContent>
                        {suppliers.map(s => (
                          <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    Annuller
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    {editingProduct ? 'Gem' : 'Opret'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
        <CardHeader className="border-b border-slate-200/60">
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                placeholder="Søg produkt eller SKU..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-3">
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-48">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle kategorier</SelectItem>
                  <SelectItem value="spare_parts">Reservedele</SelectItem>
                  <SelectItem value="components">Komponenter</SelectItem>
                  <SelectItem value="tools">Værktøj</SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant={showLowStock ? "default" : "outline"}
                onClick={() => setShowLowStock(!showLowStock)}
                className={showLowStock ? "bg-orange-600 hover:bg-orange-700" : ""}
              >
                <AlertTriangle className="w-4 h-4 mr-2" />
                Lav lager
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead>Produkt</TableHead>
                <TableHead>SKU</TableHead>
                <TableHead>Kategori</TableHead>
                <TableHead>Kritikalitet</TableHead>
                <TableHead className="text-center">Manualer</TableHead>
                <TableHead className="text-right">Lager</TableHead>
                <TableHead className="text-right">Værdi</TableHead>
                <TableHead className="text-right">Status</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProducts.map((product) => {
                const isLowStock = product.current_stock <= product.min_stock_level;
                const stockValue = product.current_stock * product.unit_price;
                const manualCount = product.manuals?.length || 0;
                
                return (
                  <TableRow 
                    key={product.id} 
                    className="hover:bg-slate-50 cursor-pointer"
                    onClick={() => {
                      setViewingProduct(product);
                      setViewDialogOpen(true);
                    }}
                  >
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          product.criticality === 'critical' ? 'bg-red-100' : 'bg-blue-100'
                        }`}>
                          <Package className={`w-5 h-5 ${
                            product.criticality === 'critical' ? 'text-red-600' : 'text-blue-600'
                          }`} />
                        </div>
                        <div className="font-medium">{product.name}</div>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-sm">{product.sku}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{t(product.category)}</Badge>
                    </TableCell>
                    <TableCell>
                      {product.criticality ? (
                        <Badge className={
                          product.criticality === 'critical' ? 'bg-red-100 text-red-800' :
                          product.criticality === 'high' ? 'bg-orange-100 text-orange-800' :
                          'bg-yellow-100 text-yellow-800'
                        }>
                          {product.criticality}
                        </Badge>
                      ) : '-'}
                    </TableCell>
                    <TableCell className="text-center">
                      {manualCount > 0 ? (
                        <Badge className="bg-blue-100 text-blue-800">
                          <FileText className="w-3 h-3 mr-1" />
                          {manualCount}
                        </Badge>
                      ) : '-'}
                    </TableCell>
                    <TableCell className="text-right">
                      <span className={isLowStock ? "text-orange-600 font-semibold" : ""}>
                        {product.current_stock} {product.unit}
                      </span>
                    </TableCell>
                    <TableCell className="text-right font-semibold">
                      {stockValue.toLocaleString('da-DK')} kr
                    </TableCell>
                    <TableCell className="text-right">
                      {isLowStock ? (
                        <Badge variant="destructive">
                          <TrendingDown className="w-3 h-3 mr-1" />
                          Lav
                        </Badge>
                      ) : (
                        <Badge className="bg-green-100 text-green-800">OK</Badge>
                      )}
                    </TableCell>
                    <TableCell onClick={(e) => e.stopPropagation()}>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => handleDelete(product)} 
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          {filteredProducts.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <Package className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>Ingen produkter fundet</p>
            </div>
          )}
        </CardContent>
      </Card>

      <ProductViewDialog
        product={viewingProduct}
        supplier={suppliers.find(s => s.id === viewingProduct?.supplier_id)}
        open={viewDialogOpen}
        onClose={() => {
          setViewDialogOpen(false);
          setViewingProduct(null);
        }}
        onEdit={(product) => {
          setViewDialogOpen(false);
          setTimeout(() => {
            setEditingProduct(product);
            setDialogOpen(true);
          }, 50);
        }}
      />
    </div>
  );
}