import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Package, AlertTriangle, ShoppingCart, Mail, CheckCircle2, Clock, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useLanguage } from "@/components/LanguageContext";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { format } from "date-fns";

export default function AutoReorder() {
  const { t } = useLanguage();
  const [sendingEmail, setSendingEmail] = useState(null);
  const queryClient = useQueryClient();

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
  });

  const { data: suppliers = [] } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => base44.entities.Supplier.list(),
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const createPurchaseOrderMutation = useMutation({
    mutationFn: (data) => base44.entities.PurchaseOrder.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['purchaseOrders']);
    },
  });

  const sendEmailMutation = useMutation({
    mutationFn: ({ to, subject, body }) => 
      base44.integrations.Core.SendEmail({
        to,
        subject,
        body,
      }),
  });

  // Find produkter der skal genbestilles
  const reorderSuggestions = products
    .filter(p => {
      // Produkter med lav lagerbeholdning
      const isLowStock = p.current_stock <= p.min_stock_level;
      
      // Kun produkter der skal have lager (ikke "order_when_needed" medmindre critical)
      const needsStock = p.stock_strategy !== 'order_when_needed' || p.criticality === 'critical';
      
      // Har leverandør
      const hasSupplier = p.supplier_id;
      
      return isLowStock && needsStock && hasSupplier;
    })
    .map(p => {
      const supplier = suppliers.find(s => s.id === p.supplier_id);
      const shortfall = p.min_stock_level - p.current_stock;
      const orderQuantity = Math.max(p.reorder_quantity || 50, shortfall);
      const orderValue = orderQuantity * p.unit_price;
      
      return {
        ...p,
        supplier,
        shortfall,
        orderQuantity,
        orderValue,
        urgency: p.criticality === 'critical' ? 'critical' : 
                 p.criticality === 'high' ? 'high' : 'medium',
      };
    })
    .sort((a, b) => {
      // Sorter efter kritikalitet først
      const urgencyOrder = { critical: 0, high: 1, medium: 2, low: 3 };
      return urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
    });

  const handleCreateOrder = async (product) => {
    const supplier = product.supplier;
    if (!supplier) return;

    const orderData = {
      order_number: `PO-AUTO-${Date.now()}`,
      supplier_id: supplier.id,
      supplier_name: supplier.name,
      order_date: format(new Date(), 'yyyy-MM-dd'),
      expected_delivery: product.lead_time_days 
        ? format(new Date(Date.now() + product.lead_time_days * 24 * 60 * 60 * 1000), 'yyyy-MM-dd')
        : format(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd'),
      status: 'draft',
      items: [{
        product_id: product.id,
        product_name: product.name,
        quantity: product.orderQuantity,
        unit_price: product.unit_price,
        total: product.orderValue,
      }],
      total_amount: product.orderValue,
      notes: `Automatisk genbestilling - Lager nået minimum niveau. Kritikalitet: ${product.criticality || 'medium'}`,
    };

    await createPurchaseOrderMutation.mutateAsync(orderData);
  };

  const handleSendEmail = async (product) => {
    setSendingEmail(product.id);
    try {
      const supplier = product.supplier;
      const emailBody = `
Hej,

Dette er en automatisk notifikation om lav lagerbeholdning.

PRODUKT: ${product.name}
SKU: ${product.sku}
KRITIKALITET: ${product.criticality || 'medium'}
LEVERANDØR: ${supplier?.name || 'Ikke angivet'}

LAGERSTATUS:
- Nuværende lager: ${product.current_stock} ${product.unit}
- Minimum niveau: ${product.min_stock_level} ${product.unit}
- Mangel: ${product.shortfall} ${product.unit}

ANBEFALET HANDLING:
- Bestil: ${product.orderQuantity} ${product.unit}
- Estimeret værdi: ${product.orderValue.toLocaleString('da-DK')} kr
- Forventet leveringstid: ${product.lead_time_days || 7} dage

${product.criticality === 'critical' ? '⚠️ KRITISK KOMPONENT - Haster!' : ''}

Log ind på ERP systemet for at oprette indkøbsordre.

Venlig hilsen,
ERP System
      `;

      await sendEmailMutation.mutateAsync({
        to: user?.email || 'admin@example.com',
        subject: `🔔 Genbestilling påkrævet: ${product.name} (${product.criticality || 'medium'})`,
        body: emailBody,
      });

      alert('Email sendt!');
    } catch (error) {
      console.error('Email error:', error);
      alert('Fejl ved afsendelse af email');
    } finally {
      setSendingEmail(null);
    }
  };

  const handleApproveAndOrder = async (product) => {
    await handleCreateOrder(product);
    await handleSendEmail(product);
  };

  const totalReorderValue = reorderSuggestions.reduce((sum, p) => sum + p.orderValue, 0);
  const criticalCount = reorderSuggestions.filter(p => p.urgency === 'critical').length;

  const getUrgencyColor = (urgency) => {
    const colors = {
      critical: 'bg-red-100 text-red-800 border-red-200',
      high: 'bg-orange-100 text-orange-800 border-orange-200',
      medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    };
    return colors[urgency] || colors.medium;
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div>
        <h2 className="text-3xl font-bold text-slate-900">{t('autoReorder') || 'Automatisk Genbestilling'}</h2>
        <p className="text-slate-500 mt-1">{t('autoReorderDesc') || 'Produkter der skal genbestilles baseret på lagerniveau'}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <ShoppingCart className="w-4 h-4" />
              {t('pendingReorders') || 'Afventende Genbestillinger'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-900">{reorderSuggestions.length}</div>
            <p className="text-sm text-slate-500 mt-1">{t('productsNeedReorder') || 'produkter skal genbestilles'}</p>
          </CardContent>
        </Card>

        <Card className="border-red-200/60 bg-red-50/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              {t('criticalItems') || 'Kritiske Varer'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600">{criticalCount}</div>
            <p className="text-sm text-slate-500 mt-1">{t('requiresImmediateAction') || 'kræver øjeblikkelig handling'}</p>
          </CardContent>
        </Card>

        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <Package className="w-4 h-4" />
              {t('totalOrderValue') || 'Total Ordreværdi'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-900">
              {totalReorderValue.toLocaleString('da-DK')} {t('kr')}
            </div>
            <p className="text-sm text-slate-500 mt-1">{t('estimatedCost') || 'estimeret omkostning'}</p>
          </CardContent>
        </Card>
      </div>

      {criticalCount > 0 && (
        <Alert className="bg-red-50 border-red-200">
          <AlertTriangle className="w-4 h-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <strong>⚠️ {t('criticalAlert') || 'Kritisk Advarsel'}:</strong> {criticalCount} {t('criticalPartsLowStock') || 'kritiske komponenter har lav lagerbeholdning. Disse kan føre til total nedbrud ved fejl!'}
          </AlertDescription>
        </Alert>
      )}

      <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
        <CardHeader className="border-b border-slate-200/60">
          <CardTitle>{t('reorderSuggestions') || 'Genbestillings-forslag'}</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead>{t('product')}</TableHead>
                <TableHead>{t('supplier')}</TableHead>
                <TableHead>{t('urgency') || 'Prioritet'}</TableHead>
                <TableHead className="text-right">{t('currentStock')}</TableHead>
                <TableHead className="text-right">{t('minLevel')}</TableHead>
                <TableHead className="text-right">{t('orderQty') || 'Bestil'}</TableHead>
                <TableHead className="text-right">{t('orderValue') || 'Værdi'}</TableHead>
                <TableHead className="text-right">{t('actions')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reorderSuggestions.map((product) => (
                <TableRow key={product.id} className="hover:bg-slate-50">
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        product.urgency === 'critical' ? 'bg-red-100' : 'bg-orange-100'
                      }`}>
                        <Package className={`w-5 h-5 ${
                          product.urgency === 'critical' ? 'text-red-600' : 'text-orange-600'
                        }`} />
                      </div>
                      <div>
                        <div className="font-medium text-slate-900">{product.name}</div>
                        <div className="text-xs text-slate-500">SKU: {product.sku}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div className="font-medium">{product.supplier?.name || '-'}</div>
                      {product.lead_time_days && (
                        <div className="text-xs text-slate-500 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {product.lead_time_days} dage
                        </div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getUrgencyColor(product.urgency)}>
                      {product.urgency === 'critical' && '🔴 '}
                      {product.urgency}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <span className="text-red-600 font-semibold">
                      {product.current_stock} {product.unit}
                    </span>
                  </TableCell>
                  <TableCell className="text-right text-slate-600">
                    {product.min_stock_level} {product.unit}
                  </TableCell>
                  <TableCell className="text-right">
                    <span className="font-semibold text-blue-600">
                      {product.orderQuantity} {product.unit}
                    </span>
                  </TableCell>
                  <TableCell className="text-right font-semibold">
                    {product.orderValue.toLocaleString('da-DK')} {t('kr')}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleSendEmail(product)}
                        disabled={sendingEmail === product.id}
                      >
                        <Mail className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => handleApproveAndOrder(product)}
                      >
                        <CheckCircle2 className="w-4 h-4 mr-1" />
                        {t('approve') || 'Godkend'}
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {reorderSuggestions.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <CheckCircle2 className="w-12 h-12 mx-auto mb-3 text-green-500" />
              <p className="text-lg font-medium text-slate-900">{t('allStocked') || 'Alt er på lager!'}</p>
              <p className="text-sm">{t('noReordersNeeded') || 'Ingen genbestillinger nødvendige lige nu'}</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-white">
        <CardHeader>
          <CardTitle className="text-blue-900">{t('howItWorks') || 'Sådan virker det'}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-blue-800">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-xs font-bold">1</div>
            <div>
              <strong>{t('automaticDetection') || 'Automatisk Opdagelse'}:</strong> Systemet scanner alle produkter og finder dem med lagerbeholdning under minimum niveau.
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-xs font-bold">2</div>
            <div>
              <strong>{t('intelligentPriority') || 'Intelligent Prioritering'}:</strong> Kritiske komponenter (network switches, control systems) får højeste prioritet.
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-xs font-bold">3</div>
            <div>
              <strong>{t('oneClickOrder') || 'Et-klik Bestilling'}:</strong> Klik "Godkend" for at oprette indkøbsordre og sende email notifikation automatisk.
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-xs font-bold">4</div>
            <div>
              <strong>{t('emailNotification') || 'Email Notifikation'}:</strong> Du modtager email med alle detaljer så du kan følge op med leverandøren.
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}