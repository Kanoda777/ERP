import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Settings as SettingsIcon, Mail, Check, Copy, ExternalLink } from "lucide-react";
import { useLanguage } from "@/components/LanguageContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Settings() {
  const { t } = useLanguage();
  const [notificationEmail, setNotificationEmail] = useState("");
  const [enableNotifications, setEnableNotifications] = useState(false);
  const [saved, setSaved] = useState(false);
  const [copied, setCopied] = useState(false);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const saveSettingsMutation = useMutation({
    mutationFn: async (data) => {
      await base44.auth.updateMe({
        notification_email: data.notificationEmail,
        enable_low_stock_notifications: data.enableNotifications,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['currentUser']);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    },
  });

  const handleSaveSettings = () => {
    saveSettingsMutation.mutate({
      notificationEmail: notificationEmail || user?.email,
      enableNotifications,
    });
  };

  const currentUrl = window.location.origin;

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  React.useEffect(() => {
    if (user) {
      setNotificationEmail(user.notification_email || user.email || "");
      setEnableNotifications(user.enable_low_stock_notifications || false);
    }
  }, [user]);

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h2 className="text-3xl font-bold text-slate-900">{t('settings') || 'Indstillinger'}</h2>
        <p className="text-slate-500 mt-1">{t('manageSettings') || 'Administrer systemindstillinger'}</p>
      </div>

      <Tabs defaultValue="notifications" className="space-y-6">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="notifications">
            <Mail className="w-4 h-4 mr-2" />
            {t('emailNotifications')}
          </TabsTrigger>
          <TabsTrigger value="sharepoint">
            <ExternalLink className="w-4 h-4 mr-2" />
            SharePoint
          </TabsTrigger>
        </TabsList>

        <TabsContent value="notifications" className="space-y-6">
          <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-blue-600" />
                {t('emailNotifications')}
              </CardTitle>
              <CardDescription>{t('notificationSettings')}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                <div className="space-y-1">
                  <div className="font-medium text-slate-900">{t('enableNotifications')}</div>
                  <div className="text-sm text-slate-500">{t('lowStockAlert')}</div>
                  <div className="text-xs text-slate-400">{t('notifyWhenLow')}</div>
                </div>
                <Switch
                  checked={enableNotifications}
                  onCheckedChange={setEnableNotifications}
                />
              </div>

              {enableNotifications && (
                <div className="space-y-2">
                  <Label htmlFor="notificationEmail">{t('notificationEmail')}</Label>
                  <Input
                    id="notificationEmail"
                    type="email"
                    value={notificationEmail}
                    onChange={(e) => setNotificationEmail(e.target.value)}
                    placeholder="din@email.dk"
                  />
                  <p className="text-xs text-slate-500">
                    {t('defaultEmail') || 'Som standard bruges din bruger-email'}
                  </p>
                </div>
              )}

              {saved && (
                <Alert className="bg-green-50 border-green-200">
                  <Check className="w-4 h-4 text-green-600" />
                  <AlertDescription className="text-green-800">
                    {t('settingsSaved')}
                  </AlertDescription>
                </Alert>
              )}

              <Button
                onClick={handleSaveSettings}
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={saveSettingsMutation.isPending}
              >
                <SettingsIcon className="w-4 h-4 mr-2" />
                {t('saveSettings')}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sharepoint" className="space-y-6">
          <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>{t('sharepointGuide')}</CardTitle>
              <CardDescription>{t('embedInstructions')}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <h3 className="font-semibold text-blue-900 mb-2">{t('step')} 1: {t('copyUrl')}</h3>
                  <p className="text-sm text-blue-700 mb-3">{t('currentUrl')}:</p>
                  <div className="flex gap-2">
                    <Input
                      value={currentUrl}
                      readOnly
                      className="font-mono text-sm bg-white"
                    />
                    <Button
                      variant="outline"
                      onClick={() => copyToClipboard(currentUrl)}
                      className="shrink-0"
                    >
                      {copied ? (
                        <>
                          <Check className="w-4 h-4 mr-2" />
                          {t('copied')}
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          {t('copy')}
                        </>
                      )}
                    </Button>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 rounded-lg">
                  <h3 className="font-semibold text-slate-900 mb-2">{t('step')} 2: SharePoint Page</h3>
                  <ol className="text-sm text-slate-700 space-y-2 list-decimal list-inside">
                    <li>Gå til din SharePoint side</li>
                    <li>Klik på "Edit" (Rediger)</li>
                    <li>Tilføj en ny "Embed" web part</li>
                    <li>Indsæt URL'en fra trin 1</li>
                    <li>Gem siden</li>
                  </ol>
                </div>

                <div className="p-4 bg-slate-50 rounded-lg">
                  <h3 className="font-semibold text-slate-900 mb-2">{t('step')} 3: Microsoft Teams</h3>
                  <ol className="text-sm text-slate-700 space-y-2 list-decimal list-inside">
                    <li>Åbn din Teams kanal</li>
                    <li>Klik på "+" for at tilføje en tab</li>
                    <li>Vælg "Website"</li>
                    <li>Indsæt URL'en og giv den et navn (f.eks. "ERP System")</li>
                    <li>Gem</li>
                  </ol>
                </div>

                <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                  <h3 className="font-semibold text-purple-900 mb-2">💡 Power BI Integration</h3>
                  <p className="text-sm text-purple-700 mb-2">
                    Eksporter data fra hver side (Lager, Salg, etc.) ved at bruge "Eksporter" knappen.
                  </p>
                  <p className="text-sm text-purple-700">
                    Importér derefter CSV/Excel filerne i Power BI for avancerede visualiseringer og rapporter.
                  </p>
                </div>

                <Alert className="bg-amber-50 border-amber-200">
                  <AlertDescription className="text-amber-800 text-sm">
                    <strong>Sikkerhedstip:</strong> Systemet bruger Base44's indbyggede authentication. 
                    Kun autoriserede brugere kan se og redigere data. Kontakt Base44 support for SSO integration med Microsoft Azure AD.
                  </AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}