import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Plus, 
  Search,
  Filter,
  Camera,
  Upload,
  Trash2,
  Loader2,
  FileText,
  MapPin,
  Download,
  Box,
  Layers,
  Weight,
  Ruler,
  Eye
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useLanguage } from "@/components/LanguageContext";
import ExportButton from "@/components/ExportButton";
import EquipmentViewDialog from "@/components/equipment/EquipmentViewDialog";
import { format } from "date-fns";

export default function TestEquipment() {
  const { t } = useLanguage();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [editingEquipment, setEditingEquipment] = useState(null);
  const [viewingEquipment, setViewingEquipment] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSite, setFilterSite] = useState("all");
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [uploadingDoc, setUploadingDoc] = useState(false);
  const [photos, setPhotos] = useState([]);
  const [documents, setDocuments] = useState([]);
  const queryClient = useQueryClient();

  const { data: equipment = [] } = useQuery({
    queryKey: ['testEquipment'],
    queryFn: () => base44.entities.TestEquipment.list('-created_date'),
  });

  const { data: projects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.list(),
  });

  const createEquipmentMutation = useMutation({
    mutationFn: (data) => base44.entities.TestEquipment.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['testEquipment']);
      setDialogOpen(false);
      setEditingEquipment(null);
      setPhotos([]);
      setDocuments([]);
    },
  });

  const updateEquipmentMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.TestEquipment.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['testEquipment']);
      setDialogOpen(false);
      setEditingEquipment(null);
      setPhotos([]);
      setDocuments([]);
    },
  });

  const deleteEquipmentMutation = useMutation({
    mutationFn: (id) => base44.entities.TestEquipment.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['testEquipment']);
    },
  });

  const handlePhotoUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setUploadingPhoto(true);
    try {
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        const photo = {
          url: file_url,
          caption: file.name,
        };
        setPhotos(prev => [...prev, photo]);
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Fejl ved upload af billede');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleDocumentUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setUploadingDoc(true);
    try {
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        const doc = {
          name: file.name,
          url: file_url,
          type: 'other',
          uploaded_date: format(new Date(), 'yyyy-MM-dd'),
        };
        setDocuments(prev => [...prev, doc]);
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Fejl ved upload af dokument');
    } finally {
      setUploadingDoc(false);
    }
  };

  const handleRemovePhoto = (index) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const handleRemoveDocument = (index) => {
    setDocuments(prev => prev.filter((_, i) => i !== index));
  };

  const handleDocumentTypeChange = (index, newType) => {
    setDocuments(prev => prev.map((doc, i) => 
      i === index ? { ...doc, type: newType } : doc
    ));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    
    const dimensions = {
      length_mm: parseFloat(formData.get('length_mm')) || null,
      width_mm: parseFloat(formData.get('width_mm')) || null,
      height_mm: parseFloat(formData.get('height_mm')) || null,
    };

    const data = {
      name: formData.get('name'),
      equipment_id: formData.get('equipment_id'),
      type: formData.get('type'),
      quantity: parseFloat(formData.get('quantity')) || 1,
      weight_kg: parseFloat(formData.get('weight_kg')) || null,
      dimensions: (dimensions.length_mm || dimensions.width_mm || dimensions.height_mm) ? dimensions : null,
      added_by: formData.get('added_by'),
      developed_for_project: formData.get('developed_for_project'),
      site: formData.get('site'),
      status: formData.get('status'),
      description: formData.get('description'),
      specifications: formData.get('specifications'),
      manufacturer: formData.get('manufacturer'),
      year_developed: parseInt(formData.get('year_developed')) || null,
      condition: formData.get('condition'),
      notes: formData.get('notes'),
      photos: photos,
      technical_documents: documents,
    };

    if (editingEquipment) {
      updateEquipmentMutation.mutate({ id: editingEquipment.id, data });
    } else {
      createEquipmentMutation.mutate(data);
    }
  };

  const filteredEquipment = equipment.filter(item => {
    const matchesSearch = item.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.equipment_id?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSite = filterSite === "all" || item.site === filterSite;
    return matchesSearch && matchesSite;
  });

  const handleDelete = (equipment) => {
    const code = prompt('Indtast admin kode for at slette:');
    if (code === 'DDigital') {
      if (confirm(`Er du sikker på at du vil slette "${equipment.name}"?`)) {
        deleteEquipmentMutation.mutate(equipment.id);
      }
    } else if (code !== null) {
      alert('Forkert admin kode');
    }
  };

  const equipmentBySite = {
    HQ: equipment.filter(e => e.site === 'HQ').length,
    Ebeltoft: equipment.filter(e => e.site === 'Ebeltoft').length,
    Polen: equipment.filter(e => e.site === 'Polen').length,
  };

  const exportColumns = [
    { label: t('name') || 'Navn', accessor: (item) => item.name },
    { label: t('equipmentId') || 'ID', accessor: (item) => item.equipment_id },
    { label: t('type') || 'Type', accessor: (item) => item.type },
    { label: t('quantity') || 'Antal', accessor: (item) => item.quantity || 1 },
    { label: t('site'), accessor: (item) => item.site },
    { label: t('status'), accessor: (item) => t(item.status) },
    { label: t('developedFor') || 'Udviklet til', accessor: (item) => item.developed_for_project || '-' },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">{t('testEquipment') || 'Test Udstyr'}</h2>
          <p className="text-slate-500 mt-1">{t('manageTestEquipment') || 'Administrer special udviklet test udstyr'}</p>
        </div>
        <div className="flex gap-3">
          <ExportButton 
            data={filteredEquipment}
            filename={`test-equipment-${new Date().toISOString().split('T')[0]}`}
            columns={exportColumns}
          />
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => {
                setEditingEquipment(null);
                setPhotos([]);
                setDocuments([]);
              }}>
                <Plus className="w-4 h-4 mr-2" />
                {t('addEquipment') || 'Tilføj Udstyr'}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingEquipment ? t('editEquipment') : t('newEquipment') || 'Nyt Udstyr'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">{t('name') || 'Navn'} *</Label>
                    <Input id="name" name="name" defaultValue={editingEquipment?.name} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="equipment_id">{t('equipmentId') || 'Udstyrs ID'} *</Label>
                    <Input id="equipment_id" name="equipment_id" defaultValue={editingEquipment?.equipment_id} required />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="added_by">{t('addedBy') || 'Tilføjet af'}</Label>
                  <Input id="added_by" name="added_by" defaultValue={editingEquipment?.added_by} placeholder={t('yourName') || 'Dit navn'} />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="type">{t('type') || 'Type'} *</Label>
                    <Select name="type" defaultValue={editingEquipment?.type || 'other'}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="camera_pedestal">{t('cameraPedestal') || 'Kamera Pedistal'}</SelectItem>
                        <SelectItem value="radar_pedestal">{t('radarPedestal') || 'Radar Pedistal'}</SelectItem>
                        <SelectItem value="test_rig">{t('testRig') || 'Test Rig'}</SelectItem>
                        <SelectItem value="measurement_system">{t('measurementSystem') || 'Målesystem'}</SelectItem>
                        <SelectItem value="calibration_equipment">{t('calibrationEquipment') || 'Kalibreringsudstyr'}</SelectItem>
                        <SelectItem value="prototype">{t('prototype') || 'Prototype'}</SelectItem>
                        <SelectItem value="other">{t('other')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="site">{t('site')} *</Label>
                    <Select name="site" defaultValue={editingEquipment?.site || 'HQ'}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="HQ">🏢 HQ</SelectItem>
                        <SelectItem value="Ebeltoft">🏭 Ebeltoft</SelectItem>
                        <SelectItem value="Polen">🇵🇱 Polen</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="status">{t('status')} *</Label>
                    <Select name="status" defaultValue={editingEquipment?.status || 'available'}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="available">{t('available')}</SelectItem>
                        <SelectItem value="in_use">{t('in_use')}</SelectItem>
                        <SelectItem value="under_development">{t('underDevelopment') || 'Under udvikling'}</SelectItem>
                        <SelectItem value="maintenance">{t('maintenance')}</SelectItem>
                        <SelectItem value="offshore">{t('offshore')}</SelectItem>
                        <SelectItem value="retired">{t('retired')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="quantity">{t('quantity') || 'Antal'}</Label>
                    <Input id="quantity" name="quantity" type="number" defaultValue={editingEquipment?.quantity || 1} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="weight_kg">{t('weight') || 'Vægt'} (kg)</Label>
                    <Input id="weight_kg" name="weight_kg" type="number" step="0.01" defaultValue={editingEquipment?.weight_kg} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="developed_for_project">{t('developedFor') || 'Udviklet til projekt'}</Label>
                    <Input id="developed_for_project" name="developed_for_project" defaultValue={editingEquipment?.developed_for_project} />
                  </div>
                </div>

                <div className="border p-4 rounded-lg space-y-3">
                  <Label className="flex items-center gap-2">
                    <Ruler className="w-4 h-4" />
                    {t('dimensions') || 'Dimensioner'} (mm)
                  </Label>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="length_mm">{t('length') || 'Længde'}</Label>
                      <Input id="length_mm" name="length_mm" type="number" defaultValue={editingEquipment?.dimensions?.length_mm} placeholder="mm" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="width_mm">{t('width') || 'Bredde'}</Label>
                      <Input id="width_mm" name="width_mm" type="number" defaultValue={editingEquipment?.dimensions?.width_mm} placeholder="mm" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="height_mm">{t('height') || 'Højde'}</Label>
                      <Input id="height_mm" name="height_mm" type="number" defaultValue={editingEquipment?.dimensions?.height_mm} placeholder="mm" />
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="manufacturer">{t('manufacturer')}</Label>
                    <Input id="manufacturer" name="manufacturer" defaultValue={editingEquipment?.manufacturer} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="year_developed">{t('yearDeveloped') || 'Udviklingsår'}</Label>
                    <Input id="year_developed" name="year_developed" type="number" defaultValue={editingEquipment?.year_developed} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">{t('description')}</Label>
                  <Textarea id="description" name="description" defaultValue={editingEquipment?.description} rows={2} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="specifications">{t('specifications') || 'Tekniske specifikationer'}</Label>
                  <Textarea id="specifications" name="specifications" defaultValue={editingEquipment?.specifications} rows={3} />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="condition">{t('condition')}</Label>
                    <Select name="condition" defaultValue={editingEquipment?.condition || 'good'}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="excellent">{t('excellent')}</SelectItem>
                        <SelectItem value="good">{t('good')}</SelectItem>
                        <SelectItem value="fair">{t('fair')}</SelectItem>
                        <SelectItem value="poor">{t('poor')}</SelectItem>
                        <SelectItem value="needs_repair">{t('needsRepair') || 'Skal repareres'}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="notes">{t('notes')}</Label>
                    <Textarea id="notes" name="notes" defaultValue={editingEquipment?.notes} rows={3} />
                  </div>
                </div>

                {/* Photos Section */}
                <div className="space-y-2 p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2">
                      <Camera className="w-4 h-4" />
                      {t('photos') || 'Fotos'}
                    </Label>
                    <label htmlFor="photo-upload" className="cursor-pointer">
                      <div className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                        {uploadingPhoto ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            {t('uploading')}...
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4" />
                            {t('uploadPhoto')}
                          </>
                        )}
                      </div>
                      <input
                        id="photo-upload"
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={handlePhotoUpload}
                        className="hidden"
                        disabled={uploadingPhoto}
                      />
                    </label>
                  </div>
                  
                  {photos.length > 0 ? (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
                      {photos.map((photo, index) => (
                        <div key={index} className="relative group">
                          <img 
                            src={photo.url} 
                            alt={photo.caption}
                            className="w-full h-32 object-cover rounded border border-slate-200"
                          />
                          <Button
                            type="button"
                            size="sm"
                            variant="destructive"
                            className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => handleRemovePhoto(index)}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-slate-500 text-center py-4">
                      {t('noPhotosYet')}
                    </p>
                  )}
                </div>

                {/* Technical Documents Section */}
                <div className="space-y-2 p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      {t('technicalDocuments') || 'Tekniske Dokumenter'}
                    </Label>
                    <label htmlFor="doc-upload" className="cursor-pointer">
                      <div className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                        {uploadingDoc ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            {t('uploading')}...
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4" />
                            {t('uploadDocument') || 'Upload Dokument'}
                          </>
                        )}
                      </div>
                      <input
                        id="doc-upload"
                        type="file"
                        multiple
                        accept=".pdf,.dwg,.dxf,.step,.stp,.igs,.iges,.stl,.png,.jpg,.jpeg,.doc,.docx"
                        onChange={handleDocumentUpload}
                        className="hidden"
                        disabled={uploadingDoc}
                      />
                    </label>
                  </div>
                  
                  {documents.length > 0 ? (
                    <div className="space-y-2 mt-3">
                      {documents.map((doc, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-white rounded border border-slate-200">
                          <div className="flex items-center gap-3 flex-1">
                            <FileText className="w-4 h-4 text-blue-600" />
                            <div className="flex-1">
                              <div className="text-sm font-medium">{doc.name}</div>
                              <div className="flex gap-2 mt-1">
                                <Select 
                                  value={doc.type} 
                                  onValueChange={(value) => handleDocumentTypeChange(index, value)}
                                >
                                  <SelectTrigger className="h-7 text-xs w-48">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="3d_model">3D Model</SelectItem>
                                    <SelectItem value="2d_drawing">2D Tegning</SelectItem>
                                    <SelectItem value="assembly_drawing">Assembly Tegning</SelectItem>
                                    <SelectItem value="technical_spec">Teknisk Spec</SelectItem>
                                    <SelectItem value="manual">Manual</SelectItem>
                                    <SelectItem value="calibration_cert">Kalibrerings Certifikat</SelectItem>
                                    <SelectItem value="other">{t('other')}</SelectItem>
                                  </SelectContent>
                                </Select>
                                <span className="text-xs text-slate-500">{doc.uploaded_date}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <a href={doc.url} target="_blank" rel="noopener noreferrer">
                              <Button type="button" size="sm" variant="ghost">
                                <Download className="w-4 h-4" />
                              </Button>
                            </a>
                            <Button
                              type="button"
                              size="sm"
                              variant="ghost"
                              onClick={() => handleRemoveDocument(index)}
                            >
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-slate-500 text-center py-4">
                      {t('noDocumentsYet') || 'Ingen dokumenter uploadet endnu'}
                    </p>
                  )}
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    {t('cancel')}
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    {editingEquipment ? t('saveChanges') : t('createEquipment') || 'Opret udstyr'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <Layers className="w-4 h-4" />
              {t('totalEquipment') || 'Total Udstyr'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">{equipment.length}</div>
            <div className="text-xs text-slate-500 mt-1">
              🏢 HQ: {equipmentBySite.HQ} • 🏭 Ebeltoft: {equipmentBySite.Ebeltoft} • 🇵🇱 Polen: {equipmentBySite.Polen}
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200/60 bg-green-50/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <Box className="w-4 h-4 text-green-600" />
              {t('available')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {equipment.filter(e => e.status === 'available').length}
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-200/60 bg-blue-50/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <Box className="w-4 h-4 text-blue-600" />
              {t('in_use')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {equipment.filter(e => e.status === 'in_use' || e.status === 'offshore').length}
            </div>
          </CardContent>
        </Card>

        <Card className="border-orange-200/60 bg-orange-50/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <Box className="w-4 h-4 text-orange-600" />
              {t('underDevelopment') || 'Under udvikling'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {equipment.filter(e => e.status === 'under_development').length}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Equipment Table */}
      <Card className="border-slate-200/60 bg-white/80 backdrop-blur-sm">
        <CardHeader className="border-b border-slate-200/60">
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                placeholder={t('searchEquipment') || 'Søg udstyr...'}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterSite} onValueChange={setFilterSite}>
              <SelectTrigger className="w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('allSites')}</SelectItem>
                <SelectItem value="HQ">🏢 HQ</SelectItem>
                <SelectItem value="Ebeltoft">🏭 Ebeltoft</SelectItem>
                <SelectItem value="Polen">🇵🇱 Polen</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead>{t('equipment') || 'Udstyr'}</TableHead>
                <TableHead>{t('type')}</TableHead>
                <TableHead className="text-center">{t('quantity') || 'Antal'}</TableHead>
                <TableHead>{t('site')}</TableHead>
                <TableHead>{t('status')}</TableHead>
                <TableHead className="text-center">{t('photos')}</TableHead>
                <TableHead className="text-center">{t('documents') || 'Dokumenter'}</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredEquipment.map((item) => (
                <TableRow 
                  key={item.id} 
                  className="hover:bg-slate-50 cursor-pointer"
                  onClick={() => {
                    setViewingEquipment(item);
                    setViewDialogOpen(true);
                  }}
                >
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Box className="w-4 h-4 text-slate-400" />
                      <div>
                        <div className="font-medium">{item.name}</div>
                        <div className="text-sm text-slate-500">{item.equipment_id}</div>
                        {item.developed_for_project && (
                          <div className="text-xs text-slate-400 mt-0.5">
                            {t('developedFor') || 'Udviklet til'}: {item.developed_for_project}
                          </div>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {item.type?.replace(/_/g, ' ')}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge className="bg-slate-100 text-slate-800">
                      {item.quantity || 1}x
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="gap-1">
                      <MapPin className="w-3 h-3" />
                      {item.site}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={
                      item.status === 'available' ? 'bg-green-100 text-green-800' :
                      item.status === 'in_use' || item.status === 'offshore' ? 'bg-blue-100 text-blue-800' :
                      item.status === 'under_development' ? 'bg-orange-100 text-orange-800' :
                      'bg-slate-100 text-slate-800'
                    }>
                      {t(item.status)}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    {item.photos?.length > 0 ? (
                      <Badge className="bg-blue-100 text-blue-800 gap-1">
                        <Camera className="w-3 h-3" />
                        {item.photos.length}
                      </Badge>
                    ) : '-'}
                  </TableCell>
                  <TableCell className="text-center">
                    {item.technical_documents?.length > 0 ? (
                      <Badge className="bg-purple-100 text-purple-800 gap-1">
                        <FileText className="w-3 h-3" />
                        {item.technical_documents.length}
                      </Badge>
                    ) : '-'}
                  </TableCell>
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      onClick={() => handleDelete(item)} 
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredEquipment.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <Box className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>{t('noEquipmentFound') || 'Intet udstyr fundet'}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Dialog */}
      <EquipmentViewDialog
        equipment={viewingEquipment}
        open={viewDialogOpen}
        onClose={() => {
          setViewDialogOpen(false);
          setViewingEquipment(null);
        }}
        onEdit={(equipment) => {
          setViewDialogOpen(false); // Close view dialog first
          setViewingEquipment(null); // Clear viewing equipment
          setEditingEquipment(equipment);
          setPhotos(equipment.photos || []);
          setDocuments(equipment.technical_documents || []);
          setDialogOpen(true); // Open edit dialog
        }}
      />
    </div>
  );
}